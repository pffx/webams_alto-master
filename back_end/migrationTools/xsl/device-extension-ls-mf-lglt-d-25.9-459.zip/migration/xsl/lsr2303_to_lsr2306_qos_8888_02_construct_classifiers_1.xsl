<?xml version="1.0"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:bbf-qos-filt="urn:bbf:yang:bbf-qos-filters"
                xmlns:bbf-qos-enhfilt="urn:bbf:yang:bbf-qos-enhanced-filters"
                xmlns:bbf-qos-pol="urn:bbf:yang:bbf-qos-policies"
                xmlns:bbf-qos-cls="urn:bbf:yang:bbf-qos-classifiers"
                xmlns:bbf-qos-plc="urn:bbf:yang:bbf-qos-policing"
                xmlns:nokia-qos-filt="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-qos-filters-ext"
                xmlns:nokia-sdan-qos-policing-extension="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-sdan-qos-policing-extension"
                xmlns:nokia-qos-cls-ext="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-sdan-qos-classifier-extension"
                xmlns=""
                version="1.0">

  <xsl:strip-space elements="*"/>
  <xsl:output method="xml" indent="yes"/>

  <xsl:key name="classifierByName" 
      match="*[local-name()='classifier-entry' and parent::*[local-name()='classifiers' and namespace-uri()='urn:bbf:yang:bbf-qos-classifiers']]" 
      use="*[local-name()='name']"/>

  <!-- enum enhanced filter type-->
  <xsl:variable name="F_EN_FILTER_WITHOUT_FLOW_COLOR" select="'F_EN_FILTER_WITHOUT_FLOW_COLOR'"/>
  <xsl:variable name="F_EN_FILTER_FLOW_COLOR" select="'F_EN_FILTER_FLOW_COLOR'"/>

  <!-- Classifier Action Type enumeration -->
  <xsl:variable name="A_PBIT_MARKING" select="'A_PBIT_MARKING'"/>
  <xsl:variable name="A_DEI_MARKING" select="'A_DEI_MARKING'"/>
  <xsl:variable name="A_DSCP_MARKING" select="'A_DSCP_MARKING'"/>
  <xsl:variable name="A_SCHEDULING_TRAFFIC" select="'A_SCHEDULING_TRAFFIC'"/>
  <xsl:variable name="A_FLOW_COLOR" select="'A_FLOW_COLOR'"/>
  <xsl:variable name="A_BAC_COLOR" select="'A_BAC_COLOR'"/>
  <xsl:variable name="A_DISCARD" select="'A_DISCARD'"/>
  <xsl:variable name="A_POLICING" select="'A_POLICING'"/>
  <xsl:variable name="A_PASS" select="'A_PASS'"/>
  <xsl:variable name="A_RATE_LIMIT" select="'A_RATE_LIMIT'"/>
  <xsl:variable name="A_PBIT_POLICING_TC" select="'A_PBIT_POLICING_TC'"/>
  <xsl:variable name="A_COUNT" select="'A_COUNT'"/>
  <xsl:variable name="A_UNKNOWN" select="'A_UNKNOWN'"/>

  <!-- Inline filter enumeration -->
  <xsl:variable name="F_MATCH_ALL" select="'F_MATCH_ALL'"/>
  <xsl:variable name="F_ANY_PROTOCOL" select="'F_ANY_PROTOCOL'"/>
  <xsl:variable name="F_PRECEDENC_RANGE" select="'F_PRECEDENC_RANGE'"/>
  <xsl:variable name="F_UNMETERED" select="'F_UNMETERED'"/>
  <!-- inline and enhanced-classifier in common -->
  <xsl:variable name="F_UNTAGGED" select="'F_UNTAGGED'"/>
  <xsl:variable name="F_FLOW_COLOR" select="'F_FLOW_COLOR'"/>
  <xsl:variable name="F_DSCP_RANGE" select="'F_DSCP_RANGE'"/>
  <xsl:variable name="F_DSCP_ANY" select="'F_DSCP_ANY'"/>
  <xsl:variable name="F_PROTOCOL_IGMP" select="'F_PROTOCOL_IGMP'"/>
  <xsl:variable name="F_PROTOCOL_NOT_IGMP" select="'F_PROTOCOL_NOT_IGMP'"/>
  <xsl:variable name="F_IN_PBIT_LIST" select="'F_IN_PBIT_LIST'"/>
  <xsl:variable name="F_IN_DEI" select="'F_IN_DEI'"/>
  <xsl:variable name="F_PBIT_MARKING" select="'F_PBIT_MARKING'"/>
  <xsl:variable name="F_DEI_MARKING" select="'F_DEI_MARKING'"/>
  <!-- any frame filter enumeration -->
  <xsl:variable name="F_ANY_FRAME" select="'F_ANY_FRAME'"/>

  <!-- enhanced classifier enumeration -->
  <xsl:variable name="F_EN_SOURCE_MAC" select="'F_EN_SOURCE_MAC'"/>
  <xsl:variable name="F_EN_DEST_MAC" select="'F_EN_DEST_MAC'"/>
  <xsl:variable name="F_EN_ETHERNET_FRAME_TYPE" select="'F_EN_ETHERNET_FRAME_TYPE'"/>
  <xsl:variable name="F_EN_ETHERNET_FRAME_TYPE_IPV4" select="'F_EN_ETHERNET_FRAME_TYPE_IPV4'"/>
  <xsl:variable name="F_EN_ETHERNET_FRAME_TYPE_IPV6" select="'F_EN_ETHERNET_FRAME_TYPE_IPV6'"/>
  <xsl:variable name="F_EN_ETHERNET_FRAME_TYPE_PPPOE" select="'F_EN_ETHERNET_FRAME_TYPE_PPPOE'"/>
  <xsl:variable name="F_EN_ETHERNET_FRAME_TYPE_UNKNOWN" select="'F_EN_ETHERNET_FRAME_TYPE_UNKNOWN'"/>
  <xsl:variable name="F_EN_IPV4" select="'F_EN_IPV4'"/>
  <xsl:variable name="F_EN_IPV6" select="'F_EN_IPV6'"/>
  <xsl:variable name="F_EN_IP_COMMON_DSCP" select="'F_EN_IP_COMMON_DSCP'"/>
  <xsl:variable name="F_EN_IP_COMMON_IGMP" select="'F_EN_IP_COMMON_IGMP'"/>
  <xsl:variable name="F_EN_IP_COMMON_NOT_DSCP_DSCPRANGE_IGMP"
                select="'F_EN_IP_COMMON_NOT_DSCP_DSCPRANGE_IGMP'"/>
  <xsl:variable name="F_EN_TRANSPORT" select="'F_EN_TRANSPORT'"/>
  <xsl:variable name="F_PROTOCOL_ARP" select="'F_PROTOCOL_ARP'"/>
  <xsl:variable name="F_UNKNOWN" select="'F_UNKNOWN'"/>

  <!-- flow-color enumeration -->
  <xsl:variable name="FLOW_COLOR_GREEN" select="'green'"/>
  <xsl:variable name="FLOW_COLOR_YELLOW" select="'yellow'"/>
  <xsl:variable name="FLOW_COLOR_RED" select="'red'"/>

  <!-- filter-operation enumeration -->
  <xsl:variable name="OPER_MATCH_ANY" select="'OPER_MATCH_ANY'"/>
  <xsl:variable name="OPER_MATCH_ALL" select="'OPER_MATCH_ALL'"/>
  <xsl:variable name="OPER_UNKNOWN" select="'OPER_UNKNOWN'"/>
  <!-- ip common protocol value enumeration -->
  <xsl:variable name="PROTOCAL_IGMP_IN_IP_HEAD" select="'2'"/>

  <!-- Color mode -->
  <xsl:variable name="color-blind" select="'color-blind'"/>
  <xsl:variable name="color-aware" select="'color-aware'"/>


  <!-- enum Policing type -->
  <xsl:variable name="POLICING_TYPE_TRTCM_MEF_COLOR_BLIND" select="'POLICING_TYPE_TRTCM_MEF_COLOR_BLIND'"/>
  <xsl:variable name="POLICING_TYPE_TRTCM_MEF_COLOR_AWARE" select="'POLICING_TYPE_TRTCM_MEF_COLOR_AWARE'"/>
  <xsl:variable name="POLICING_TYPE_TRTCM_COS" select="'POLICING_TYPE_TRTCM_COS'"/>
  <xsl:variable name="POLICING_TYPE_TRTCM_MEF_COS" select="'POLICING_TYPE_TRTCM_MEF_COS'"/>
  <xsl:variable name="POLICING_TYPE_STB" select="'POLICING_TYPE_STB'"/>


  <!-- default rule -->
  <xsl:template match="*">
    <xsl:copy>
      <xsl:copy-of select="@*"/>
      <xsl:apply-templates/>
    </xsl:copy>
  </xsl:template>

  <!-- Insert info on classifier -->
  <xsl:template match="*[
    local-name() = 'classifier'
    and parent::*[local-name() = 'classifiers']
    and ancestor::*[local-name() = 'policy-migration-cache']
    and ancestor::*[local-name() = 'policy']
    and ancestor::*[local-name() = 'policies' and namespace-uri() = 'urn:bbf:yang:bbf-qos-policies']
  ]">
    <xsl:variable name="curClsName">
      <xsl:value-of select="current()/child::*[local-name() = 'name']"/>
    </xsl:variable>

    <xsl:variable name="classifier" select="key('classifierByName', $curClsName)"/>

    <xsl:variable name="anyframeTypeVar">
      <xsl:call-template name="isAnyFrameFilter">
        <xsl:with-param name="classifierSec" select="$classifier"/>
      </xsl:call-template>
    </xsl:variable>

    <xsl:variable name="filterOperationVar">
      <xsl:call-template name="getFilterOperation">
        <xsl:with-param name="classifierSec" select="$classifier"/>
      </xsl:call-template>
    </xsl:variable>

    <xsl:copy>
      <xsl:copy-of select="@*"/>
      <xsl:apply-templates/>

      <xsl:if test="$filterOperationVar and string-length($filterOperationVar) > 0">
        <xsl:element name="filter-operation">
          <xsl:value-of select="$filterOperationVar"/>
        </xsl:element>
      </xsl:if>

      <xsl:if test="$anyframeTypeVar and string-length($anyframeTypeVar) > 0">
        <xsl:element name="any-frame">
          <xsl:value-of select="$anyframeTypeVar"/>
        </xsl:element>
      </xsl:if>

    </xsl:copy>

  </xsl:template>

  <!-- Insert info on classifier actions-->
  <xsl:template match="
      *[
      local-name() = 'actions'
      and parent::*[local-name() = 'classifier']
      and ancestor::*[local-name() = 'classifiers']
      and ancestor::*[local-name() = 'policy-migration-cache']
      and ancestor::*[local-name() = 'policy']
      and ancestor::*[local-name() = 'policies' and namespace-uri() = 'urn:bbf:yang:bbf-qos-policies']
      ]">

    <xsl:variable name="curClsName">
      <xsl:value-of select="../child::*[local-name() = 'name']"/>
    </xsl:variable>

    <xsl:variable name="classifier" select="key('classifierByName', $curClsName)"/>

    <xsl:copy>
      <xsl:copy-of select="@*"/>
      <xsl:for-each select="$classifier/child::*[local-name() = 'classifier-action-entry-cfg']">
        <xsl:variable name="actionTypeVariable">
          <xsl:call-template name="getActionType">
            <xsl:with-param name="actionSecParam" select="."/>
          </xsl:call-template>
        </xsl:variable>
        <xsl:element name="action">
          <xsl:element name="type">
            <xsl:value-of select="$actionTypeVariable"/>
          </xsl:element>
        </xsl:element>
      </xsl:for-each>
    </xsl:copy>
  </xsl:template>

  <!-- Insert info on classifier filters -->
  <xsl:template match="
      *[
      local-name() = 'filters'
      and parent::*[local-name() = 'classifier']
      and ancestor::*[local-name() = 'classifiers']
      and ancestor::*[local-name() = 'policy-migration-cache']
      and ancestor::*[local-name() = 'policy']
      and ancestor::*[local-name() = 'policies' and namespace-uri() = 'urn:bbf:yang:bbf-qos-policies']
      ]">
    <xsl:variable name="curClsName">
      <xsl:value-of select="../child::*[local-name() = 'name']"/>
    </xsl:variable>

    <xsl:variable name="classifier" select="key('classifierByName', $curClsName)"/>

    <xsl:variable name="inlineClassifierTypeVar">
      <xsl:if test="$classifier/child::*[local-name() = 'match-criteria']">
        <xsl:call-template name="getInlineFilterType">
          <xsl:with-param name="matchCriteriaSec"
                          select="$classifier/child::*[local-name() = 'match-criteria']"/>
        </xsl:call-template>
      </xsl:if>
    </xsl:variable>

    <xsl:variable name="enhClassifierTypeVar">
      <xsl:call-template name="getEnhClassifierType">
        <xsl:with-param name="classifierSec" select="$classifier"/>
      </xsl:call-template>
    </xsl:variable>

    <xsl:copy>
      <xsl:copy-of select="@*"/>
      <xsl:apply-templates/>

      <xsl:if test="$inlineClassifierTypeVar and string-length($inlineClassifierTypeVar) > 0">
        <xsl:element name="inline-filter-type">
          <xsl:value-of select="$inlineClassifierTypeVar"/>
        </xsl:element>
      </xsl:if>

      <xsl:if test="$enhClassifierTypeVar and string-length($enhClassifierTypeVar) > 0">
        <xsl:element name="enh-filter-type">
          <xsl:value-of select="$enhClassifierTypeVar"/>
        </xsl:element>
      </xsl:if>

      <xsl:if test="string-length($inlineClassifierTypeVar) > 0 or string-length($enhClassifierTypeVar) > 0">
        <xsl:element name="self-filter-types">
          <xsl:choose>
            <xsl:when test="string-length($inlineClassifierTypeVar) > 0 and string-length($enhClassifierTypeVar) > 0">
              <xsl:value-of select="concat($inlineClassifierTypeVar,',',$enhClassifierTypeVar)"/>
            </xsl:when>
            <xsl:when test="boolean($inlineClassifierTypeVar) and string-length($inlineClassifierTypeVar) > 0">
              <xsl:value-of select="$inlineClassifierTypeVar"/>
            </xsl:when>
            <xsl:when test="boolean($enhClassifierTypeVar) and string-length($enhClassifierTypeVar) > 0">
              <xsl:value-of select="$enhClassifierTypeVar"/>
            </xsl:when>
          </xsl:choose>
        </xsl:element>
      </xsl:if>

      <xsl:if test="
        (contains($inlineClassifierTypeVar,$F_FLOW_COLOR) and (not($enhClassifierTypeVar) or $enhClassifierTypeVar = ''))
        or (contains($enhClassifierTypeVar,$F_FLOW_COLOR) and (not($inlineClassifierTypeVar) or $inlineClassifierTypeVar = ''))
      ">
        <xsl:element name="self-filter-flow-color">
          <xsl:if test="contains($inlineClassifierTypeVar, $F_FLOW_COLOR)">
            <xsl:variable name="flowColorVar">
              <xsl:value-of
                      select="$classifier/child::*[local-name() = 'match-criteria']/child::*[local-name() = 'flow-color']"/>
            </xsl:variable>
            <xsl:choose>
              <xsl:when test="$flowColorVar = 'green' or $flowColorVar = 'bbf-qos-plc:green'">
                <xsl:value-of select="$FLOW_COLOR_GREEN"/>
              </xsl:when>
              <xsl:when test="$flowColorVar = 'yellow' or $flowColorVar = 'bbf-qos-plc:yellow'">
                <xsl:value-of select="$FLOW_COLOR_YELLOW"/>
              </xsl:when>
              <xsl:otherwise>
                <xsl:value-of select="$FLOW_COLOR_RED"/>
              </xsl:otherwise>
            </xsl:choose>
          </xsl:if>
          <xsl:if test="contains($enhClassifierTypeVar, $F_FLOW_COLOR)">
            <xsl:variable name="flowColorVar">
              <xsl:value-of select="$classifier/child::*[local-name() = 'flow-color']"/>
            </xsl:variable>
            <xsl:choose>
              <xsl:when test="$flowColorVar = 'green' or $flowColorVar = 'bbf-qos-plc:green'">
                <xsl:value-of select="$FLOW_COLOR_GREEN"/>
              </xsl:when>
              <xsl:when test="$flowColorVar = 'yellow' or $flowColorVar = 'bbf-qos-plc:yellow'">
                <xsl:value-of select="$FLOW_COLOR_YELLOW"/>
              </xsl:when>
              <xsl:otherwise>
                <xsl:value-of select="$FLOW_COLOR_RED"/>
              </xsl:otherwise>
            </xsl:choose>
          </xsl:if>
        </xsl:element>
      </xsl:if>
    </xsl:copy>
  </xsl:template>

  <!-- ========================= Infra Function ============================= -->
  <xsl:template name="isAnyFrameFilter">
    <xsl:param name="classifierSec"/>
    <xsl:if test="$classifierSec/child::*[local-name() = 'any-frame']">
      <xsl:value-of select="$F_ANY_FRAME"/>
    </xsl:if>
  </xsl:template>

  <xsl:template name="getFilterOperation">
    <xsl:param name="classifierSec"/>
    <xsl:if test="$classifierSec/child::*[local-name() = 'filter-operation']">
      <xsl:variable name="operationVar">
        <xsl:value-of
                select="normalize-space($classifierSec/child::*[local-name() = 'filter-operation'])"/>
      </xsl:variable>
      <xsl:choose>
        <xsl:when test="contains($operationVar,'match-all-filter')">
          <xsl:value-of select="$OPER_MATCH_ALL"/>
        </xsl:when>
        <xsl:otherwise>
          <xsl:value-of select="$OPER_MATCH_ANY"/>
        </xsl:otherwise>
      </xsl:choose>
    </xsl:if>
  </xsl:template>

  <!-- Function to get classifier action type -->
  <xsl:template name="getActionType">
    <xsl:param name="actionSecParam"/>
    <xsl:variable name="localActionTypeVar">
      <xsl:value-of select="normalize-space($actionSecParam/*[local-name() = 'action-type'])"/>
    </xsl:variable>
    <xsl:choose>
      <xsl:when
              test="$localActionTypeVar = 'pbit-marking' or $localActionTypeVar = 'bbf-qos-cls:pbit-marking'">
        <xsl:value-of select="$A_PBIT_MARKING"/>
      </xsl:when>
      <xsl:when
              test="$localActionTypeVar = 'dei-marking' or $localActionTypeVar = 'bbf-qos-cls:dei-marking'">
        <xsl:value-of select="$A_DEI_MARKING"/>
      </xsl:when>
      <xsl:when
              test="$localActionTypeVar = 'dscp-marking' or $localActionTypeVar = 'bbf-qos-cls:dscp-marking'">
        <xsl:value-of select="$A_DSCP_MARKING"/>
      </xsl:when>
      <xsl:when
              test="$localActionTypeVar = 'scheduling-traffic-class' or $localActionTypeVar = 'bbf-qos-cls:scheduling-traffic-class'">
        <xsl:value-of select="$A_SCHEDULING_TRAFFIC"/>
      </xsl:when>
      <xsl:when
              test="$localActionTypeVar = 'flow-color' or $localActionTypeVar = 'bbf-qos-plc:flow-color'">
        <xsl:value-of select="$A_FLOW_COLOR"/>
      </xsl:when>
      <xsl:when
              test="$localActionTypeVar = 'bac-color' or $localActionTypeVar = 'bbf-qos-plc:bac-color'">
        <xsl:value-of select="$A_BAC_COLOR"/>
      </xsl:when>
      <xsl:when
              test="$localActionTypeVar = 'discard' or $localActionTypeVar = 'bbf-qos-plc:discard'">
        <xsl:value-of select="$A_DISCARD"/>
      </xsl:when>
      <xsl:when
              test="$localActionTypeVar = 'policing' or $localActionTypeVar = 'bbf-qos-plc:policing'">
        <xsl:value-of select="$A_POLICING"/>
      </xsl:when>
      <xsl:when test="$localActionTypeVar = 'pass' or $localActionTypeVar = 'bbf-qos-cls:pass'">
        <xsl:value-of select="$A_PASS"/>
      </xsl:when>
      <xsl:when
              test="$localActionTypeVar = 'rate-limit-frames' or $localActionTypeVar = 'bbf-qos-rc:rate-limit-frames'">
        <xsl:value-of select="$A_RATE_LIMIT"/>
      </xsl:when>
      <xsl:when
              test="$localActionTypeVar = 'policing-traffic-class' or $localActionTypeVar = 'nokia-qos-cls-ext:policing-traffic-class'">
        <xsl:value-of select="$A_PBIT_POLICING_TC"/>
      </xsl:when>
      <xsl:when
              test="$localActionTypeVar = 'count' or $localActionTypeVar = 'nokia-qos-cls-ext:count'">
        <xsl:value-of select="$A_COUNT"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$A_UNKNOWN"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="getInlineFilterType">
    <xsl:param name="matchCriteriaSec"/>
    <xsl:variable name="inlineFilterVar">
      <xsl:if test="$matchCriteriaSec/child::*[local-name() = 'unmetered']">
        <xsl:value-of select="concat($F_UNMETERED ,',')"/>
      </xsl:if>
      <xsl:if test="$matchCriteriaSec/child::*[local-name() = 'flow-color']">
        <xsl:value-of select="concat($F_FLOW_COLOR , ',')"/>
      </xsl:if>
      <xsl:if test="$matchCriteriaSec/child::*[local-name() = 'dscp-range']">
        <xsl:value-of select="concat($F_DSCP_RANGE , ',')"/>
      </xsl:if>
      <xsl:if test="$matchCriteriaSec/child::*[local-name() = 'pbit-marking-list']">
        <xsl:value-of select="concat($F_PBIT_MARKING , ',')"/>
      </xsl:if>
      <xsl:if test="$matchCriteriaSec/child::*[local-name() = 'dei-marking-list']">
        <xsl:value-of select="concat($F_DEI_MARKING , ',')"/>
      </xsl:if>
      <xsl:if test="$matchCriteriaSec/child::*[local-name() = 'untagged']">
        <xsl:value-of select="concat($F_UNTAGGED , ',')"/>
      </xsl:if>
      <xsl:if test="$matchCriteriaSec/descendant::*[local-name() = 'in-pbit-list']">
        <xsl:value-of select="concat($F_IN_PBIT_LIST , ',')"/>
      </xsl:if>
      <xsl:if test="$matchCriteriaSec/descendant::*[local-name() = 'in-dei']">
        <xsl:value-of select="concat($F_IN_DEI , ',')"/>
      </xsl:if>
      <xsl:if test="$matchCriteriaSec/child::*[local-name() = 'protocol']">
        <xsl:choose>
          <xsl:when test="$matchCriteriaSec/child::*[local-name() = 'protocol'] = 'igmp'">
            <xsl:value-of select="concat($F_PROTOCOL_IGMP , ',')"/>
          </xsl:when>
          <xsl:otherwise>
            <xsl:value-of select="concat($F_PROTOCOL_NOT_IGMP , ',')"/>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:if>
      <xsl:if test="$matchCriteriaSec/child::*[local-name() = 'other-protocol']">
        <xsl:value-of select="concat($F_PROTOCOL_NOT_IGMP , ',')"/>
      </xsl:if>
      <xsl:if test="$matchCriteriaSec/child::*[local-name() = 'any-protocol']">
        <xsl:value-of select="concat($F_ANY_PROTOCOL , ',')"/>
      </xsl:if>
      <xsl:if test="$matchCriteriaSec/child::*[local-name() = 'match-all']">
        <xsl:value-of select="concat($F_MATCH_ALL , ',')"/>
      </xsl:if>
    </xsl:variable>

    <xsl:choose>
      <xsl:when test="string-length($inlineFilterVar) &gt; 0">
        <xsl:value-of select="substring($inlineFilterVar,0,string-length($inlineFilterVar))"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$inlineFilterVar"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="getEnhClassifierType">
    <xsl:param name="classifierSec"/>
    <xsl:variable name="enhClsTypeVar">
      <xsl:if test="$classifierSec/child::*[local-name() = 'flow-color']">
        <xsl:value-of select="concat($F_FLOW_COLOR,',')"/>
      </xsl:if>
      <xsl:if test="$classifierSec/child::*[local-name() = 'source-mac-address']">
        <xsl:value-of select="concat($F_EN_SOURCE_MAC,',')"/>
      </xsl:if>
      <xsl:if test="$classifierSec/child::*[local-name() = 'destination-mac-address']">
        <xsl:value-of select="concat($F_EN_DEST_MAC,',')"/>
      </xsl:if>
      <xsl:if test="$classifierSec/child::*[local-name() = 'ipv4']">
        <xsl:value-of select="concat($F_EN_IPV4,',')"/>
      </xsl:if>
      <xsl:if test="$classifierSec/child::*[local-name() = 'ipv6']">
        <xsl:value-of select="concat($F_EN_IPV6,',')"/>
      </xsl:if>
      <xsl:if test="$classifierSec/child::*[local-name() = 'ethernet-frame-type']">
        <xsl:variable name="local_ethernet_frame_type">
          <xsl:value-of select="normalize-space($classifierSec/child::*[local-name() = 'ethernet-frame-type'])"/>
        </xsl:variable>
        <xsl:choose>
          <xsl:when test="$local_ethernet_frame_type = '0'">
            <xsl:value-of select="$F_EN_ETHERNET_FRAME_TYPE_IPV4"/>
          </xsl:when>
          <xsl:when test="$local_ethernet_frame_type = '1'">
            <xsl:value-of select="$F_EN_ETHERNET_FRAME_TYPE_PPPOE"/>
          </xsl:when>
          <xsl:when test="$local_ethernet_frame_type = '2'">
            <xsl:value-of select="$F_EN_ETHERNET_FRAME_TYPE_IPV6"/>
          </xsl:when>
          <xsl:otherwise>
            <xsl:value-of select="$F_EN_ETHERNET_FRAME_TYPE_UNKNOWN"/>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:if>

      <xsl:if test="$classifierSec/child::*[local-name() = 'transport']">
        <xsl:value-of select="concat($F_EN_TRANSPORT,',')"/>
      </xsl:if>
      <xsl:if test="$classifierSec/child::*[local-name() = 'pbit-marking-list']">
        <xsl:value-of select="concat($F_PBIT_MARKING,',')"/>
      </xsl:if>
      <xsl:if test="$classifierSec/child::*[local-name() = 'dei-marking-list']">
        <xsl:value-of select="concat($F_DEI_MARKING,',')"/>
      </xsl:if>
      <xsl:if test="$classifierSec/child::*[local-name() = 'vlans']/child::*[local-name() = 'untagged']">
        <xsl:value-of select="concat($F_UNTAGGED,',')"/>
      </xsl:if>
      <xsl:if test="$classifierSec/child::*[local-name() = 'vlans']/child::*[local-name() = 'tag']/child::*[local-name() = 'in-pbit-list']">
        <xsl:value-of select="concat($F_IN_PBIT_LIST,',')"/>
      </xsl:if>
      <xsl:if test="$classifierSec/child::*[local-name() = 'vlans']/child::*[local-name() = 'tag']/child::*[local-name() = 'in-dei']">
        <xsl:value-of select="concat($F_IN_DEI,',')"/>
      </xsl:if>
      <xsl:if test="$classifierSec/child::*[local-name() = 'ip-common']">
        <xsl:if test="$classifierSec/child::*[local-name() = 'ip-common']/child::*[local-name() = 'dscp-range']">
          <xsl:value-of select="concat($F_DSCP_RANGE,',')"/>
        </xsl:if>
        <xsl:if test="$classifierSec/child::*[local-name() = 'ip-common']/child::*[local-name() = 'dscp']">
          <xsl:value-of select="concat($F_EN_IP_COMMON_DSCP,',')"/>
        </xsl:if>
        <xsl:if test="$classifierSec/child::*[local-name() = 'ip-common']/child::*[local-name() = 'protocol']">
          <xsl:variable name="ipcommon_protocol">
            <xsl:value-of
                    select="normalize-space($classifierSec/child::*[local-name() = 'ip-common']/child::*[local-name() = 'protocol'])"/>
          </xsl:variable>
          <xsl:choose>
            <xsl:when test="$ipcommon_protocol = $PROTOCAL_IGMP_IN_IP_HEAD">
              <xsl:value-of select="concat($F_EN_IP_COMMON_IGMP,',')"/>
            </xsl:when>
            <xsl:otherwise>
              <xsl:value-of select="concat($F_EN_IP_COMMON_NOT_DSCP_DSCPRANGE_IGMP,',')"/>
            </xsl:otherwise>
          </xsl:choose>
        </xsl:if>
      </xsl:if>
      <xsl:if test="$classifierSec/child::*[local-name() = 'protocol']">
        <xsl:variable name="protocol_var">
          <xsl:value-of select="$classifierSec/child::*[local-name() = 'protocol']"/>
        </xsl:variable>
        <!-- enum igmp mld dhcpv4 dhcpv6 pppoe-discovery icmpv6 nd arp cfm dot1x lacp -->
        <xsl:choose>
          <xsl:when test="$protocol_var = 'igmp'">
            <xsl:value-of select="concat($F_PROTOCOL_IGMP,',')"/>
          </xsl:when>
          <xsl:otherwise>
            <xsl:value-of select="concat($F_PROTOCOL_NOT_IGMP,',')"/>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:if>
    </xsl:variable>
    <xsl:choose>
      <xsl:when test="string-length($enhClsTypeVar) > 0">
        <xsl:value-of select="substring($enhClsTypeVar,0,string-length($enhClsTypeVar))"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$enhClsTypeVar"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="getPolicingProfileType">
    <xsl:param name="policingProfileName"/>
    <xsl:variable name="policingProfile" select="//*[
      local-name() = 'policing-profile'
      and parent::*[local-name() = 'policing-profiles' and namespace-uri() = 'urn:bbf:yang:bbf-qos-policing']
      and child::*[local-name() = 'name'] = $policingProfileName
    ]"/>
    <xsl:choose>
      <xsl:when test="$policingProfile/child::*[local-name() ='two-rate-three-color-marker-mef']">
        <xsl:choose>
          <xsl:when
                  test="$policingProfile/child::*[local-name() ='two-rate-three-color-marker-mef']/child::*[local-name() ='color-mode'] = $color-aware">
            <xsl:value-of select="$POLICING_TYPE_TRTCM_MEF_COLOR_AWARE"/>
          </xsl:when>
          <xsl:otherwise>
            <xsl:value-of select="$POLICING_TYPE_TRTCM_MEF_COLOR_BLIND"/>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:when>
      <xsl:when test="$policingProfile/child::*[local-name() ='two-rate-three-color-marker-with-cos']">
        <xsl:value-of select="$POLICING_TYPE_TRTCM_COS"/>
      </xsl:when>
      <xsl:when test="$policingProfile/child::*[local-name() ='two-rate-three-color-marker-mef-with-cos']">
        <xsl:value-of select="$POLICING_TYPE_TRTCM_MEF_COS"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:value-of select="$POLICING_TYPE_STB"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="getCurClassifierNamesByRefFilter">
    <xsl:param name="refFilterName"/>
    <xsl:param name="curSec"/>
    <xsl:for-each
            select="$curSec/policies/policy/classifiers/classifier[normalize-space(filters/ref-filter/name) = $refFilterName]">
      <xsl:value-of select="normalize-space(current()/name)"/>
    </xsl:for-each>
  </xsl:template>

</xsl:stylesheet>
