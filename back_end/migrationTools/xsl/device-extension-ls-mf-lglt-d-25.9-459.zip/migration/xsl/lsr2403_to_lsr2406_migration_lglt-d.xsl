<?xml version='1.0' encoding='utf-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">

    
    <xsl:template match="@* | node()">
        <xsl:copy>
            <xsl:apply-templates select="@* | node()" />
        </xsl:copy>
    </xsl:template>

    <xsl:include href="lsr2403_to_lsr2406_ipfix-caches_lglt-d.xsl" />
    <xsl:include href="lsr2403_to_lsr2406_ipfix_lglt-d.xsl" />
    <xsl:include href="lsr2403_to_lsr2406_nacm_1.xsl" />
    <xsl:include href="lsr2403_to_lsr2406_ct_statistics_1.xsl" />
    <xsl:include href="lsr2403_to_lsr2406_remove_unsecure_algorithms_1.xsl" />
    <xsl:include href="lsr2403_to_lsr2406_multicast_interface_to_host_per_cp_cg_dimension_1.xsl" />
    <xsl:include href="lsr2403_to_lsr2406_qos_pbit_dei_configuring_improvement_1.xsl" />
    <xsl:include href="lsr2403_to_lsr2406_rmtDbg_xgemport_1.xsl" />

</xsl:stylesheet>