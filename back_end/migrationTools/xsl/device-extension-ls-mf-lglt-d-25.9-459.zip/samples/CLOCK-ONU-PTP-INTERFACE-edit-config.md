This macro edit/create the  ptp interface configuration data . 

* Every onu owns its own PTP profile
* One ONU should use one same PTP profile for all the uni ports.

Pre-condition:

Before creating the ptp interface, ptp-profile need to be created.
Input parameters:

* autoneg-status: to enable/disable auto negotiation function on uni interface.
* enable: to enable/disable ptp on uni interface.
* onu-name: the custom name of the onu.
* profile-name: the custom name of the uni ptp profile.It should use one same PTP profile for all uni ports on one ONU.
* profile-type: the spec type of the ptp profile.The allowed values are [g8275.1, ccsa]. It should use same PTP profile type for all uni ports on one ONU.
* uni-name: the custom name of the uni interface.
* uni-port-layer-if-name: the custom name of the uni port layer interface.

