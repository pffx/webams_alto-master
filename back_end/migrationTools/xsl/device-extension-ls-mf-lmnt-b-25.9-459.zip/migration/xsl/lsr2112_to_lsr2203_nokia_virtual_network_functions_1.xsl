<?xml version="1.0" ?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:strip-space elements="*"/>
    <xsl:output method="xml" indent="yes"/>

    <xsl:template match="*">
        <xsl:copy>
        <xsl:copy-of select="@*"/>
        <xsl:apply-templates/>
        </xsl:copy>
    </xsl:template>

    <xsl:template match="*[name() = 'virtual-network-functions'
                    and namespace-uri() = 'http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-virtual-network-function'
                    ]">
    </xsl:template>
     
</xsl:stylesheet>
