<?xml version="1.0" ?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                              xmlns:ipfix="urn:ietf:params:xml:ns:yang:ietf-ipfix-psamp" >
    <xsl:strip-space elements="*"/>
    <xsl:output method="xml" encoding="UTF-8" indent="yes"/>
    <xsl:param name="ipfix_ns" select="'urn:ietf:params:xml:ns:yang:ietf-ipfix-psamp'" />






   <!-- Delete cacheField if underlying ieName is set to an unsupported xpath -->
   <xsl:template match="ipfix:ipfix/ipfix:cache/ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField[
                          ipfix:ieName[
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:up-time' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:total-active-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:run-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:sleep-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:stop-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:zombie-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:active-session' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:cpu-avg-load-1-min' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:cpu-avg-load-5-min' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:cpu-avg-load-15-mins' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-hwio' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-io' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-nice' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-swint' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-unused' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-user' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:buffer-mem-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:free-mem-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:total-mem-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:used-mem-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:available-mem-system' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/nokia-ipfix:username' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/nokia-ipfix:password' or
                                      text()='/ipfix:ipfix/nokia-ipfix:collection-timestamp' or
                                      text()='/ipfix:ipfix/nokia-ipfix:last-message' or
                                      text()='/ipfix:ipfix/nokia-ipfix:cache-sequence-number' or
                                      text()='/ipfix:ipfix/nokia-ipfix:record-type' or
                                      text()='/ipfix:ipfix/nokia-ipfix:delete-flag' or
                                      text()='/ipfix:ipfix/nokia-ipfix:data-presence-indication' or
                                      text()='/ipfix:ipfix/nokia-ipfix:hierarchy-meta-info' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:ipfixVersion' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:destinationAddress' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:destinationPort' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:status' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:bytes' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:messages' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:discardedMessages' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:records' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:templates' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:optionsTemplates' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:transportSessionStartTime' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:transportSessionDiscontinuityTime' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template/ipfix:templateId' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template/ipfix:accessTime' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template/ipfix:templateDataRecords' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template/ipfix:templateDiscontinuityTime' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:name' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:name'
                          ]
   ]"/>



   <!-- Delete cache if the count of the underlying ieNames equals to the count of ieNames that contain
                unsupported xpaths, i.e, not even 1 supported xpath is present in the cache. -->
   <xsl:template match="ipfix:ipfix/ipfix:cache[
                          count(./ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName) > 0 and
                          count(./ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName) =
                          count(./ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName[
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:up-time' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:total-active-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:run-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:sleep-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:stop-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:zombie-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:active-session' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:cpu-avg-load-1-min' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:cpu-avg-load-5-min' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:cpu-avg-load-15-mins' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-hwio' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-io' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-nice' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-swint' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-unused' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-user' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:buffer-mem-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:free-mem-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:total-mem-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:used-mem-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:available-mem-system' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/nokia-ipfix:username' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/nokia-ipfix:password' or
                                      text()='/ipfix:ipfix/nokia-ipfix:collection-timestamp' or
                                      text()='/ipfix:ipfix/nokia-ipfix:last-message' or
                                      text()='/ipfix:ipfix/nokia-ipfix:cache-sequence-number' or
                                      text()='/ipfix:ipfix/nokia-ipfix:record-type' or
                                      text()='/ipfix:ipfix/nokia-ipfix:delete-flag' or
                                      text()='/ipfix:ipfix/nokia-ipfix:data-presence-indication' or
                                      text()='/ipfix:ipfix/nokia-ipfix:hierarchy-meta-info' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:ipfixVersion' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:destinationAddress' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:destinationPort' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:status' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:bytes' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:messages' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:discardedMessages' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:records' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:templates' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:optionsTemplates' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:transportSessionStartTime' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:transportSessionDiscontinuityTime' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template/ipfix:templateId' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template/ipfix:accessTime' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template/ipfix:templateDataRecords' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template/ipfix:templateDiscontinuityTime' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:name' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:name'
                          ])
   ]"/>


   <!-- xsl rule to remove ipfix elements -->
   <xsl:template match="ipfix:ipfix[
                          count(./ipfix:randomize-data-collection) = 0 and
                          count(./ipfix:ipfix-exporting-enable) = 0 and
                          count(./exportingProcess) = 0 and
                          (count(./ipfix:cache) = 0 or
                          count(./ipfix:cache/ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName) > 0 and
                          count(./ipfix:cache/ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName) = count(./ipfix:cache/ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName[
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:up-time' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:total-active-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:run-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:sleep-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:stop-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:zombie-process' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:active-session' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:cpu-avg-load-1-min' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:cpu-avg-load-5-min' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:cpu-avg-load-15-mins' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-hwio' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-io' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-nice' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-swint' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-unused' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:percent-cpu-user' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:buffer-mem-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:free-mem-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:total-mem-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:used-mem-system' or
                                      text()='/hw:hardware-state/hw:component/bbf-hw-resource:resource-data/bbf-hw-resource:available-mem-system' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/nokia-ipfix:username' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/nokia-ipfix:password' or
                                      text()='/ipfix:ipfix/nokia-ipfix:collection-timestamp' or
                                      text()='/ipfix:ipfix/nokia-ipfix:last-message' or
                                      text()='/ipfix:ipfix/nokia-ipfix:cache-sequence-number' or
                                      text()='/ipfix:ipfix/nokia-ipfix:record-type' or
                                      text()='/ipfix:ipfix/nokia-ipfix:delete-flag' or
                                      text()='/ipfix:ipfix/nokia-ipfix:data-presence-indication' or
                                      text()='/ipfix:ipfix/nokia-ipfix:hierarchy-meta-info' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:ipfixVersion' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:destinationAddress' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:destinationPort' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:status' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:bytes' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:messages' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:discardedMessages' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:records' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:templates' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:optionsTemplates' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:transportSessionStartTime' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:transportSessionDiscontinuityTime' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template/ipfix:templateId' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template/ipfix:accessTime' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template/ipfix:templateDataRecords' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:tcpExporter/ipfix:transportSession/ipfix:template/ipfix:templateDiscontinuityTime' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:name' or
                                      text()='/ipfix:ipfix/ipfix:exportingProcess/ipfix:destination/ipfix:name'
                          ]))
   ]"/>

</xsl:stylesheet>