<?xml version="1.0" ?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                              xmlns:cfgNs="urn:ietf:params:xml:ns:netconf:base:1.0"
                              xmlns:sysNs="urn:ietf:params:xml:ns:yang:ietf-system"
                              xmlns:itfNs="urn:ietf:params:xml:ns:yang:ietf-interfaces"
                              xmlns:freqNs="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-conf-clock-frequency" >
<xsl:strip-space elements="*"/>
<xsl:output method="xml" encoding="UTF-8" indent="yes"/>


<!-- check if system region exist and any clock port(freq-port, ssm-in port or ssm-out port) enabled, create the ETSI region node if not -->
<xsl:template match="/cfgNs:config/sysNs:system">
  <xsl:copy>
    <xsl:copy-of select="@*"/>
    <xsl:apply-templates/>
    <xsl:if test="not(./child::*[name()='region'])">
      <xsl:if test="/cfgNs:config/itfNs:interfaces/itfNs:interface/freqNs:clock-freq-port/child::*[name() = 'enable']/text() = 'true' or
                    /cfgNs:config/itfNs:interfaces/itfNs:interface/freqNs:ssm-in/child::*[name() = 'ssm-in-enable']/text() = 'true' or
                    /cfgNs:config/itfNs:interfaces/itfNs:interface/freqNs:ssm-out/child::*[name() = 'ssm-out-enable']/text() = 'true'">
        <xsl:element name="region" namespace="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-ietf-system-aug">
          <xsl:element name="region" namespace="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-ietf-system-aug">
            <xsl:text>etsi</xsl:text>
          </xsl:element>
        </xsl:element>
      </xsl:if>
    </xsl:if>
  </xsl:copy>
</xsl:template>


</xsl:stylesheet>
