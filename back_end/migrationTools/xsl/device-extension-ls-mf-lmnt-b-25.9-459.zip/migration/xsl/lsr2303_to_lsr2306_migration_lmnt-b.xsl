<?xml version='1.0' encoding='utf-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
    
    <xsl:template match="@* | node()">
        <xsl:copy>
            <xsl:apply-templates select="@* | node()" />
        </xsl:copy>
    </xsl:template>

    <xsl:include href="lsr2303_to_lsr2306_ipfix-caches_lmnt-b.xsl" />
    <xsl:include href="lsr2303_to_lsr2306_nacm_1.xsl" />
    <xsl:include href="lsr2303_to_lsr2306_clock_1.xsl" />
    <xsl:include href="lsr2303_to_lsr2306_idefault_confd_dyncfg_init_ext_auth_1.xsl" />

</xsl:stylesheet>