<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:newns="http://tail-f.com/ns/aaa/1.1" version="1.0">
    <xsl:strip-space elements="*"/>
    <xsl:output method="xml" encoding="UTF-8" indent="yes"/>
 
 <xsl:param name="nTemplateNS" select="'http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-template-common'"/>
 <xsl:param name="onusNS" select="'urn:bbf:params:xml:ns:yang:bbf-fiber-onu-emulated-mount'"/>

<!-- default rule -->
    <xsl:template match="*">
        <xsl:copy>
        <xsl:copy-of select="@*"/>
        <xsl:apply-templates/>
        </xsl:copy>
    </xsl:template>


   <xsl:template match="*[name() = 'usage']">
     <xsl:choose>
       <xsl:when test="namespace-uri() = $nTemplateNS  and parent::*[name() = 'interface'] and ancestor::*[name() = 'interfaces']">
       </xsl:when>
       <xsl:otherwise>
          <xsl:copy>
             <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
       </xsl:otherwise>
     </xsl:choose>
   </xsl:template>

  <xsl:template match="*[name() = 'template-common:usage' and parent::*[name() = 'interface'] and ancestor::*[name() = 'interfaces']] "/>

   <xsl:template match="*[name() = 'onus']">
     <xsl:choose>
       <xsl:when test="namespace-uri() = $onusNS  and ./ancestor::*[name()='config']">
       </xsl:when>
       <xsl:otherwise>
          <xsl:copy>
             <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
       </xsl:otherwise>
     </xsl:choose>
   </xsl:template>

</xsl:stylesheet>
