<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:cfgNs="urn:ietf:params:xml:ns:netconf:base:1.0" xmlns:ifNs="urn:ietf:params:xml:ns:yang:ietf-interfaces" version="1.0">
                              
<xsl:strip-space elements="*"/>
<xsl:output method="xml" encoding="UTF-8" indent="yes"/>    

<!-- default rule -->
<xsl:template match="node()|@*">
  <xsl:copy>
    <xsl:apply-templates select="node()|@*"/>
  </xsl:copy>
</xsl:template>

<!-- check if an interface binding more than one gnss component -->
<xsl:template match="*[name() = 'interface']">
  <xsl:choose>
    <xsl:when test="namespace-uri() = 'urn:ietf:params:xml:ns:yang:ietf-interfaces'               and ./child::*[name()= 'type' and text() = 'nokia-if-id:gnss']">
      <xsl:variable name="lay_num" select="count(./child::*[name()='port-layer-if' and namespace-uri() = 'urn:bbf:yang:bbf-interface-port-reference'])"/>
      <xsl:if test="$lay_num &lt;= 1">
        <xsl:copy>
           <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
      </xsl:if>
      <xsl:if test="$lay_num &gt;= 2">
        <wrong-configuration-detected>More than one GNSS component was bound to an interface - Migration failed</wrong-configuration-detected>
        <xsl:comment>xslt warning: More than one GNSS component was bound to an interface, operator need to update first.</xsl:comment>
      </xsl:if>
    </xsl:when>
    <xsl:otherwise>
      <xsl:copy>
        <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- check if more than one interface binding on one gnss component -->
<xsl:template match="*[name() = 'component']">
  <xsl:choose>
    <xsl:when test="namespace-uri() = 'urn:ietf:params:xml:ns:yang:ietf-hardware'                   and ./child::*[name()= 'class' and text() = 'nokia-hwi:gnss-port']">
      <xsl:variable name="val_name" select="child::*[name() = 'name']"/>

      <xsl:choose>
        <xsl:when test="count(/cfgNs:config/ifNs:interfaces/ifNs:interface/child::*[name()='port-layer-if' and text()=$val_name]/..) &gt;= 2">
          <wrong-configuration-detected>More than one interface was bound to the same GNSS component - Migration failed</wrong-configuration-detected>
          <xsl:comment>xslt warning: More than one interface was bound to the same GNSS component, operator need to update first.</xsl:comment>
       </xsl:when>
       <xsl:otherwise>
         <xsl:copy>
           <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
       </xsl:otherwise>
    </xsl:choose>

   </xsl:when>
   <xsl:otherwise>
     <xsl:copy>
       <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
   </xsl:otherwise>
  </xsl:choose>

</xsl:template>

<!-- replace value to clk-ql-dus when pre-value is clk-ql-inv[3,5,6,9] in system clock-->
<xsl:template match="*[name() = 'ssmout-ceiling' and namespace-uri()='http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-conf-clock-frequency']">
  <xsl:choose>
    <xsl:when test="./text() = 'clk-ql-inv3' or ./text() = 'clk-ql-inv5' or ./text() = 'clk-ql-inv6' or ./text() = 'clk-ql-inv9'">
      <ssmout-ceiling xmlns="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-conf-clock-frequency">
        <xsl:text>clk-ql-prs</xsl:text>
      </ssmout-ceiling>
    </xsl:when>
    <xsl:otherwise>
      <xsl:copy-of select="."/>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- replace value to clk-ql-dus when pre-value is clk-ql-inv[3,5,6,9] in clock-freq-port-->
<xsl:template match="*[name() = 'ql-minimum' and namespace-uri()='http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-conf-clock-frequency']">
  <xsl:choose>
    <xsl:when test="./text() = 'clk-ql-inv3' or ./text() = 'clk-ql-inv5' or ./text() = 'clk-ql-inv6' or ./text() = 'clk-ql-inv9'">
      <ql-minimum xmlns="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-conf-clock-frequency">
        <xsl:text>clk-ql-dus</xsl:text>
      </ql-minimum>
    </xsl:when>
    <xsl:otherwise>
      <xsl:copy-of select="."/>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<xsl:template match="*[name() = 'ql-default' and namespace-uri()='http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-conf-clock-frequency']">
  <xsl:choose>
    <xsl:when test="./text() = 'clk-ql-inv3' or ./text() = 'clk-ql-inv5' or ./text() = 'clk-ql-inv6' or ./text() = 'clk-ql-inv9'">
      <ql-default xmlns="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-conf-clock-frequency">
        <xsl:text>clk-ql-stu</xsl:text>
      </ql-default>
    </xsl:when>
    <xsl:otherwise>
      <xsl:copy-of select="."/>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

</xsl:stylesheet>
