<?xml version="1.0" ?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                              xmlns:cfgNs="urn:ietf:params:xml:ns:netconf:base:1.0"
                              xmlns:freqNs="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-conf-clock-frequency">
<xsl:strip-space elements="*"/>
<xsl:output method="xml" encoding="UTF-8" indent="yes"/>    

<!-- ssm out vlan profiles to be removed -->
<xsl:template match="/cfgNs:config/freqNs:clock-ssm-out-vlan-profiles">
</xsl:template>

</xsl:stylesheet>
