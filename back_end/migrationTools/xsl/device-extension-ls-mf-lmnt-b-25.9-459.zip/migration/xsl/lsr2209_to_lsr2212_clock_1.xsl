<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:freq="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-conf-clock-frequency" xmlns:hdNs="urn:ietf:params:xml:ns:yang:ietf-hardware" version="1.0">
<xsl:strip-space elements="*"/>
<xsl:output method="xml" encoding="UTF-8" indent="yes"/>    

<!-- default rule -->
<xsl:template match="node()|@*">
  <xsl:copy>
    <xsl:apply-templates select="node()|@*"/>
  </xsl:copy>
</xsl:template>

<!-- change clock-freq-src-port to clock-freq-port -->
<xsl:template match="*[name() = 'clock-freq-src-port']">
  <xsl:element name="clock-freq-port" namespace="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-conf-clock-frequency">
      <xsl:apply-templates select="node()|@*"/>
  </xsl:element>
</xsl:template>

<!-- remove priority when gnss out -->
<xsl:template match="*[name() = 'priority' and namespace-uri()= 'urn:ietf:params:xml:ns:yang:nokia-conf-clock-ptp' and ./parent::*[name() = 'ptp-port'] and ../preceding-sibling::*[name() = 'type' and text() = 'nokia-if-id:gnss']]">
  <xsl:variable name="portlay" select="../preceding-sibling::*[name() = 'port-layer-if']"/>
  <xsl:variable name="dirValue" select="../../../../hdNs:hardware/hdNs:component/child::*[name() = 'name' and text() = $portlay]/../descendant::*[name() = 'direction']"/>
  <xsl:choose>
    <xsl:when test="$dirValue ='out'"> </xsl:when>
    <xsl:otherwise>
      <xsl:copy>
        <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- NT master-only only configure false -->
<xsl:template match="*[name() = 'master-only' and namespace-uri()='urn:ietf:params:xml:ns:yang:nokia-conf-clock-ptp']">
  <xsl:choose>
    <xsl:when test="./text() = 'false'">
      <xsl:copy-of select="."/>
    </xsl:when>
    <xsl:otherwise>
      <xsl:element name="master-only" namespace="urn:ietf:params:xml:ns:yang:nokia-conf-clock-ptp">
        <xsl:text>false</xsl:text>
      </xsl:element>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- ssm out vlan profiles to be removed -->
<!--xsl:template match="freq:clock-ssm-out-vlan-profiles">
</xsl:template-->

<!-- ptp profile not support master-only -->
<!--xsl:template match="*[name() = 'master-only' and namespace-uri()='urn:ietf:params:xml:ns:yang:nokia-conf-clock-ptp']">
</xsl:template-->

</xsl:stylesheet>
