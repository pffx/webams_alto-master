<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:cfgNs="urn:ietf:params:xml:ns:netconf:base:1.0"
                xmlns:hwNs="urn:ietf:params:xml:ns:yang:ietf-hardware"
                xmlns:nokia-fan="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-fan"
                xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities"  version="1.0">
  <xsl:strip-space elements="*"/>
  <xsl:output method="xml" indent="yes"/>

  <!--remove the value of fan mode -->
  <xsl:template match="//hwNs:hardware/hwNs:component/nokia-fan:fans">
    <xsl:choose>
       <xsl:when test="./nokia-fan:fan-mode">
       </xsl:when>
    </xsl:choose>
  </xsl:template>

 </xsl:stylesheet>
