<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:freq="urn:ietf:params:xml:ns:yang:nokia-conf-clock-frequency" version="1.0">

<xsl:strip-space elements="*"/>
<xsl:output method="xml" encoding="UTF-8" indent="yes"/>

<!-- default rule -->
<xsl:template match="node()|@*">
    <xsl:copy>
        <xsl:apply-templates select="node()|@*"/>
    </xsl:copy>
</xsl:template>

<!-- remove clock-freq-src-port when freq-type is ptp -->
<xsl:template match="*[name() = 'clock-freq-src-port']">
    <xsl:choose>
        <xsl:when test="./child::*[name()='freq-type' and text()='ptp']"> </xsl:when>
        <xsl:otherwise>
            <xsl:copy>
                <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
        </xsl:otherwise>
    </xsl:choose>
</xsl:template>

</xsl:stylesheet>
