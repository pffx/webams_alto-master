<?xml version="1.0" ?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <!-- Identity transform -->
    <xsl:template match="@* | node()">
        <xsl:copy>
            <xsl:apply-templates select="@* | node()"/>
        </xsl:copy>
    </xsl:template>

    <xsl:include href="lsr2506_to_lsr2509_ipfix-caches_lmnt-b.xsl"/>
    <xsl:include href="lsr2506_to_lsr2509_nacm_1.xsl"/>

</xsl:stylesheet>
