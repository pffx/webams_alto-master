This macro modifies the  switch aggregation device topology in the system.

Input parameters:

* adjacent-switch-aggregation-device-name: system hostname of the remote IHUB NE.
* inter-shelf-port-name: param used to represent the local inter-shelf link port.
* switch-aggregation-device-topology: system hostname of the IHUB NE.

