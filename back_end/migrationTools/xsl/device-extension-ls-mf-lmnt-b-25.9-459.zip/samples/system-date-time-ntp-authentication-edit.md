This macro configures a key to be used for NTP authentication.

Input parameters:

* algorithm: digest algorithm to be used
* key: the key itself, it can be specified in 2 formats ( ASCII or HEX )
* key-id: integer positive value locally used to refer to a key

