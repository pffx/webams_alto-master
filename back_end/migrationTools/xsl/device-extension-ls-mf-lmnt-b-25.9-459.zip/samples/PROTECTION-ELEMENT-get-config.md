This macro retrieves the configuration of redundancy protection element.

