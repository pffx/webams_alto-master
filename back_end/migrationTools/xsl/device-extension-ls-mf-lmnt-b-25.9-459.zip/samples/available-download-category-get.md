Retrieves the available downloaded files.

Pre-condition:
some files should be downloaded first

Input parameters:

* download-category-type: Category type

