This macro on SHELF-NE remove intrashelf pon protection, intershelf pon protection.
This macro on LT-NE remove intralt pon protection.

Pre-condition:

protection group has been configured.

Input parameters:

* controlled-cp: protection group configured

