This macro retrieves configuration data of the NT.

Pre-condition:

* configuration data for a component is only retrieved if the component is detected by the system as physically present and its parent component its oper-state is enabled.

Input parameters:

* hw-name: NT name for the respective hardware thats needs to configured.

