This macro configures Dynamic Authorization Client parameters.

Input parameters:

* dac-admin-state: Administrative state of the Dynamic Authorization Client(DAC)
* dac-server-address: The IP address of the Dynamic Authorization Client(DAC).
* dac-server-name: Name of the Dynamic Authorization Client(DAC).
* dac-server-shared-secret: The shared secret known to both the Dynamic Authorization client(DAC) and Dynamic Authorization Server(DAS).

