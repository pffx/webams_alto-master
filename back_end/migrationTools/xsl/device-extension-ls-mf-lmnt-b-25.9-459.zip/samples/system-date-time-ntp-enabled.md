This macro enables or disables NTP on the device. By default NTP is enabled.

Input parameters:

* enabled: True or false depending on whether we want to enable or disable respectively NTP on the device.

