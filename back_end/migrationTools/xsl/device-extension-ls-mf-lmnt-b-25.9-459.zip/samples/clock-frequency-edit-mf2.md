This macro configures the system level frequency  parameters.

Input parameters:

* force-local-reference: set to force the local clock as system reference.
* revert: choose system whether to revert to a higher priority re-validated reference source.
* ssmout-ceiling: maximum QL for frequency output.
* wait-to-restore: set the time that a previously failed input reference must be valid before it will be used, unit is minute.

