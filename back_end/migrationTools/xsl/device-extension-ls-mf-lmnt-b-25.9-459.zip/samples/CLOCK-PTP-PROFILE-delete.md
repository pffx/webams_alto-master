This macro deletes the clock g8275dot1/ccsa ptp profile configuration data . The profile-name should be the exist ptp profile name in the equipment.

Input parameters:

* profile-name: the custom name of the ptp profile.
* profile-type: the spec type of the ptp profile. allowed values are [g8275dot1, ccsa]

