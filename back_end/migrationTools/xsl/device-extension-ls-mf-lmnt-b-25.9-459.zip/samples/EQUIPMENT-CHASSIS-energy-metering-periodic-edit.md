This macro creates energy metering periodic mode in Shelf-NE.

Input parameters:

* enable: enable periodic mode with setting interval length.
* interval-length: the interval length of periodic mode needs to configured.

