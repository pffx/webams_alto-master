This macro removes the radius external authentication from the system.
