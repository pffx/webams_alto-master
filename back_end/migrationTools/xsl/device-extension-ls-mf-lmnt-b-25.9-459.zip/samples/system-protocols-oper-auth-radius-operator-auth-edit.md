This macro configures RADIUS operator authentication parameters.

Prerequisite:

* RADIUS servers must be configured.

Input parameters:

* operator-auth-server1-name: The primary RADIUS authentication server.
* operator-auth-server2-name: The secondary RADIUS authentication server.
* operator-nas-id: NAS-Identifier used in messages towards RADIUS servers.
* operator-nas-ip-address: NAS-IP-Address used in messages towards RADIUS servers. If this parameter is not configured, then the Lightspan Access Node system IP address is filled as nas-ip-address in the RADIUS messages.
* operator-policy-name: Name of the RADIUS operator policy.

