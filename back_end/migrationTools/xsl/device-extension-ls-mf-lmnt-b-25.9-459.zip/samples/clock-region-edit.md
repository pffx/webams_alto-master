This macro configures the system region value, for example: 'etsi' or 'ansi'.
The system region should be configured in advance of clock ports configuration. If you wish to modify the configured system value, all the clock ports should be disabled manually.

Input parameters:

* region: the region value of the NT board.

