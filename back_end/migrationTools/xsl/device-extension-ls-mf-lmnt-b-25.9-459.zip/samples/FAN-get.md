This macro retrieves operational data of a FAN board.

This data provides the operator with information on several aspects of the FAN:

* Identification of the FAN: e.g. model-name.
* State and status of the FAN:	e.g. operational-state.
* Fan speed info data (if supported by the system): value, value-type(rpm), value-scale, value-precision

Pre-condition:

* Operational data for this component is only retrieved if the component is configured and detected by the system as physically present.

Input parameters:

* fan-board-name: When the FAN board name is specified, operational data is retrieved for that FAN board, if omitted, operational data is retrieved for all FAN boards.

