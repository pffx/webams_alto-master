Retrieves the available files and directories for upload. Files are organized to category:

* syslog: syslog file stored localy in the file system
* packet-capture: packet-captured tracer
* ihub-config: configuration files of IHUB-NE
* ihub-syslog: syslog file of IHUB-NE

Pre-condition:
some files are available for syslog upload

Input parameters:

* upload-category-type: Category type

