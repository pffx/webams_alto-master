This macro edit/create the  ptp interface configuration data.

Pre-condition:

* synce/bits interface should be configured firstly to edit its ptp function.
* interface should created with common parameters first, the parameters such as type, remote-interface-hardware-ref, and so on.

Input parameters:

* compensation: the compensation of the  ptp port,unit is ns. For dedicated SFP Clock port, the uplink compensation range is limited with [-16283,16283] due to hardware register limitation.
* enable: to enable/disable ptp.
* interface-name: the name of the interface as configured in synce/bits interfaces.
* priority: the priority of the input ptp.
* profile-name: the custom name of the uni ptp profile.
* profile-type: the spec type of the ptp profile. Allowed values are [g8275dot1, ccsa]

