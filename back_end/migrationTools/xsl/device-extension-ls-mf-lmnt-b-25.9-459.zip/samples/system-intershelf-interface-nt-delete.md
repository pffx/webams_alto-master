This macro deletes the inter-shelf IP interface and related L2 interfaces.


Input parameters:

* interface-name: Name of IP interface

