This macro removes the  switch aggregation device topology in the system.

Input parameters:

* switch-aggregation-device-topolog: hostname of IHUB NE.

