This macro creates the g8275dot1/ccsa ptp profile configuration data.

Input parameters:

* dest-mac-addr-forwardable: the dest-mac-addr-forwardable value of the ptp profile. allowed values are ['forwardable', 'non-forwardable']
* domain: the domain value of the ptp profile.
* master-only: Enable or disable the master-only parameter of the PTP port.Only can be configured on FANT-H and LANT-A.
* profile-name: the custom name of the ptp profile.
* profile-type: the spec type of the ptp profile. allowed values are [g8275dot1, ccsa]
* step-mode: the step-mode value of the ptp profile.

