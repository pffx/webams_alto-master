The macro works for the enable or disable the ssm-in function of frequency source. For LS-FX, SSM-IN port can be on NT, NTIO or uplink Ethernet LT. For LS-MF14/MF8, SSM-IN port can be on NT,LTIO. For LS-MF2, SSM-IN port can be on NT.

Input parameters:

* interface-name: the name of the interface as configured in synce/bits interfaces.
* ssm-in-enable: the ssm-in status of the frequency source(true/false).

