This macro downloads the ztp-certificate file via SCP or SFTP server with username/password based authentication. 

Format of URL: _<protocol>://host[:port]/path_

* protocol: scp or sftp
* host: represent the remote host server
* port: port is optional
* path: the directory on the file system of host server

Pre-condition: relevant file transfer protocol is enabled.

Input parameters:

* host-url: scp or sftp server url.
* password: password
* username: The username that will be used

