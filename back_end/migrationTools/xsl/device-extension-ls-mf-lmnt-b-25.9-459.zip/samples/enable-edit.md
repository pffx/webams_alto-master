This macro enables callhome.

