This macro retrieves operational data of the NT.

* Identification of the NT: e.g. model-name or serial-number.
* The hierarchy of the NT: e.g. how many ports a board contains, or if an SFP has been plugged-in.
* State and status of the NT: e.g. operational-state.
* Information about sensor data (i.e. temperature sensors).
* Information about CPU/memory, system-load.
* Last reset information (type, reason, time).
* Last self test result: value 00:00:00:00 means that no failing tests were observed.


Pre-condition:

* Operational data for a component is only retrieved if the component is detected by the system as physically present and its parent component its oper-state is enabled.

Procedure:

* Retrieve operational data of the NT.

Input parameters:

* hw-name: Name of the hardware in which operational data should be retrieved.

