This macro deletes the IP interface and related L2 interfaces.

Pre-condition:

* The static route must be removed using macro system-inband-ipv6-route-remove. This is not applicable if SLAAC was used.

Input parameters:

* interface-name: Name of IP interface

