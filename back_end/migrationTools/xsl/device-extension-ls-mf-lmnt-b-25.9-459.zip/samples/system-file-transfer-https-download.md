This macro downloads the ztp-certificate file from an HTTPS server.

Format of URL: _https://host[:port]/path

* host: represent the ipaddres of HTTPS server
* port: port is optional (default port is 443)
* path: the directory on the file system of host server

Pre-condition: pinned certificates or EST profile are configured (refer to macro-ids system-certificate-pinned-ca-edit or system-est-client-edit respectively).

Input parameters:

* certificate-list-name: Certificate name, based on the certificate type.
* certificate-type: Certificate type, allowed values are pinned-ca-certs pinned-server-certs or est-certificate-profile.
* host-url: https server url

