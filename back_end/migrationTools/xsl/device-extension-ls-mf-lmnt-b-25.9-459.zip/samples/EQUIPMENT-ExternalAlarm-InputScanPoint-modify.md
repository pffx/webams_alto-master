This macro modify Input-scan-point in Shelf-NE.

Pre-condition:

* The Input-scan-point is created.

Input parameters:

* alarm-severity: alarm severity with critical, indeterminate, major, minor, warning. Only minor/major/critical are supported in hardware. indeterminate/warning will be regarded as minor in hardware.
* alarm-text: alarm name is be set by customer. It should be set with the physical hardware input line.
* input-scan-point: input-scan-point component name.
* output-scan-point: the input-scan-point state is set to output-scan-point list. The output-scan-point list can be none or 1-2 output-scan-point which configured.
* polarity: polarity defines hardware state to alarm state. "normal" is open contact to no-alarm, "inverse" is open contact to alarm-active.

