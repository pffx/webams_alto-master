This macro modifies the LT board admin-state in Shelf-NE.

Pre-condition:

* The LT board is created.

Input parameters:

* admin-state: LT board's administrative permission to provide service
* board-name: The name of LT board

