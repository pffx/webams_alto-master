This macro retrieves the system phase sync status.

