This macro configures the system 1PPS/ToD-out value

Input parameters:

* baud-rate: the baud-rate.
* data-bit: the data bit.
* direction: the direction of 1PPS/ToD.
* parent: the parent.
* parity: the parity mode.
* stop-bit: the stop bit.

