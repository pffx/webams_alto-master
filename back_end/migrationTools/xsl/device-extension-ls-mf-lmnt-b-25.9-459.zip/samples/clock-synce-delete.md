This macro deletes the clock configuration data of a SyncE port. 

* For LS-FX-FANT-G or LS-FX-FANT-H, SyncE port can be on NT, NTIO or uplink Ethernet LT. 
* For LS-FX-FANT-M, SyncE port can be on NT, NTIO or uplink Ethernet LT, but if NTIO is planned, NT uplink QSFP ports cannot work at the same time.
* For LS-MF-LMNT-B, SyncE port can be on NT QSFP ports and SFP ports, but it doesn't support SyncE output with SFP port type.
* For LS-MF-LANT-A, SyncE port can be on NT and NTIO.
* For LS-MF-LBNT-A, SyncE port can be on NT and NTIO, but if NTIO is planned, NT uplink QSFP ports cannot work at the same time.

Pre-condition:

* The Interface-Name should be the exist port name in the equipment.
* For NTIO uplink ports, SyncE sources should be configured with different NT mapping with redundancy NTs protection.  
  * FNIO-A  A/A mode ports mapping, c1/c2/c3/c4 - NTA, c5/c6/c7/c8 -NTB.
  * FNIO-E  A/A mode ports mapping, c1/c2/c5/c6 - NTA, c3/c4/c7/c8 -NTB. FNIO-E A/S mode, only c1/c2/c5/c6 ports are available.
  * LTIO-A only suports A/S mode.
  * LTIO-B  A/A mode ports mapping, c1/c2 - NTB, c3/c4 -NTA.  LTIO-B A/S mode, only c1/c2 ports are available and work with load-shared mode.

Input parameters:

* interface-name: the name of the interface, for sfp/sfp+ port on NT is like 1/1/[1...4], for qsfp port on NT is like l/1/c1/[1...4], for port on NTIO is like 1/6/[1...8]. For port on uplink Ethernet LT, it can be any string value.

