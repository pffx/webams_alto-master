This macro retrieves the system status clock frequency data.

