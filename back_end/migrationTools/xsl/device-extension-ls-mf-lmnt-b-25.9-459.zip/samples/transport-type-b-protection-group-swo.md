This macro request manual protection group switchover

Pre-condition:

protection group has been configured.

Input parameters:

* controlled-cp: protection group represented by a channel-pair object with 2 channel-termination attributes
* olt: host name of olt
* olt-infrastructure-name: current active channel termination location

