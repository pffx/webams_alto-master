This macro deletes a LT board in Shelf-NE.

Input parameters:

* board-name: The name of LT board

