This macro modifies the redundancy protection group.

Input parameters:

* admin-status: The administration status of redundancy protection group.Value "LOCK","UNLOCK" can be chosen.
* protection-group-name: The name of protection group.The default value is "NT-Protection".

