This macro retrieves the external authentication options of users on the system.
