This macro allows to configure simplex or duplex chassis working mode in Shelf-NE.

The default is duplex.  

When configuring simplex mode, one still has the freedom to choose in which one of the two NT-slots in a shelf/chassis one will insert the single NT-card, and this NT-card will still become fully operational in any of these two NT-slots.  (And therefore the autoconfiguration SW of NT-cards still plan an NT-card in each NT-slot, and this being reflected in configuration management, even in simplex mode.)  But, in simplex mode, by definition one expects only one NT-card in a shelf, and then assures no alarms will be generated if only one NT-card is actually present. 

Redundancy between NT-cards requires two NT-cards.  By default the working mode is duplex, and also by default redundancy/protection-group is enabled.  If one changes to simplex mode and only one NT-card in the shelf, one should then also disable the protection-group to avoid the latter’s alarm will be raised.

Pre-condition:

* By default chassis works in duplex working mode.

Input parameters:

* chassis-working-mode: chassis working mode needs to configured.

