This macro deletes Output-scan-point in Input-scan-points.

Input parameters:

* input-scan-point: input-scan-point name.
* output-scan-point: output-scan-point name.

