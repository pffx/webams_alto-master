This macro removes the olt device topology in the system.


Input parameters:

* olt-device-topology: hostname of LT-NE.

