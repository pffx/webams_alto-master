This macro on SHELF-NE get operational data of intrashelf pon protection, intershelf pon protection from odb.
This macro on LT-NE get operational data of intralt pon protection from odb.

Pre-condition:

protection group has been configured.

Input parameters:

* controlled-cp: protection group configured

