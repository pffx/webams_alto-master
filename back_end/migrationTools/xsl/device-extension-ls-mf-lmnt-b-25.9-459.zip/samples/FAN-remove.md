This macro deletes FAN board in Shelf-NE.

Input parameters:

* board-name: The name of FAN board

