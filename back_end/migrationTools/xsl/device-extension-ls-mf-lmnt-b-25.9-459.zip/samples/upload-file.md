This macro uploads the packet-capture file to a sftp, ftp or scp server with username/password based authentication.


Pre-condition: relevant file transfer protocol is enabled and capture file available.

Input parameters:

* password: password
* sftp-ftp-scp-url: sftp ftp or scp server url
* username: username
* zip-format: compression format

