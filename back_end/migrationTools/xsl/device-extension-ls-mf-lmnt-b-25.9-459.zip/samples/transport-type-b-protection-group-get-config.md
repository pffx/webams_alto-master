This macro on SHELF-NE retrieve intrashelf pon protection configuration, intershelf pon protection configuration.
This macro on LT-NE retrieve intralt pon protection configuration.

Pre-condition:

protection group has been configured.

Input parameters:

* controlled-cp: protection group configured

