This macro creates energy metering total mode in Shelf-NE.

Input parameters:

* enable: enable total mode.

