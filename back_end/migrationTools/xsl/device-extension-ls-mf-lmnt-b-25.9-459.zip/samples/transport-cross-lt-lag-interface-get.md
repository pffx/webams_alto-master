This macro retrieves operational data of cross-LT LAG interface.

Input parameters:

* cross-lt-lag-name: Cross-LT lag interface name.This parameter is used to derive the cross-lt lag interface name.

