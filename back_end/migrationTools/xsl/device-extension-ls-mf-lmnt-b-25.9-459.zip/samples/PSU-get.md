This macro retrieves operational data of a PSU board.

This data provides the operator with information on several aspects of the PSU:

* Identification of the PSU: e.g. model-name.
* State and status of the PSU:	e.g. operational-state.
* Power metering data (if supported by the system): voltage (in 0.1 V), current (in 0.1 A), power (in 0.1 W), power mode (depending on the system, one of AC/DC/BAT/RFT-V)
* MF-14 and FX could get detailed power sensor data by "show hardware-state component sensor-data" .

Pre-condition:

* Operational data for this component is only retrieved if the component is configured and detected by the system as physically present.

Input parameters:

* psu-board-name: When the PSU board name is specified, operational data is retrieved for that PSU board, if omitted, operational data is retrieved for all PSU boards.MF2 doesn't support power-metering.

