This macro configures the system 1PPS/ToD-out interface.
The SMA port 1PPS output need to be enabled with specified interface binding.

Pre-condition:
The hardware component should be created before 1PPS/ToD interface created.
Input parameters:

* enable: enable/disable of the 1PPS/ToD-out interface.
* hardware-component-name: the name of the 1PPS/ToD hardware component, should be configured by default xml.
* interface-name: the name of the interface as configured in 1PPS/ToD interfaces.

