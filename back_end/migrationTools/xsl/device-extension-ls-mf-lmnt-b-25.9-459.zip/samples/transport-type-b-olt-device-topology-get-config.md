This macro retrieves the olt device topology in the system.

Input parameters:

* olt-device-topology: hostname of the LT NE.

