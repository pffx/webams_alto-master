This macro downloads the ztp-certificate file via SFTP or SCP protocol, by making use of the generated ssh-key for file transfer. 

Format of URL: _<protocol>://host[:port]/path_

* protocol: sftp or scp
* host: represent the remote host server
* port: port is optional
* path: the directory on the file system of host server

Pre-condition: relevant file transfer protocol is enabled and ssh-key is configured.

Input parameters:

* host-url: sftp or scp server url
* ssh-key-type: Algorithm of ssh-key, allowed values is ssh-rsa, ssh-dss and ecdsa-sha2-nistp256
* username: The username that will be used

