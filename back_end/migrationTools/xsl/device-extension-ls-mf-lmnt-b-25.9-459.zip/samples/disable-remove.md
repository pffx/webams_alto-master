This macro disables callhome.

