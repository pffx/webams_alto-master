This macro retrieves NT redundancy protection element state.

