This macro retrieves the Dynamic Authorization Client statistics

Prerequisite:

* Dynamic Authorization Client configuration must be present.

Input parameters:

* dac-server-name: Name of the Dynamic Authorization Client(DAC).

