This macro retrieves periodic data of energy consumption.

* Identification of the energy mode.
* Periodic interval-length
* enable or disable for periodic energy measurement

Pre-condition:

* Operational data for a component is only retrieved if period mode is enable and interval length timeout.

