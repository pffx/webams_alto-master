This macro on SHELF-NE configures intrashelf pon protection between different LTs, intershelf pon protection between different LTs of different shelves.
This macro on LT-NE configures intralt pon protection between different PON ports.

Before the creation of type-B protection group, the secondary channel termination should have no configuration data. 

Pre-condition:

It should be possible to create type-b protection group in following cases:

* Primary Channel termination has been created, providing service. Secondary Channel Termination can be added without impacting the running service on Primary Channel Termination. 
* Both Primary Channel Termination and Secondary Channel Termination have not been created.

Input parameters:

* control: identity used to denote that type-b protection is revertive, non-revertive or disabled, only non-revertive supported.
* controlled-cp: protection group represented by a channel-pair object with 2 channel-termination attributes
* olt-first: host name of first olt with intrashelf or host name of olt with intralt
* olt-infrastructure-name-first: first channel termination location
* olt-infrastructure-name-paired: paired channel termination location
* olt-paired: host name of paired olt with intrashelf or host name of olt with intralt
* role-first: first channel termination role
* role-paired: paired channel termination role

