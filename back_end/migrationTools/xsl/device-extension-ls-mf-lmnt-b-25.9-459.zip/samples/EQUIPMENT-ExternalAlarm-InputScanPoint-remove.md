This macro deletes Input-scan-point in alarm-port-input-scan-point.

Pre-condition:

* The Input-scan-point is created.

Input parameters:

* input-scan-point: input-scan-point name.

