This macro removes Dynamic Authorization Client parameters.

Prerequisite:

* Dynamic Authorization Client parameters must exist.

Input parameters:

* dac-server-name: Name of the Dynamic Authorization Client(DAC).

