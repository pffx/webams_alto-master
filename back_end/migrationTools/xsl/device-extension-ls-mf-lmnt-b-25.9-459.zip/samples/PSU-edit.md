This macro creates PSU board in Shelf-NE.

In order to be able to retrieve operational data of a PSU, the PSU board shall be configured.



Input parameters:

* board-model-name: The model name of PSU board
* board-name: The name of PSU board
* slot-name: The slot name of PSU board

