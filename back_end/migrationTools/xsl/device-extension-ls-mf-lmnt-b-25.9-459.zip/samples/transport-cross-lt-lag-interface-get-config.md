This macro retrieves configuration data of cross-LT LAG interface.

Input parameters:

* cross-lt-lag-name: Cross-LT Lag interface name.This parameter is used to derive the cross-lt lag interface name.

