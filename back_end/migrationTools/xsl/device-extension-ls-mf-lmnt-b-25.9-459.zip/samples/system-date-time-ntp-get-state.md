Retrieves the device's current NTP state with respect to time sources.

