This macro retrieves the system ptp sync status.

