This macro starts capturing mirrored packets using an internal vlan interface.
If a filter is provided, only packets matching the filter are captured.
If a parameter is not explicitely indicated, default values will be used, except for file-upload parameters.
By default capture happens on a single pcap file and stops once given size is reached, but this can be changed via parameters num-capture-files and enable-file-rotation.
If file-rotation is enabled, capture will continue until manually stopped, or an error happens and system stops the capture.
If timeout occurs, capture will be stopped, independently from other parameters.
If file-upload parameters specified, capture file(s) will be uploaded as soon as they are ready.


Pre-condition:

* Mirroring already configured and enabled, otherwise capture will be empty.
* num_capture_files * capture_file_size < 250
* valid file-upload parameters if provided


Input parameters:

* capture_file_size: 
* enable_file_rotation: 
* filter: 
* num_capture_files: 
* sftp_upload_folder_url: 
* timeout: 
* upload_password: 
* upload_username: 
* vlan: 

