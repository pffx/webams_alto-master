This macro removes a static NTP server.

Input parameters:

* ntp-server-name: Name of NTP server

