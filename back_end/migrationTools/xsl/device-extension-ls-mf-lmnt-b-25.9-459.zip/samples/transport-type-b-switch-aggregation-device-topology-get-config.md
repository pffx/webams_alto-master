This macro retrieves the  switch aggregation device topology in the system.

Input parameters:

* switch-aggregation-device-topolog: system hostname of the Ihub NE.

