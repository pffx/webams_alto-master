This macro sets the system date and time.

Pre-condition: NTP must be disabled using the system-date-time-ntp-enabled-edit macro.

Input parameters:

* current-datetime: The current system date and time

