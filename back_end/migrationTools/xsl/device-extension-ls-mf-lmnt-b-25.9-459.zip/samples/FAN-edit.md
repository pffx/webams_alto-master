This macro creates FAN board in Shelf-NE.


Input parameters:

* board-model-name: The model name of FAN board
* board-name: The name of FAN board
* slot-name: The name of FAN Slot

