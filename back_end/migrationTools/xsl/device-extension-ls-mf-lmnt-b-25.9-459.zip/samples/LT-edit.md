This macro creates LT board in Shelf-NE.

Input parameters:

* admin-state: LT board's administrative permission to provide service
* board-model-name: The model name of LT board
* board-name: The name of LT board
* slot-name: The name of LT slot

