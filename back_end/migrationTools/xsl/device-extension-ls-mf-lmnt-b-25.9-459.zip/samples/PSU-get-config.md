This macro retrieves configuration data of a PSU board.

Input parameters:

* psu-board-name: When the PSU board name is specified, configuration data is retrieved for that PSU board, if omitted, configuration data is retrieved for all PSU boards.

