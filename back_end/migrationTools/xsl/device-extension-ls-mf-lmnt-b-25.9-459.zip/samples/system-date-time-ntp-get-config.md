This macro retrieves NTP parameters.

