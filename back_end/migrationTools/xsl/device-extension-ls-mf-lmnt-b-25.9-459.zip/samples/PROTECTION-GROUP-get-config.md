This macro retrieves the configuration of redundancy protection group.

Input parameters:

* protection-group-name: 

