This macro configures the system ptp value, include system ptp holdover duration, system holdover clock class,system ptp max-step-removed and system ptp ptp-clock-type.

Input parameters:

* clock-class: specified system PTP holdover clock class (0...255).
* duration: specified system PTP holdover duration, unit is minute (0...2880).
* max-step-removed: specified system ptp max-step-removed value defined in G.8275.1 (0...255).
* ptp-clock-type: specifies ptp device type of this node. currently support boundary clock on FANT-H and LANT-A.

