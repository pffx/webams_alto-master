This macro retrieves total data of energy consumption.

* Identification of the energy mode.
* Total mode enable/disable

Pre-condition:

* Operational data for a component is only retrieved if total mode is enable.

