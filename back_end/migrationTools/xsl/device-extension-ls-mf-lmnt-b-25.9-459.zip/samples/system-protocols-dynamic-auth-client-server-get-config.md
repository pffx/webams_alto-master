This macro retrieves configuration data of Dynamic Authorization Client parameters.

