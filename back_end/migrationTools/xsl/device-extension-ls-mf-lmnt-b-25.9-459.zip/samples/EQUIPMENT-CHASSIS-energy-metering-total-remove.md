This macro deletes energy metering total mode in Shelf-NE.

Pre-condition:

* The  energy metering total mode is created.

