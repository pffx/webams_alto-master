This macro deletes energy metering periodic mode in Shelf-NE.

Pre-condition:

* The  energy metering periodic mode is created.

Input parameters:

* interval-length: the interval length of periodic mode needs to configured.

