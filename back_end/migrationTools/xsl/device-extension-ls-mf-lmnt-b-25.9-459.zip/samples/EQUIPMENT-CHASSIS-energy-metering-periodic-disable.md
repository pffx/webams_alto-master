This macro disable or enable energy period mode in Shelf-NE.

Pre-condition:

* The energy period mode is created.

Input parameters:

* enable: enable or disable periodic mode with setting interval length.
* interval-length: the interval length of periodic mode needs to configured.

