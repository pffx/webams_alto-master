This macro starts capturing packets on an external yang interface of type ipForward.
If a filter is provided, only packets matching the filter are captured.
If a parameter is not explicitely indicated, default values will be used, except for file-upload parameters.
By default capture happens on a single pcap file and stops once given size is reached, but this can be changed via parameters num-capture-files and enable-file-rotation.
If file-rotation is enabled, capture will continue until manually stopped, or an error happens and system stops the capture.
If timeout occurs, capture will be stopped, independently from other parameters.
If file-upload parameters specified, capture file(s) will be uploaded as soon as they are ready.

Pre-condition:

* ip-interface exists on the system
* num_capture_files * capture_file_size < 250
* valid file-upload parameters

Input parameters:

* capture_file_size: 
* enable_file_rotation: 
* filter: 
* ip_interface: 
* num_capture_files: 
* sftp_upload_folder_url: 
* timeout: 
* upload_password: 
* upload_username: 

