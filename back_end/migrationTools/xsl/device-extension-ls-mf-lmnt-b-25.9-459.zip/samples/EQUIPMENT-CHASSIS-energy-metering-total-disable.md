This macro disable or enable energy total mode in Shelf-NE.

Pre-condition:

* The energy total mode is created.

Input parameters:

* enable: enable or disable total mode.

