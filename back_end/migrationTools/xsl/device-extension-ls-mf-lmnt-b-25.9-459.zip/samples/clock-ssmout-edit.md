The macro works for the enable or disable the ssm-out port. For LS-FX, SSM-OUT port can be on NT, NTIO or uplink Ethernet LT. For LS-MF14/MF8, SSM-OUT port can be on NT,LTIO. For LS-MF2, SSM-in port can be on NT.

Input parameters:

* interface-name: the name of the interface as configured in synce/bits interfaces.
* ssm-out-enable: the ssm-out status of the frequency source(true/false).

