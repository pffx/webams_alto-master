This macro retrieves configuration data of the RADIUS operator authentication parameters.

