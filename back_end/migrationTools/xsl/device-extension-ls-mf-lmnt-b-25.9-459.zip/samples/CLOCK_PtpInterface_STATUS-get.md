This macro retrieves the interface's ptp status clock tod data.

Input parameters:

* interface-name: the name of the interface as configured in synce/bits interfaces.

