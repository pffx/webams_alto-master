This macro configures a static NTP server.

Input parameters:

* key-id: reference to authentication key
* maxpoll: Maximum poll intervals for NTP messages
* minpoll: Minimum poll intervals for NTP messages
* ntp-server-ip-address: Both IPv4 and IPv6 addresses are supported.
* ntp-server-name: Name of NTP server
* ntp-server-port: The port number of the NTP server

