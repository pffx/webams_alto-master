This macro creates the inter-shelf IP interface and related L2 interfaces.

Input parameters:

* interface-name: Name of IP interface
* vlan-id: Value of vlan-id

