This macro removes RADIUS operator authentication parameters.

Prerequisite:

* RADIUS operator authentication parameters must exist.

Input parameters:

* operator-policy-name: Name of the RADIUS policy.

