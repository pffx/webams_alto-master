This macro modifies the control status of redundancy protection element, which will impact to all related protection group.

Input parameters:

* control-status: The control status of protection element.
* hardware-reference: The control status of protection element.

