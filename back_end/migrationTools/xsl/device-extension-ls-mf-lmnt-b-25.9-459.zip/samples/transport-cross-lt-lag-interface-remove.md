This macro removes a cross-lt LAG interface.

Pre-condition: 

The cross-lt LAG interface has to exist and is not referenced by other objects, e.g. by VLAN sub-interfaces.


Input parameters:

* cross-lt-lag-name: Cross-LT lag interface name.

