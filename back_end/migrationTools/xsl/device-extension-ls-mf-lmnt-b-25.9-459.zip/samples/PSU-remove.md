This macro deletes PSU board in Shelf-NE.

Input parameters:

* board-name: The name of PSU board

