This macro configures the external authentication options of users on the system.
If the user does not exist in the system and the external authentication is enabled then the authentication and authorization will be performed by the radius server.
For the locally created users the parameter ext-auth-enabled in the users profile should be enabled.
External authentication is applicable only for CLI sessions.

Pre-condition:

* To enable the external authentication the radius server and cli-session-policy must be configured (refer to RADIUS and operator authentication parameters chapters).

Note:

* To change the fallback option the external authentication must be enabled.

Input parameters:

* auth-enabled: Enables or disables the user external authentication throughout a RADIUS server.
* fallback-to-local: In case the RADIUS server is not reachable, fallback to local authentication is performed.

