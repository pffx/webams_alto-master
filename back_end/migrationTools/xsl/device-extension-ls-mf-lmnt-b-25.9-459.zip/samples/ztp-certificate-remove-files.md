This macro removes all downloaded ztp-certificate files from device.
