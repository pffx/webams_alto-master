This macro retrieves configuration working mode of the chassis.

Pre-condition:

* By default Chassis works in duplex working mode.

