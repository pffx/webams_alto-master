This macro modifies the olt device topology in the system.


Input parameters:

* equipment-aggregation-device-name: hostname of the SHELF NE.
* olt-device-topology: hostname of the LT NE.
* olt-slot-id: param used to represent the slot id of the LT NE.
* switch-aggregation-device-name: hostname of the IHUB NE.

