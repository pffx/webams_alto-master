This macro retrieves configuration data of a FAN board.

Input parameters:

* fan-board-name: When the FAN board name is specified, configuration data is retrieved for that FAN board, if omitted, configuration data is retrieved for all FAN boards.

