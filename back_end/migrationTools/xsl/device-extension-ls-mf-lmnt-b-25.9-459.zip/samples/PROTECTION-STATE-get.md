This macro retrieves NT redundancy protection state.

