This macro will self test board.

Pre-condition:

* Component should be physically present and powered-up.

Procedure:

* Reset component and then do selftest and then after finish selftest and then reset component.

Input parameters:

* hw-name: Name of the harware which needs to be selftest.

