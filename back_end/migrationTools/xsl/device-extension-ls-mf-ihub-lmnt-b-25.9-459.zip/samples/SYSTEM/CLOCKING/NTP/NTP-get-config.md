This sample gets a NTP server configuration from aggregation switch.

Pre-condition:

 None
  
Description:  

* It retreives a NTP server configuration from aggregation switch.
