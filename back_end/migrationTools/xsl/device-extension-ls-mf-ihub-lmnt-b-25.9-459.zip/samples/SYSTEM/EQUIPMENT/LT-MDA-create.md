This sample creates a LT MDA provisioning on aggregation switch.
 
Pre-condition:
* Following sample must execute first,
    *None
* Same LT-MDA-SLOT-ID should not be provisioned previously.

Description:  
* It creates a LT MDA provisioning on aggregation switch.
