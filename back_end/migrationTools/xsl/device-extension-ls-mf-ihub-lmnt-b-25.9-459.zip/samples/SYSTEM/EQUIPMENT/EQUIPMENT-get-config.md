This sample retrieves Equipment provisioning configuration on aggregation switch.

Pre-condition:
* Following sample must execute first,
   equipment-lt-mda-create or equipment-ntio-mda-create
* MDA-SLOT-ID should be provisioned.

Description:  
* It retrieves equipment provisioning configuration on aggregation switch.
