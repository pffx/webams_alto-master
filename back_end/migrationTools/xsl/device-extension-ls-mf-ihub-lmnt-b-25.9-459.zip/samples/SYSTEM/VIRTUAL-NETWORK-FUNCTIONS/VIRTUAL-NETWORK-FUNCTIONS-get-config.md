Thiss sample gets virtual-network-functions that is used for cross shelf.
Pre-condition:
* Following sample must execute first,
    1) system-virtual-network-functions-create
Description:
* It gets virtual-network-functions used for cross shelf.
