This sample modifies the ecdsa key for the user configuration.

Pre-condition:

* Following sample must execute first,
    1) system-user-profile-create
	
* ECDSA Key must be configured in the above sample.
