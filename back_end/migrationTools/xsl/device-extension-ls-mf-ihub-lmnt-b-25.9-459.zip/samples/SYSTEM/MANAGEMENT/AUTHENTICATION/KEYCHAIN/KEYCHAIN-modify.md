This sample modifies Keychain configs.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-keychain-create

Description:

* It modifies the keychain configs.
