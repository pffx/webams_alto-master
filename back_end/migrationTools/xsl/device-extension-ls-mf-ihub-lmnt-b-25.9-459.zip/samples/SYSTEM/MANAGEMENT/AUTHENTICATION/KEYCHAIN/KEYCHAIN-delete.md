This sample deletes Keychain.

Description:

* It deletes Keychain under system security.
