This sample gets operational status of Keychain in system security.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-keychain-create.

Description:

* It gets state data of Keychain.

