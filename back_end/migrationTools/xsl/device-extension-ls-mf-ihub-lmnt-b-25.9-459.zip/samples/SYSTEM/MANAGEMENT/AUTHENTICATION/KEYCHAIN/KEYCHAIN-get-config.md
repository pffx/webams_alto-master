This sample gets configurations of keychain in system security.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-keychain-create

Description:

* It gets configurations of keychain.

