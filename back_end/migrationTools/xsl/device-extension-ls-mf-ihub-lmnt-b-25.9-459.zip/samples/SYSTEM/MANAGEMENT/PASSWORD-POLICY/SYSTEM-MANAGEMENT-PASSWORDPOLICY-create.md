This sample updates Password Policy configuration Rules.
The system shall support a configurable password policy to define the minimum length of the password, history-size, the least number of digital numbers, the least number of special characters and define if both upper- and lower-case alphabetic characters shall or shall not be present. It is possible to restore all the password-policy elements to their default values by deleting the system-security password-policy or delete one single element.

Pre-condition:

* Only a user who belongs to an admin group can change the password policy and can restore the default values.

* Users who do not belong to admin group are allowed only to read the password policy.


