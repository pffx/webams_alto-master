This sample retreives the password policy rules.

This sample provides configured information on password policy rules such as

*Password aging - Max age in days allowed for passwords.

*Password history size -  New password to match against previous ones (number of entries)

*allow-user-name- flag to set of username is allowed as part of password

*minimun required lowercase,special,uppercase and numeric characters for password configuration
