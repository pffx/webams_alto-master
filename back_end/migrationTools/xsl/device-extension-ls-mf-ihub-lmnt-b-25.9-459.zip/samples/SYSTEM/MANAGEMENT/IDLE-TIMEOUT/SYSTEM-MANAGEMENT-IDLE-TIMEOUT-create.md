This sample configures the idle timeout for console, Telnet, SSH, and FTP sessions before 
the session is terminated by the system.

The idle timeout functionality is applicable only for console login session and not for netconf login sessions.
 

Pre-condition:

* By default, each idle console , Telnet,SSH, or FTP session times out after 30 minutes of 
  inactivity.
  
* Users who do not belong to admin group are allowed only to read and not configure the idle-timeout.

