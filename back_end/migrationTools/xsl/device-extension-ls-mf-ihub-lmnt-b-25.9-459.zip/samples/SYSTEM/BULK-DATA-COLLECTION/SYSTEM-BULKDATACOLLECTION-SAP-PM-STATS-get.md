Retrieve SAP PM statistics 

Pre-condition:

Following sample should be executed first

* system-bulk-data-collection-sap-pm-enablestats-create

Description :

* This sample retrieves SAP PM statistics.

Only the following attributes will be exported using IPFIX.

|                  |           |                    |                 |            |
|------------------|-----------|--------------------|-----------------|------------|
| SERVICE ID       |  SAP ID   |   INTERVAL NUMBER  |  SAP OPERSTATE  | TIMESTAMP  |
| MEASURED TIME    |  IN PKTS  |   IN OCTETS        |  OUT PKTS       | OUT OCTETS |
| INVALIDDATA FLAG |           |                    |                 |            |

:SAP Stats PM

