Enables assist-open-ring configuration at ring-level
 
Pre-condition:

* The Major Ring-Ids provided as input must already exist in the aggregation switch.
    
Description:  

* To support open-ring type of network deploaymeney model this sample is mandatory in aggregataion switch
* The below configurations are needed in Aggregation Switch inorder to co-ordinate with the peer devices in the network,       which deploys open-ring.
* eth-ring-raps-store-fwd -This parameter when enabled will allow the erps application to store and forward the ERPS control   raps packets(NR-RB) that is being received via the peer node.Default value is false.
* eth-ring-list -fwd-raps-neighbour-rpl-end and igmp-snoop-umc-ring-flood will be applicable for the ring-ids provided here as input.
* fwd-raps-neighbour-rpl-end -This parameter when enabled in rpl-neighbor node, will allow the erps application to receive     the nrrb packet via the blocked rpl neighbor port and forward it to the peer nodes.Default value is false.
* igmp-snoop-umc-ring-flood -This parameter when enabled allows the erps application to flood UMC packets to eth-ring sap(s)   as well as  non-ring regular saps, in igmp-snooping enabled ethring services.Default value is false.
