This sample retrieves ihub system level assist-open-ring all ring level configuration.
 
Pre-condition:
 None

* It retrieves ihub system level assist-open-ring erps configuration from aggregation switch.
