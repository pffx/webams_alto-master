Disables assist-open-ring configuration at ring-level
 
Pre-condition:
None


Description:

* It deletes the ring level erps configurations in Aggregation Switch.
* eth-ring-raps-store-fwd -This parameter when deleted will not store the raps packets(NR-RB) received via peer node.
* fwd-raps-neighbour-rpl-end -This parameter when deleted will not process the nrrb packet received via the blocked            rpl-neighbor port for the ring-ids provide as input.
* igmp-snoop-umc-ring-flood -This parameter when deleted allows the erps application to flood UMC packets only to the          eth-ring sap(s) and not via the non-ring regular saps, present in the igmp-snooping enabled ethring services for which the ring-ids provide as input.

