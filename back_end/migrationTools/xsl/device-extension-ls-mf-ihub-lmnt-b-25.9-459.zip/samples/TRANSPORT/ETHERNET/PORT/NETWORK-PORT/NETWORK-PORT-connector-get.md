This sample retrieves network port operational data.
 
Pre-condition:

* Following sample must execute first,
    1) transport-ethernet-port-network-port-connector-create

Description:  

* It retrieves network port operational data.
