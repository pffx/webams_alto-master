This sample creates a port configuration.
 
Pre-condition:

* None  
  
Description:  

* This sample provides a context to configure ports

* Available Breakout modes c4-10G, c4-25G, c1-40G, c1-100G, c1-10G and c1-25G.
* Default breakout is none mode where no ports will be created.
* When changing breakout mode to another mode, there should not be any created ports in MD-CLI / configured port in the connector.
* All the existing connector ports should be deleted and then mode change should be performed.
* Connector oper state will be LinkUp if it has valid connector mode, admin up and Transceiver inserted, otherwise connector oper state will be Down.
* In c1-100G/c1-40G/c1-10G/c1-25G mode, 1 port will created internally.
* In c4-10G/c4-25G mode, 4 ports will created internally.

* For breakout c1-40g : NTA ports for connector1(1/1/c1) - 1/1/c1/1 and connector2(1/1/c2) - 1/1/c2/1
                        NTB ports for connector1(1/3/c1) - 1/3/c1/1 and connector2(1/3/c2) - 1/3/c2/1

* For breakout c4-10g : NTA ports for connector1(1/1/c1) - 1/1/c1/1, 1/1/c1/2, 1/1/c1/3, 1/1/c1/4 and 
			                          connector2(1/1/c2) - 1/1/c2/1, 1/1/c2/2, 1/1/c2/3, 1/1/c2/4
                        NTB ports for connector1(1/1/c1) - 1/3/c1/1, 1/3/c1/2, 1/3/c1/3, 1/3/c1/4 and
				     	        	  connector2(1/3/c2) - 1/3/c2/1, 1/3/c2/2, 1/3/c2/3, 1/3/c2/4
					  
* For breakout c1-100g : NTA ports for connector1(1/1/c1) - 1/1/c1/1 and connector2(1/1/c2) - 1/1/c2/1
			 NTB ports for connector1(1/3/c1) - 1/3/c1/1 and connector2(1/3/c2) - 1/3/c2/1
			   					
* For breakout c4-25g : NTA ports for connector1(1/1/c1) - 1/1/c1/1, 1/1/c1/2, 1/1/c1/3, 1/1/c1/4 and
			                          connector2(1/1/c2) - 1/1/c2/1, 1/1/c2/2, 1/1/c2/3, 1/1/c2/4
			   	        NTB ports for connector1(1/1/c1) - 1/3/c1/1, 1/3/c1/2, 1/3/c1/3, 1/3/c1/4 and
		                              connector2(1/3/c2) - 1/3/c2/1, 1/3/c2/2, 1/3/c2/3, 1/3/c2/4

* For breakout c1-10g : NTA ports for connector1(1/1/c1) - 1/1/c1/1 and connector2(1/1/c2) - 1/1/c2/1
                        NTB ports for connector1(1/3/c1) - 1/3/c1/1 and connector2(1/3/c2) - 1/3/c2/1

* For breakout c1-25g : NTA ports for connector1(1/1/c1) - 1/1/c1/1 and connector2(1/1/c2) - 1/1/c2/1
                        NTB ports for connector1(1/3/c1) - 1/3/c1/1 and connector2(1/3/c2) - 1/3/c2/1