This sample modify a port configuration.
 
Pre-condition:

* Following sample must executed first,
    1) transport-ethernet-port-network-port-connector-create
* Port must created.

Description: 
 
* In c1-100G/c1-40G/c1-10G/c1-25G mode, 1 port will created internally.
* In c4-10G/c4-25G mode, 4 ports will created internally.

* For breakout c1-40g : NTA ports for connector1(1/1/c1) - 1/1/c1/1 and connector2(1/1/c2) - 1/1/c2/1
                        NTB ports for connector1(1/3/c1) - 1/3/c1/1 and connector2(1/3/c2) - 1/3/c2/1

* For breakout c4-10g : NTA ports for connector1(1/1/c1) - 1/1/c1/1, 1/1/c1/2, 1/1/c1/3, 1/1/c1/4 and
                                      connector2(1/1/c2) - 1/1/c2/1, 1/1/c2/2, 1/1/c2/3, 1/1/c2/4
                        NTB ports for connector1(1/3/c1) - 1/3/c1/1, 1/3/c1/2, 1/3/c1/3, 1/3/c1/4 and
                                      connector2(1/3/c2) - 1/3/c2/1, 1/3/c2/2, 1/3/c2/3, 1/3/c2/4
 
* For breakout c1-100g : NTA ports for connector1(1/1/c1) - 1/1/c1/1 and connector2(1/1/c2) - 1/1/c2/1
                         NTB ports for connector1(1/3/c1) - 1/3/c1/1 and connector2(1/3/c2) - 1/3/c2/1  
 
* For breakout c4-25g : NTA ports for connector1(1/1/c1) - 1/1/c1/1, 1/1/c1/2, 1/1/c1/3, 1/1/c1/4 and
                                      connector2(1/1/c2) - 1/1/c2/1, 1/1/c2/2, 1/1/c2/3, 1/1/c2/4
                        NTB ports for connector1(1/3/c1) - 1/3/c1/1, 1/3/c1/2, 1/3/c1/3, 1/3/c1/4 and
                                      connector2(1/3/c2) - 1/3/c2/1, 1/3/c2/2, 1/3/c2/3, 1/3/c2/4

* For breakout c1-10g : NTA ports for connector1(1/1/c1) - 1/1/c1/1 and connector2(1/1/c2) - 1/1/c2/1
                        NTB ports for connector1(1/3/c1) - 1/3/c1/1 and connector2(1/3/c2) - 1/3/c2/1

* For breakout c1-25g : NTA ports for connector1(1/1/c1) - 1/1/c1/1 and connector2(1/1/c2) - 1/1/c2/1
                        NTB ports for connector1(1/3/c1) - 1/3/c1/1 and connector2(1/3/c2) - 1/3/c2/1



