This sample creates a port configuration.
 
Pre-condition:

* None  

Description:

* This sample provides a context to configure ports & its Ethernet attributes(ie. speed).
* Speed attribute is optional and it is applicable only for non-connector ports. 
* In c1-100G/c1-40G/c1-10G/c1-25G mode, 1 port will created internally.
* In c4-10G/c4-25G mode, 4 ports will created internally.
* For breakout c1-40g : NTA ports for connector1(1/1/c1) - 1/1/c1/1 and connector2(1/1/c2) - 1/1/c2/1
                        NTB ports for connector1(1/3/c1) - 1/3/c1/1 and connector2(1/3/c2) - 1/3/c2/1

* For breakout c4-10g : NTA ports for connector1(1/1/c1) - 1/1/c1/1, 1/1/c1/2, 1/1/c1/3, 1/1/c1/4 and
                                      connector2(1/1/c2) - 1/1/c2/1, 1/1/c2/2, 1/1/c2/3, 1/1/c2/4
                        NTB ports for connector1(1/3/c1) - 1/3/c1/1, 1/3/c1/2, 1/3/c1/3, 1/3/c1/4 and
                                      connector2(1/3/c2) - 1/3/c2/1, 1/3/c2/2, 1/3/c2/3, 1/3/c2/4
 
* For breakout c1-100g : NTA ports for connector1(1/1/c1) - 1/1/c1/1 and connector2(1/1/c2) - 1/1/c2/1
                         NTB ports for connector1(1/3/c1) - 1/3/c1/1 and connector2(1/3/c2) - 1/3/c2/1  
 
* For breakout c4-25g : NTA ports for connector1(1/1/c1) - 1/1/c1/1, 1/1/c1/2, 1/1/c1/3, 1/1/c1/4 and
                                      connector2(1/1/c2) - 1/1/c2/1, 1/1/c2/2, 1/1/c2/3, 1/1/c2/4
                        NTB ports for connector1(1/3/c1) - 1/3/c1/1, 1/3/c1/2, 1/3/c1/3, 1/3/c1/4 and
                                      connector2(1/3/c2) - 1/3/c2/1, 1/3/c2/2, 1/3/c2/3, 1/3/c2/4
* For breakout c1-10g : NTA ports for connector1(1/1/c1) - 1/1/c1/1 and connector2(1/1/c2) - 1/1/c2/1
                        NTB ports for connector1(1/3/c1) - 1/3/c1/1 and connector2(1/3/c2) - 1/3/c2/1

* For breakout c1-25g : NTA ports for connector1(1/1/c1) - 1/1/c1/1 and connector2(1/1/c2) - 1/1/c2/1
                        NTB ports for connector1(1/3/c1) - 1/3/c1/1 and connector2(1/3/c2) - 1/3/c2/1

* For LMNT-B the maximum burst which can be set for port egress rate in restricted to 4095 KiloBytes

