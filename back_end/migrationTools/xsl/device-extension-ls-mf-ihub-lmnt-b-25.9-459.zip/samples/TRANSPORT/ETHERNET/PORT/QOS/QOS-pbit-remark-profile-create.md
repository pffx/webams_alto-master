This sample creates the QoS egress P bits remarking profile configuration.
 
* It creates the QoS egress P bits remarking profile configuration.

Pre-condition:  

* None
