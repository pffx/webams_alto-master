This sample deletes a static/dynamic Link Aggregation Group(LAG) configuration.
 
* It deletes a static/dynamic Link Aggregation Group(LAG) configuration with the LAG-ID.

Pre-condition: 

* Following sample must execute first,
    1) transport-ethernet-lag-port-create
* The LAG must exist with particular LAG-ID.
