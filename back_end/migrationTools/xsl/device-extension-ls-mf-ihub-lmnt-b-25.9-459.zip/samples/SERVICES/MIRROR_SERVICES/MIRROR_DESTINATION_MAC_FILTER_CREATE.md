This sample creates Mirror Destination service with MAC Filter
 
Pre-condition:
* Service name and service id should not exist in any of the other existing services.
* Mac filter created before associating with mirror service.

Description:  
* It associates mirror destination SAP with an MAC FILTER.
