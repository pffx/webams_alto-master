This sample creates Mirror Destination sap
 
Pre-condition:
* Service name and service id should not exist in any of the other existing services.
 
Description:  
* It creates Mirror Destination sap with Uplink NT/NTIO ports.
* It configures a mirror destination SAP on uplink NT/NTIO ports or AI port(1/5/3).
