This sample creates  Mirror Source Port
 
Pre-condition:
* Mirror dest should be already configured.
* Mirror source service name should be same as mirror destination service name.
 
Description:  
* It creates Uplink NT/NTIO ports as Mirror Source.

