This sample delete Port Mirror Source
 
Pre-condition:
* Port as Mirror Source should already present.

Description:  
* It delete Uplink NT/NTIO ports as Mirror Source.

