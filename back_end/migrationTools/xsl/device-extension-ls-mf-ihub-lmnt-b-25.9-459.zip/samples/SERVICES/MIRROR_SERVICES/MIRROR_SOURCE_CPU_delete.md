This sample delete CPU ports as Mirror Source
 
Pre-condition:
* CPU as Mirror Source should already present.
 
Description:  
* It delete CPU ports as Mirror Source.
