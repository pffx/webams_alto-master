This sample creates Mirror Destination service
 
Pre-condition:
* Service name and service id should not exist in any of the other existing services.
  
Description:  
* It creates a Mirror Destination service with unique service name, service id and service vlan.
