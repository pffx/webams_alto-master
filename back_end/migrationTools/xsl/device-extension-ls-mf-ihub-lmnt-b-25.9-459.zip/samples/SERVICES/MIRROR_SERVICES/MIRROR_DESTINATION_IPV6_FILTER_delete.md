This sample delete IPV6 filter association with Mirror Destination SAP.
 
Pre-condition:
* Mirror destination service and sap should present with IPV6 filter associated to sap.

Description:  
* It delete IPV6 filter association with Mirror Destination SAP.
