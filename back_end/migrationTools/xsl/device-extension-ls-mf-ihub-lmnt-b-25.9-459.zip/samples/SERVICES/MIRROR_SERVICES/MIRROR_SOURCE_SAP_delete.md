This sample delete  Mirror SAP Source
 
Pre-condition:
* Mirror source service and sap should be already configured.
 
Description:  
* It delete Mirror Source sap with Uplink NT/NTIO ports.

