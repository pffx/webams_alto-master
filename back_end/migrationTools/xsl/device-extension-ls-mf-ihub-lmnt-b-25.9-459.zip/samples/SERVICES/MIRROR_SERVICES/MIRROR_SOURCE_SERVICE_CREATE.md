This sample creates Mirror Source service
 
Pre-condition:
* Mirror Destination Service must already be configured.
* Mirror source service name should be same as mirror destination service name.

Description:
* It creates a Mirror Source service with similar service name as mirror destination.
