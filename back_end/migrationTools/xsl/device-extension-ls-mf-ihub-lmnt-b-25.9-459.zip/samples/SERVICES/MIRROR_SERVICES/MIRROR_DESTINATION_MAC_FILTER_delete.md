This sample delete MAC filter association with Mirror Destination SAP.

Pre-condition:
* Mirror destination service and sap should present with MAC filter associated to sap.

Description:
* It delete MAC filter association with Mirror Destination SAP.

