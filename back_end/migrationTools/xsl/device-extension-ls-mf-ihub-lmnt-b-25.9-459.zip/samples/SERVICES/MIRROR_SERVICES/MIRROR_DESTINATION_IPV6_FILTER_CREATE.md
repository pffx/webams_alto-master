This sample creates Mirror Destination service with IPv6 Filter
 
Pre-condition:
* Service name and service id should not exist in any of the other existing services.
* IPV6 filter created before associating with mirror service.

Description:  
* It associates mirror destination SAP with an IPv6 filter.
