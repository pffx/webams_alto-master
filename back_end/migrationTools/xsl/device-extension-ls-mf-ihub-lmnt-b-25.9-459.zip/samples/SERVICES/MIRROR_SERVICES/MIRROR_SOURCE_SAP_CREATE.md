This sample creates a SAP Mirror Source
 
Pre-condition:

* Mirror dest should be already configured.
* Mirror source service name should be same as mirror destination service name.
* The service SAP should already be configured. It could be part of either a V-VPLS or a True VPLS service.
 
Description:  

* It creates Mirror Source SAP with Uplink NT/NTIO ports for both ingress and egress direction.

