This sample deletes a SDP service

* It deletes a SDP service.

Pre-condition:

* Following sample must execute first,
    * services-layer2-sdp-create

* Service should exist.
