This sample creates SDP services

* It creates a SDP service.

Pre-condition:
* SDP service id should not exist.
