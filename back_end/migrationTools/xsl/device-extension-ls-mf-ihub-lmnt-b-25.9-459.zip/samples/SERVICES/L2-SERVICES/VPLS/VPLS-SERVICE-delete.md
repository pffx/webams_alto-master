This sample deletes a true VPLS Bridging configuration.

Pre-condition:
* Following sample must execute first,
    * services-layer2-bridge-vpls-create

* It deletes vpls service forwarding configurations in Aggregation Switch
