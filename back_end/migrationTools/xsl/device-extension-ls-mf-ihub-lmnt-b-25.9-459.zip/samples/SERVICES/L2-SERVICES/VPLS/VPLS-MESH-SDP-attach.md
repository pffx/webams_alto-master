This sample creates true VPLS services with Mesh-SDP

* It creates a true vpls service configuration with mesh-sdp enabled.

Pre-condition:
Following sample should be executed first
* services-layer2-bridge-vpls-create
* Before configuring mesh-sdp , SDP service should be created using the following sample:
     1) services-layer2-sdp-create
