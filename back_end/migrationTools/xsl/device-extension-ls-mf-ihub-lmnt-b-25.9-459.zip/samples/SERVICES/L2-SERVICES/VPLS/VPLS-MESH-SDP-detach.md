This sample deletes Mesh-sdp within true VPLS services

* It deletes mesh-sdp configurations within true VPLS services.

Pre-condition:
Following sample should be executed first
* services-layer2-bridge-vpls-create
