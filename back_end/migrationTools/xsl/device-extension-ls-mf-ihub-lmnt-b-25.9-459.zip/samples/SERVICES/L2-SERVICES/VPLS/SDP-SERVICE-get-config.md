This sample retrieves SDP service configuration.

Pre-condition:
* Following sample must execute first,
    * services-layer2-sdp-create

* It retrieves sdp service configuration from aggregation switch.

