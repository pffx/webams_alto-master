This sample modifies SDP service configs

* It modifies a SDP service.
