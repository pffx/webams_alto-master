This sample retrieves SDP service operational status.

Pre-condition:
* Following sample must execute first,
    * services-layer2-sdp-create

* It retrieves sdp service operational state info from aggregation switch.

