This sample retrieves true VPLS service forwarding operational status.

Pre-condition:
* Following sample must execute first,
    * services-layer2-bridge-vpls-create

* It retrieves true vpls service forwarding operational status from aggregation switch.
