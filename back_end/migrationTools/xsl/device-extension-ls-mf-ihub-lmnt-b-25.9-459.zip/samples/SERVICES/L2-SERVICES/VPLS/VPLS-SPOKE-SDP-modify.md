This sample modifies Spoke-SDP configs

* It modifies spoke-sdp configs under VPLS.
