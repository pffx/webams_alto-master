This sample modifies true VPLS forwarding services

Description:
* It modifies true VPLS forwarding services.
