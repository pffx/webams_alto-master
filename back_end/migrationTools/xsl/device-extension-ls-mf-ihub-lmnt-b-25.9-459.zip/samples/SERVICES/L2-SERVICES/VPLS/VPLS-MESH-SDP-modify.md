This sample modifies Mesh-SDP configs

* It modifies mesh-sdp configs under VPLS.
