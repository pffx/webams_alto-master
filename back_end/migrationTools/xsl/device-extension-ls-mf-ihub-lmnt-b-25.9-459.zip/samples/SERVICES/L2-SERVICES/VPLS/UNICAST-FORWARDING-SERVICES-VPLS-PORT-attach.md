This sample creates unicast services with LT/Uplink NT ports
 
* It creates a unicast services Virtual Private LAN Service configuration with LT and Uplink NT ports.

Pre-condition:
Following sample should be executed first
* services-layer2-bridge-vpls-create
