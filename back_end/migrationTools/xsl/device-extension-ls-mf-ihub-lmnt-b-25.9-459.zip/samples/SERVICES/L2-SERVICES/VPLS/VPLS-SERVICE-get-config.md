This sample retrieves true VPLS service forwarding configuration.

Pre-condition:
* Following sample must execute first,
    * services-layer2-bridge-vpls-create

* It retrieves true vpls service forwarding configuration from aggregation switch.
