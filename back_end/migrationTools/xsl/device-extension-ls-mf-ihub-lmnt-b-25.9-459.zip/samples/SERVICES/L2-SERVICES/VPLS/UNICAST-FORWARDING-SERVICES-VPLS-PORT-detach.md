This sample deletes LT/Uplink NT ports within unicast services

* It deletes LT and Uplink NT ports within unicast services Virtual Private LAN Service configuration.

Pre-condition:
Following sample should be executed first
* services-layer2-bridge-vpls-create
