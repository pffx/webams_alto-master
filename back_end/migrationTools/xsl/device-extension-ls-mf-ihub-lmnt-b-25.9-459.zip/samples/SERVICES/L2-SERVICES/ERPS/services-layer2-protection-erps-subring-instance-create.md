This sample creates an ethernet Sub-ring instance on aggregation switch
 
Pre-condition:

* Following sample must execute first,
    * services-layer2-oam-domain-create
	* services-layer2-oam-association-create


Description: 
 
* This sample creates an ethernet Sub-ring instance on agregation switch
