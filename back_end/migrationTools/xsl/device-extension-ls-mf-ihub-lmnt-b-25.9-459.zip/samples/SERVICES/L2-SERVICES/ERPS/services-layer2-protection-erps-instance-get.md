This sample retrieves Ethernet ring instance state data from system
 
Pre-condition:

* Following sample must execute first,
    * services-layer2-protection-erps-instance-create
* Ethernet Ring instance must exist.

Description: 
 
* This sample retrieves the state data of ethernet ring instance from system
