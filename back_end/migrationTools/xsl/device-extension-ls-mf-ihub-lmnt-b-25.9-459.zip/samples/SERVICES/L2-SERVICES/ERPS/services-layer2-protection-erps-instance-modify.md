This sample modifies ethernet ring instance params on aggregation switch
 
Pre-condition:

* Following sample must execute first,
	* services-layer2-protection-erps-instance-create
* Modifying the eth-ring rpl-node parameter mandates the corresponding eth-ring instance to be made admin-state disable        before modifying and to enable the admin-state of the eth-ring instance after modifying.
* Modifying the eth-ring path rpl-end parameter mandates the corresponding eth-ring path instance to be made admin-state       disable before modifying and to enable the eth-ring path admin-state of the eth-ring instance after modifying.

Description: 
 
* This sample modifies ethernet ring instance params on aagregation switch
