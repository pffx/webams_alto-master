This sample deletes the ERPS Path instance from system
 
Pre-condition:

* Following sample must execute first,
    * services-layer2-protection-erps-instance-create
* Ethernet Ring instance must exist.
* Before deleting ERPS instance, the corresponding vvpls where ring instance is referenced should also be deleted

Description: 
 
* This sample deletes ethernet ring path instance from system
