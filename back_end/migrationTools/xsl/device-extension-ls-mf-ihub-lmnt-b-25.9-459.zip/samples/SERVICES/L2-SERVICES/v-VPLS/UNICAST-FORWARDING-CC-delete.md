This sample deletes a unicast services forwarding CC configuration.
 
Pre-condition:
* Following sample must execute first,
    * services-layer2-cross-connect-v-vpls-create
* VPLS Service must exist.

* It deletes unicast services forwarding CC configuration which is typically a v-vpls service in Aggregation Switch
