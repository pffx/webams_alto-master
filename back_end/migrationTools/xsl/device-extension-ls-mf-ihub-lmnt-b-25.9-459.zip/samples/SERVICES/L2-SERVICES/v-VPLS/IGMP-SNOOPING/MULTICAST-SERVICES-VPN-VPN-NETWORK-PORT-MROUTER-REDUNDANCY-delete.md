This sample deletes mrouter-redundancy on multicast services.
