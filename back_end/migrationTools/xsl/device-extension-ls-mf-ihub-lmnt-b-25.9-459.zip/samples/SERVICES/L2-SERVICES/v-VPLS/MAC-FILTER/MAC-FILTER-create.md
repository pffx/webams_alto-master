This sample creates a MAC filter policy configuration on system level.
 
Pre-condition:

* None
Only for frame type ethernet-ii the etype parameter is applicable

  
Description:  

* It creates a MAC filter policies which controls the forwarding and dropping of packets based on MAC matching
criteria. 
