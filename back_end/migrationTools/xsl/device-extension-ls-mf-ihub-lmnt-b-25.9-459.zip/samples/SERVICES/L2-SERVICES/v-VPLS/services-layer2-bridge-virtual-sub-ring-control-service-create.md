This sample creates a service on a Virtual Sub-Ring instance
For Non-Virtual sub-ring instance existing services-layer2-bridge-eth-ring-services-create sample can be used
 
Pre-condition:

* services-layer2-bridge-eth-ring-services-create sample must exist
  
Description:  

* This sample creates a service to forward the RAPS messages over a Virtual Sub-Ring instance
* This sample creates a split-horizon-group 
* Ports which are part of Ethernet ring and added into this service with ERPS RAPS VLAN tag associated with corresponding erps ring-id and split horizon-group group-id . 
