This sample enables mrouter-redundancy on multicast services.

Pre-condition:

* User must configure 2 static m-router to enable this feature.
