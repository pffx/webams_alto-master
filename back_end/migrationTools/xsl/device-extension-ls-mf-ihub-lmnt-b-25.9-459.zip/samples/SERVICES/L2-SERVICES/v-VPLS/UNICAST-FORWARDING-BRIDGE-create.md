This sample creates unicast services forwarding bridging with LT/Uplink NT ports
 
Pre-condition:
* Service name and id should not exist.

Description:  
* It creates a unicast services forwarding bridging Virtual Private LAN Service(v-VPLS) configuration with LT and Uplink NT ports.
* RS-FEC-MODE is supported only for c4-25g and c1-100g breakout.
* Speed attribute is optional and it is applicable only for non-connector ports.
* In c1-100G/c1-40G/c1-10G mode, 1 port will created internally.
* In c4-10G/c4-25G mode, 4 ports will created internally.

* NTA Port : 1/1/1

* NTB Port : 1/3/1

For breakout c1-40g : LTIOA-1 ports for connector1(1/6/c1) - 1/6/c1/1 and connector2(1/6/c2) - 1/6/c2/1
                      LTIOA-2 ports for connector1(1/7/c1) - 1/7/c1/1 and connector2(1/7/c2) - 1/7/c2/1

For breakout c4-10g : LTIOA-1 ports for connector1(1/6/c1) - 1/6/c1/1, 1/6/c1/2, 1/6/c1/3, 1/6/c1/4 and
                                        connector2(1/6/c2) - 1/6/c2/1, 1/6/c2/2, 1/6/c2/3, 1/6/c2/4
                      LTIOA-2 ports for connector1(1/7/c1) - 1/7/c1/1, 1/7/c1/2, 1/7/c1/3, 1/7/c1/4 and
                                        connector2(1/7/c2) - 1/7/c2/1, 1/7/c2/2, 1/7/c2/3, 1/7/c2/4

For breakout c1-100g : LTIOA-1 ports for connector1(1/6/c1) - 1/6/c1/1 and connector2(1/6/c2) - 1/6/c2/1
                       LTIOA-2 ports for connector1(1/7/c1) - 1/7/c1/1 and connector2(1/7/c2) - 1/7/c2/1


For breakout c4-25g : LTIOA-1 ports for connector1(1/6/c1) - 1/6/c1/1, 1/6/c1/2, 1/6/c1/3, 1/6/c1/4 and
                                        connector2(1/6/c2) - 1/6/c2/1, 1/6/c2/2, 1/6/c2/3, 1/6/c2/4
                      LTIOA-2 ports for connector1(1/7/c1) - 1/7/c1/1, 1/7/c1/2, 1/7/c1/3, 1/7/c1/4 and
                                        connector2(1/7/c2) - 1/7/c2/1, 1/7/c2/2, 1/7/c2/3, 1/7/c2/4

For breakout c1-10g : LTIOA-1 ports for connector1(1/6/c1) - 1/6/c1/1 and connector2(1/6/c2) - 1/6/c2/1
                      LTIOA-2 ports for connector1(1/7/c1) - 1/7/c1/1 and connector2(1/7/c2) - 1/7/c2/1


