This sample deletes the control or data service created for Ring instance
 
Pre-condition:

* Following sample must execute first,
    * services-layer2-bridge-eth-ring-services-create
	
* control VPLS service must exist.

* It deletes control or data service created for Ring instance from Aggregation Switch
