This sample creates a service to forward the RAPS as well as data traffic over a Ring instance
 
Pre-condition:

* Service name and id should not exist.

  
Description:  

* This sample creates a service to forward the RAPS messages over a Ring instance
* The sample can be invoked to create a data path service over ring instance
* Ports which are part of Ethernet ring and added into this service with ERPS VLAN tag which acts as control VLAN for these packets 
