This sample retrieves unicast services forwarding operational Status

Pre-condition:

* Following sample must execute first,
    * services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create

* It retrieves unicast services forwarding operational Status
