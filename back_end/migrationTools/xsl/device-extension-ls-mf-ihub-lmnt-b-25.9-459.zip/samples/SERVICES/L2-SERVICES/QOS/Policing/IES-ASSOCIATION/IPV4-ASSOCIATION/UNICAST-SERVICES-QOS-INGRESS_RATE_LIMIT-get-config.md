This sample retrieves the ingress policer configuration at IES service level.
 
Pre-condition:  


* Following sample must execute first,
	1) services-layer3-ipv4-traffic-management-service-policer-create
	2) services-layer3-ipv4-traffic-management-ies-ingress-policer-attach
  
Description:  


* Retrieves the ingress rate limit policer associated to IES service configuration.
