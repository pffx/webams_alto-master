This sample modifies service egress network QoS policy configuration.
 
Pre-condition:


* Following sample must execute first,
    1) services-layer2-traffic-management-service-egress-network-policy-create
 
Description:


* This policy defines the match criteria used to determine the mapping of Flow Class and profile indication to experimental bit(EXP) bits
