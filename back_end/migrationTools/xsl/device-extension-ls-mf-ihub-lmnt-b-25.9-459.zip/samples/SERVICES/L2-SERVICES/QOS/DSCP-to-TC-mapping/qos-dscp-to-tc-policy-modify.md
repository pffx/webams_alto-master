This sample modifies the service ingress access DSCP and PREC to TC QoS policy configuration.
 
Pre-condition:

* Following sample must execute first,
  1) services-layer2-traffic-management-dscp-to-tc-policy-create
* Service Ingress Policy must exist.
