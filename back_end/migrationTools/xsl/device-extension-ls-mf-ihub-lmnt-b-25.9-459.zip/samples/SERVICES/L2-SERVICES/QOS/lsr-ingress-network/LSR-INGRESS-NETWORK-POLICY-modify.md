This sample is used to modify the existing QoS lsr-ingress-network policy.

Pre-condition: 

* None

Description:
 
* This policy defines the match criteria used to determine the mapping of Flow Class and profile indication to experimental bit(EXP) bits
