This sample modifies service ingress network QoS policy configuration.
 
Pre-condition:


* Following sample must execute first,
    1) services-layer2-traffic-management-service-ingress-network-policy-create
 
Description:


* A service ingress network QoS policy defines the match criteria used to determine the Flow Class of each packet, based on the EXP value of the VC label or on the inner P-bit of the L2 payload
