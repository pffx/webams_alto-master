This sample creates service egress network QoS policy configuration.
 
Pre-condition:


* None
 
Description:


* This policy defines the match criteria used to determine the mapping of Flow Class and profile indication to experimental bit(EXP) bits
