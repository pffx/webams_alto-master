This sample deletes service ingress network QoS policy configuration.
 
Pre-condition:


* Following sample must execute first,
    1) services-layer2-traffic-management-service-ingress-network-policy-create
	2) policy should not be associated to any true VPLS service.
 
 
Description:


* Deletes service ingress network QoS policy configuration.
