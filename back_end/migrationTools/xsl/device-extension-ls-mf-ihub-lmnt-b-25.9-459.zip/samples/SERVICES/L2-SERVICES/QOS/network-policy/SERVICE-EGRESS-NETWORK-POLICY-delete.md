This sample deletes service egress network QoS policy configuration.
 
Pre-condition:


* Following sample must execute first,
    1) services-layer2-traffic-management-service-egress-network-policy-create
	2) policy should not be associated to any true VPLS service.
 
 
Description:


* Deletes service egress network QoS policy configuration.
