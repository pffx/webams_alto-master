This sample detaches the egress network policy from true vpls service. 

Pre-condition:


* Following sample must execute first,    
    1) services-layer2-bridge-vpls-create
    2) services-layer2-traffic-management-service-egress-network-policy-create
    3) services-layer2-traffic-management-service-egress-network-policy-attach
 
 
* True VPLS Service with service egress network policy must exist.
 
Description:  
De-associate the egress network policy with true VPLS service configuration.
