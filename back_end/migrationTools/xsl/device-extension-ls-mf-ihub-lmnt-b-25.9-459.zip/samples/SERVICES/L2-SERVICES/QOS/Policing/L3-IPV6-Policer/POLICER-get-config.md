This sample retrieves the configuration of policer with default rate-limit.

Pre-condition:


* Following sample must execute first,
    1) services-layer3-ipv6-traffic-management-service-policer-create

Description:
Retrieves the configuration of  policer with default rate-limit.
