This sample retrives service egress network QoS policy configuration.
 
Pre-condition:


* Following sample must execute first,
    1) services-layer2-traffic-management-service-egress-network-policy-create
 
 
Description:


* Retrives service egress network QoS policy configuration.
