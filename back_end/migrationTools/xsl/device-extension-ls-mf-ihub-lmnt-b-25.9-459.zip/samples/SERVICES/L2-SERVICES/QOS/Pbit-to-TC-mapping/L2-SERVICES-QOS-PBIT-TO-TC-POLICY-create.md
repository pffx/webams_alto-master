This sample creates QoS Service ingress Pbit to TC policy configuration.
 
 
Description:  

* The mapping of packets to a forwarding class can be based on combinations of
  customer QoS markings including IEEE 802.1p bits and TOS precedence. 
* This sample lets user create a Ingress QoS policer policy and associate for each .1p priority value the forwarding class mapping as well as the method that is chosen to classify if the packet is within policy profile or not.
  The method can be based upon policer rates configured or based upon DEI bit alone.  
  This sample also allows user to add a policy entry for .1p [or overwrite ] existing policy entry for .1p for profile-in/out
* The service ingress access QoS policy also serves to classify packets as being either in 
  profile or out-of-profile based on the color-selector configuration:
  1) When the color-selector configuration is set to config-entry-based, then the
    ingress color assignment will happen from the service ingress access QoS policy
    configuration.
	Final Color assignment will be based upon rate limit policy applied on service
  2) When the color-selector configuration is set to packet-dei-based then the ingress
    color assignment will happen based on the value in the packet DEI field. DEI=0
    value in the packet assigns Green color while DEI=1 value in the packet would
    assign Yellow Color.
