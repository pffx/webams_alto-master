This sample retrieves the mapping of Flow Class and profile indication to experimental bit(EXP) bits in the lsr-ingress-network-policy

Pre-condition:

* Following sample must execute first,
  1) services-layer2-traffic-management-lsr-ingress-network-policy-create

Description:

* This sample retrieves the mapping of Flow Class and profile indication to experimental bit(EXP) bits in the lsr-ingress-network-policy.

