This sample retrives service ingress network QoS policy configuration.
 
Pre-condition:


* Following sample must execute first,
    1) services-layer2-traffic-management-service-ingress-network-policy-create
 
 
Description:


* Retrives service ingress network QoS policy configuration
