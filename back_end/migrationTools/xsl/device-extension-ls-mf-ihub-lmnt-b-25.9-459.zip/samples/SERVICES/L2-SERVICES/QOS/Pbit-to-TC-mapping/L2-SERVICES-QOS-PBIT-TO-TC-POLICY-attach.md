This sample applies the Pbit to TC mapping profile on service level.
 
Pre-condition:

* Following sample must execute first,
    1)services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
  	2)services-layer2-traffic-management-pbit-to-tc-policy-create
  
Description:  

* It applies the user-defined Pbit to TC mapping profile on service level.
