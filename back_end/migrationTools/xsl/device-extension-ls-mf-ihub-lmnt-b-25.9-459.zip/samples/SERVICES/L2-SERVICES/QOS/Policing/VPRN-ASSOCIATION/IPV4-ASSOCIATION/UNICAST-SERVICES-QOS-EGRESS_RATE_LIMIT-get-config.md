This sample retrieves the egress policer configuration at VPRN service level.
 
Pre-condition:  


* Following sample must execute first,
	1) services-layer3-ipv4-traffic-management-service-policer-create
	2) services-layer3-ipv4-vprn-router-create
	3) services-layer3-ipv4-traffic-management-vprn-egress-policer-attach

Description:  


* Retrieves the egress rate limit policer associated to VPRN service configuration.
