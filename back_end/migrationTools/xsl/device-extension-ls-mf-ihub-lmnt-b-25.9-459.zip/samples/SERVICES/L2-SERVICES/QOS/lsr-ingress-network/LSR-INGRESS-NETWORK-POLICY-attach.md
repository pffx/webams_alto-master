This sample is used to associate a given lsr-ingress-network policy to a Base router interface


Pre-condition:

* Following sample must execute first,
  1) services-layer2-traffic-management-lsr-ingress-network-policy-create
  2) services-layer3-router-interface-create

Description:

* This sample is used to associate a given lsr-ingress-network policy to a Base router network interface.
