This sample applies the DSCP and PREC to TC mapping profile on service level.
 
Pre-condition:

* Following sample must execute first,

    1)services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
  	2)services-layer2-traffic-management-dscp-to-tc-policy-create
  
Description: 

* It applies the user-defined DSCP and PREC to TC mapping profile on service level.
* The policy can be applied on service type vvpls,true vpls
