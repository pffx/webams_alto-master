This sample deletes the Pbit to TC mapping association from service level.
 
Pre-condition:

* Following sample must execute first,
    1.services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
  	2.services-layer2-traffic-management-pbit-to-tc-policy-attach

Description:  

* It deletes the Pbit to TC mapping profile association from service level and assigns the default policy 1
