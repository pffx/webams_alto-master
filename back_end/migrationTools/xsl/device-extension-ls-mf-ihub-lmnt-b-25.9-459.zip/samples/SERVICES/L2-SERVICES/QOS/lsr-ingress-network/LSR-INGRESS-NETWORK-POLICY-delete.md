This sample delete the existing QoS lsr-ingress-network policy.

Pre-condition: 

* Following sample must execute first,
  1) services-layer2-traffic-management-lsr-ingress-network-create

* Policy should not be associated to any router interface in Base router.If attached,the following sample must execute first,
  1) services-layer3-ipv4-traffic-management-router-lsr-ingress-network-detach

Description:
 
* This policy is used to delete the lsr-ingress-network policy created using the sample services-layer2-traffic-management-lsr-ingress-network-create.
