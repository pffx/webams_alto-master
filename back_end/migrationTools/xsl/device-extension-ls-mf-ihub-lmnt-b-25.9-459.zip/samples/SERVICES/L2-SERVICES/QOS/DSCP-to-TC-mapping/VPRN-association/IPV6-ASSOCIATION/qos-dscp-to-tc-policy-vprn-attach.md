This sample creates association of service ingress access QoS policy on VPRN service

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv6-vprn-router-create

Description:

* It creates association of service ingress access QoS policy on VPRN service

