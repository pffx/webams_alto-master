This sample creates QoS Service ingress DSCP and PREC to TC mapping policy configuration.
 
 
Description:  

* The mapping of packets to forwarding class can be based on combinations of customer QoS markings including IEEE 802.1p bits, DSCP, and TOS precedence
* Service ingress access QoS Policy also serves to classify packets as being either in profile or out of profile based on the color-selector configuration
* When the color-selector configuration is set to config-entry-based, then the ingress color assignment will happen from the service ingress access QoS policy configuration.Final Color assignment will be based upon rate limit policy applied on service
* When the color-selector configuration is set to packet-dei-based then the ingress color assignment will happen based on the value in the packet DEI field. DEI=0 value in the packet assigns Green color while DEI=1 value in the packet would assign Yellow Color.
