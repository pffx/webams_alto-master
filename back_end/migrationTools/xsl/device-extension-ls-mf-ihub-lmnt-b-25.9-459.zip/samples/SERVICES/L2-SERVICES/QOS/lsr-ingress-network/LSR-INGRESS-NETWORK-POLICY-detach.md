This sample is used to detach a given lsr-ingress-network policy from a Base router interface


Pre-condition:

* Following sample must execute first,
  1) services-layer2-traffic-management-lsr-ingress-network-policy-create
  2) services-layer3-router-interface-create

Description:

* This sample is used to detach a given lsr-ingress-network policy from a Base router interface

* Once the user defined lsr-ingress-network policy is detached , the default policy lsr-ingress-network 1 will be associated with the interface.
