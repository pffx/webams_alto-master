This sample creates storm control configuration in system level.

* It creates the rate-limit for each of the flooding traffic type (bcast/unknown-multicast/unknown-unicast).
* Either aggregate or individual(BC/MC/UUC) rates can be configured and not both.
 
Pre-condition:  

* None.
