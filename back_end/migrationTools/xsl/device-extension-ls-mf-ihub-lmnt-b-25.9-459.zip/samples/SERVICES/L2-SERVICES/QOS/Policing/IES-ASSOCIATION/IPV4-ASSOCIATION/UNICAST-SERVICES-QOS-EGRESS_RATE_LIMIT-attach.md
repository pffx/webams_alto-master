This sample associates the egress policer to the IES service.

Pre-condition:


* Polcicer's shared parameter has to be false
* If only default rates are configured then policer can be associated to single service for either ingress or egress ratelimiting.
* There should be no pbit policer entries
* Following sample must execute first,
    1) services-layer3-ipv4-traffic-management-service-policer-create

Description:  
Associate the policer with IES service for egress rate-limit
