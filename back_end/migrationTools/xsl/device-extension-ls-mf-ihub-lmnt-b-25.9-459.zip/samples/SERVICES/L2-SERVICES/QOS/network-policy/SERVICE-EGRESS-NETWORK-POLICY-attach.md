This sample associates the service egress network policer on true vpls service.
 
Pre-condition:  



* Following sample must execute first,
    1) services-layer2-bridge-vpls-create
    2) services-layer2-traffic-management-service-egress-network-policy-create

Description:  
Associates the service egress network policer on true vpls service.
