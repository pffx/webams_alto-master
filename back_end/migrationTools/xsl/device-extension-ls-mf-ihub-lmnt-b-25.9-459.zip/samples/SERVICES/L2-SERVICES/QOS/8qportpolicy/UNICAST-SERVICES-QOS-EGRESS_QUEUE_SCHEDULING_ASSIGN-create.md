This sample add port QoS policy to system level configuration.
 
Pre-condition:  

* Following sample must execute first,
    services-layer2-traffic-management-egress-8q-scheduling-profile-create
* QoS four-queue policy must exist.
 

Description:  

1.Default port-QoS-policy in system should be 2[eight queue mode]
2.By default the TC to Queue mapping is fixed and not modifyable in port QoS policy.
3.for strict priority queue, queue and priority must be same.[i.e if weight is 0,queue number and priority must be same in LMNT-B]
4.for weighted queue, weight and priority must be same.[i.e if weight is not equal to 0, priority must be 0 in LMNT-B]
5.Valid priority range is 0-7 in 8Qmode.
