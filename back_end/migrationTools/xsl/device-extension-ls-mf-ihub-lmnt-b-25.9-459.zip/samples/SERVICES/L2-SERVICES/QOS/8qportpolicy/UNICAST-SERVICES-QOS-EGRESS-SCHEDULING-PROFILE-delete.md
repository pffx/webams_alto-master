This sample deletes user defined eight queue mode policy from system.
 
Pre-condition:  

* Following sample must execute first,
    services-layer2-traffic-management-egress-8q-scheduling-profile-create

* QoS eight queue policy must exist.
 
Description:  

* It deletes user defined eight-queue mode policy configuration from system
