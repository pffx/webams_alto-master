This sample Retrieves the service ingress access DSCP and PREC to TC QoS policy configuration.
 
Pre-condition:

* Following sample must execute first,
  1) services-layer3-ipv6-traffic-management-dscp-to-tc-policy-create
* Service Ingress QoS Policy must exist previously
 

