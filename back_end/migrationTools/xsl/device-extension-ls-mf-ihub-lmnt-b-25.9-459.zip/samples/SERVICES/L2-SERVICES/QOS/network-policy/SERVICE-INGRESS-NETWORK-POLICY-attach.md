This sample associates the service ingress network policer on true vpls service.
 
Pre-condition:  



* Following sample must execute first,
    1) services-layer2-bridge-vpls-create
    2) services-layer2-traffic-management-service-ingress-network-policy-create
	
Description:  
Associates the service ingress network policer on true vpls service.
