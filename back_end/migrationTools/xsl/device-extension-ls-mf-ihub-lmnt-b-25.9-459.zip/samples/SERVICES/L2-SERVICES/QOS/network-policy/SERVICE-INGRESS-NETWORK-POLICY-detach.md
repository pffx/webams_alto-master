This sample detaches the ingress network policy from true vpls service. 

Pre-condition:


* Following sample must execute first,    
    1) services-layer2-bridge-vpls-create
    2) services-layer2-traffic-management-service-ingress-network-policy-create
    3) services-layer2-traffic-management-service-ingress-network-policy-attach
 
 
* True VPLS Service with service ingress network policy must exist.
 
Description:  
De-associate the ingress network policy with true VPLS service configuration.
