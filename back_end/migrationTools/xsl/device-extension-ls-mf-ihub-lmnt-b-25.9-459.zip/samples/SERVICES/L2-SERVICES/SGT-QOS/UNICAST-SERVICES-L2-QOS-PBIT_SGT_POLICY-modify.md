This sample modifies Pbit and lsp-exp SGT QoS policy configuration for layer 2 services

Pre-condition:
* Following sample must execute first,
    1) services-layer2-traffic-management-pbit-sgt-policy-create

Description:
* It modifies Pbit,lsp-exp of SGT QoS policy configuration for layer 2 services
