This sample creates a SGT QoS Pbit and lspexp profile configuration in system for layer 2 services

Pre-condition:
* None

Description:
* It creates a SGT QoS Pbit and lspexp profile configuration in system for layer 2 services
