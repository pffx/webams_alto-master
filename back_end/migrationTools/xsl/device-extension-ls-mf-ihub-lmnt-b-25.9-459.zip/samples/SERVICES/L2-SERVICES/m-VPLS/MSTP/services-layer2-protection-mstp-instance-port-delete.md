This sample deletes a port [represented by SAP] from m-VPLS service which represents a MSTP instance

Pre-condition:

* Following sample must execute first,
    1) services-layer2-protection-mstp-instance-create
    2) transport-ethernet-port-network-port-create
   	3) services-layer2-protection-mstp-instance-port-attach
*  A m-VPLS service which maps to MSTP instance should be present
