This sample creates a MSTP instance in Aggregation switch
 
Description:

* MSTP protocol manages port forwarding states and will determine the port forward states of all VLANs for which the port is a member.
* The m-VPLS is not intended to forward data traffic.
* The ISAM uses a single m-VPLS to exclusively handle L2CP frames to support spanning tree protocols (RSTP/MSTP).
* MSTP mode-of-operation is only supported in an m-VPLS
* When running MSTP, by default, all VLANs are mapped to the CIST. On the m-VPLS level VLANs can be assigned to specific MSTIs.
* For MSTP, up to 15 instances can be configured with different VLAN ranges for the MST instance. VLANs which are not included explicitly in an MSTP instance 
  fall into the default MSTP instance 0. For the MST instance, the path-cost and port-priority are configured at the SAP level.

Pre-condition:

* Service name and id should not exist.
