This sample adds a port [represented by SAP] into m-VPLS service which represents a MSTP instance

Pre-condition:

* Following sample must execute first,
    1) services-layer2-protection-mstp-instance-create
    2) transport-ethernet-port-network-port-create
*  A m-VPLS service which maps to MSTP instance should be present
