This sample gets operational data of MSTP instance on Aggregation switch

Pre-condition:

* Following sample must execute first,
    services-layer2-m-vpls-mstp-instance-create
* A m-VPLS service which maps to MSTP instance should be present
