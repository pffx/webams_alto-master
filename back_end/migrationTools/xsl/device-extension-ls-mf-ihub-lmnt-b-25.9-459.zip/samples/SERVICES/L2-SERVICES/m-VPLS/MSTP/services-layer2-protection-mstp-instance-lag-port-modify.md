This sample modifies mstp configuration on lag port level(represented as sap) in m-vpls service

This can cause a temporary blocking or unblocking of ports in respective VLANs associated with this MSTP instance [identified by m-VPLS service] 
till a loop free topology is identified with new configuration values specified for the port.

Pre-condition:

* Following sample must execute first,
	1) services-layer2-protection-mstp-instance-create
