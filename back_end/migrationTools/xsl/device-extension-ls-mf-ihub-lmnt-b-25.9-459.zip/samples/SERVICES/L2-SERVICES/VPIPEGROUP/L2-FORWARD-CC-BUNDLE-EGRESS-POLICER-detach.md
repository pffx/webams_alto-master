This sample detaches the egress policer profile association from cross connect bundle (VPIPEGROUP) services

Pre-condition: 


* Following sample must execute first,
    1)  services-layer2-cross-connect-bundle-create or services-layer2-cross-connect-bundle-modify

