This sample creates Layer-2 forwarding cross connect bundle (VPIPEGROUP) services
 
Pre-condition:
* Service name ,service id and Outer VLAN id should not exist in any of the other existing services.


            