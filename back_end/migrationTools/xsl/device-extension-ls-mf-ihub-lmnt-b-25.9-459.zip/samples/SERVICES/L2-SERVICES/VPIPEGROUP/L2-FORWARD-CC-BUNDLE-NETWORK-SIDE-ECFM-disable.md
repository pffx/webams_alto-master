 This sample deletes Ethernet Fault monitoring (ECFM) from Layer-2 forwarding cross connect bundle (VPIPEGROUP) service in LAG interface.

 Pre-condition:
     1) L2 forwarding cross connect bundle must exist and Uplink port(SAP) must be attached to the service.
     2) Ethernet Fault monitoring domain and association must exist.
     3) Network side Ethernet Fault monitoring (ECFM) in Cross-connect bundle should have been enabled already.