This sample deletes Layer-2 forwarding cross connect bundle (VPIPEGROUP) service 
 
Pre-condition:
    1) Layer-2 Forwarding cross connect bundle must exist.
    2) Admin state of all pipes and SAPs inside the vpipe-group service should be in disabled state.
    3) And all associate cross connect bundle configuration like CFM, QoS, filters should have been removed.

