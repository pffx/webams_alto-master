This sample retrieves Layer-2 forwarding cross connect bundle (VPIPEGROUP) service configurations.
 
Pre-condition:
    1) Layer-2 Forwarding cross connect bundle must exist.

