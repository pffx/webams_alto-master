This sample associates the egress policer on service.
 
Pre-condition:

* If only default rates are configured then policer can be associated to single service either for ingress or egress ratelimiting.
* If the policer has pbit profile, the policer can be applied for egress ratelimiting only
* Following sample must execute first,
 1) services-layer2-cross-connect-create 
 2)services-layer2-traffic-management-service-policer-create

Description:
Associate egress policer with unicast service configuration


            
