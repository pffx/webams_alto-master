This sample modifies Layer-2 forwarding cross connect bundle (VPIPEGROUP) service
 
Pre-condition:
* Layer-2 forwarding cross connect bundle must exist and Admin-state of Layer-2 forwarding cross connect bundle should be disabled for modification.
