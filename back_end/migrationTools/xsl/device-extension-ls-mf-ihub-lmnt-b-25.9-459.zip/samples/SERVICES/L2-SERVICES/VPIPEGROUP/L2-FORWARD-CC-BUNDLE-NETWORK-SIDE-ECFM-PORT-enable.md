 This sample adds Ethernet Fault monitoring (ECFM) to Layer-2 forwarding cross connect bundle (VPIPEGROUP) service in SAP.
 
 Pre-condition:
     1) Layer-2 forwarding cross connect bundle must exist and Uplink port(SAP) must be attached to the service 
     2) Ethernet Fault monitoring domain and association must exist.