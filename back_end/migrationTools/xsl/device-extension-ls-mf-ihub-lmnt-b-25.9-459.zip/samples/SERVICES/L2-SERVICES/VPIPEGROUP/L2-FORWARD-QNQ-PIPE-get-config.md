This sample retrieves configuration of Layer-2 Forward QNQ pipe from Layer-2 forward cross connect bundle.

Pre-condition:
    1) Layer-2 forwarding cross connect bundle must exist 
    2) Layer-2 Forward QNQ pipe should be member of Layer-2 forwarding cross connect bundle
