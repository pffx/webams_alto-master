 This sample creates Layer-2 forwarding QNQ pipe inside Layer-2 forward cross connect bundle.
 
 Pre-condition:  
  * Layer-2 forwarding cross connect bundle must exist.
  * The LAG-id if specified should have been configured already.
  * The ring-id if specified should have been configured already.
