 This sample creates Layer-2 forwarding cross connect bundle (VPIPEGROUP)with LT/Uplink NT ports
 
 Pre-condition:
    1) Layer-2 Forwarding cross connect bundle must exist.
    2) SAP VLAN id should be same as outer VLAN id.
