 This sample modifies LT/Uplink NT ports within Layer-2 forwarding CC bundle (VPIPEGROUP)service
 
 Pre-condition:
    1) 1) Layer-2 Forwarding cross connect bundle must exist and the admin state of SAP should be disabled.
