 This sample Retreives state data of LT/uplink NT ports(SAP) within Layer-2 forwarding cross connect bundle (VPIPEGROUP)service
 
 Pre-condition:
    1) Layer-2 Forwarding cross connect bundle must exist.
