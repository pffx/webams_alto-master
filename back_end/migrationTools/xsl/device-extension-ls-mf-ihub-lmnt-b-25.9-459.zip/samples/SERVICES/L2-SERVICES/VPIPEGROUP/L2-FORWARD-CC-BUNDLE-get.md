This sample retrieves Layer-2 forwarding cross connect bundle (VIPEGROUP) service operational status

Pre-condition:
    1) Layer-2 Forwarding cross connect bundle must exist.


