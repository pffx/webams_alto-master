 This sample deletes LT/Uplink NT port within Layer-2 forwarding cross connect bundle (VPIPEGROUP) service
 
 Pre-condition:
    1) Layer-2 Forwarding cross connect bundle must exist.
