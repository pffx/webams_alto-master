This sample deletes a L2 forwarding CC configuration.
 
Pre-condition:
* Following sample must execute first,
    1) services-layer2-cross-connect-vpipe-create
* VPIPE Service must exist.

* It deletes L2 forwarding CC configuration which is vpipe service in Aggregation Switch
