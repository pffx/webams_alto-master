This sample creates L2 forwarding cross connect with LT/Uplink NT ports
 
* It creates a unicast services forwarding CC VPIPE configuration with LT and Uplink NT ports.

Pre-condition:

* Service name and id should not exist.
  
