This sample gets configurations of RSVP in Base router.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-router-mpls-create

Description:

* It gets configurations of RSVP.
