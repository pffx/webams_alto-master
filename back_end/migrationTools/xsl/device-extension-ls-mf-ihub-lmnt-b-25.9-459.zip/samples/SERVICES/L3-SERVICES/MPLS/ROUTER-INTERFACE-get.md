This sample gets state data of router interface.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-router-interface-create

Description:
* It gets operational state of router interface.
