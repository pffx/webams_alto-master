This sample gets state data of MPLS LSP path

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-router-mpls-create

Description:
* It gets operational state data of MPLS LSP path.
