This sample gets configurations of Interface LDP in LDP.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-router-interface-ldp-create

Description:

* It gets configurations of Interface in LDP.
