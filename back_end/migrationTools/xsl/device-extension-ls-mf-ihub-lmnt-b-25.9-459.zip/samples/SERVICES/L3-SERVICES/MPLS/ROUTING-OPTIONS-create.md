This sample creates admin-group under Routing options.

Description:
* It creates admin-group under routing options.
