This sample deletes T-LDP configurations

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-router-targeted-ldp-create

Description:

* It deletes T-LDP configuration under LDP.
