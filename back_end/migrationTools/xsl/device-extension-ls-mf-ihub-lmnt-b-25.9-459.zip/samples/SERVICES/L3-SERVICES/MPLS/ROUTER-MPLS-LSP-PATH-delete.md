This sample deletes MPLS lsp path.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-router-mpls-create

Description:

* It deletes Mpls lsp path.
