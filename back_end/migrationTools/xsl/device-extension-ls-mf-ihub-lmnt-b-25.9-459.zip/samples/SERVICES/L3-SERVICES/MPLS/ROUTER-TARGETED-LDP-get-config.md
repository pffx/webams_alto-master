This sample gets configurations of T-LDP in LDP.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-router-targeted-ldp-create

Description:

* It gets configurations of T-LDP.
