This sample creates modifies Admin group configs

Description:
* It updates admin-group name or value.
