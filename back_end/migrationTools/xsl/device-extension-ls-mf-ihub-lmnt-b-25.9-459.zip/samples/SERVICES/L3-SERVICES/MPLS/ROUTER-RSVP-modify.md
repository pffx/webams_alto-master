This sample modifies RSVP configs.

Description:
* It updates Rsvp router configs.
