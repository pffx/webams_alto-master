This sample gets configurations of router interface.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-router-interface-create

Description:

* It gets configurations of router interface.
