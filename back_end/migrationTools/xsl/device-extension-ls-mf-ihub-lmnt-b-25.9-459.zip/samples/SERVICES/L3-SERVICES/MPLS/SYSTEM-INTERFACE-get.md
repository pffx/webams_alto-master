This sample gets state data of system interface.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-system-interface-create

Description:
* It gets operational state of system interface.
