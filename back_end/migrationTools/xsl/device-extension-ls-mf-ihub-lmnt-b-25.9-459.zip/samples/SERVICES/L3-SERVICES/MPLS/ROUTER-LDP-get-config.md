This sample gets configurations of LDP in Base router.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-router-ldp-create

Description:

* It gets configurations of LDP.
