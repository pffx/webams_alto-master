This sample creates LDP under Base router.

Description:
* It creates LDP router under Base router.
