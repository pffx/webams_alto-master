This sample deletes system interface.

Description:

* It deletes system interface.
