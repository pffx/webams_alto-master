This sample creates Router interface.

Description:
* It creates router interface.
