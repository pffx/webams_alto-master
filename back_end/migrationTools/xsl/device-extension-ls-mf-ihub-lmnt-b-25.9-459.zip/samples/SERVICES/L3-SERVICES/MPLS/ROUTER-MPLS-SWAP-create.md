This sample creates Swap under Base router Mpls interface.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-router-mpls-create

Description:
* It creates Swap under Base router Mpls interface.
