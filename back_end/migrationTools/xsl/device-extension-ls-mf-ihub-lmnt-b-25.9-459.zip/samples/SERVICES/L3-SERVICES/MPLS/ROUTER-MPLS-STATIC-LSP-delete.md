This sample deletes MPLS Static lsp.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-router-mpls-create

Description:

* It deletes Mpls Static lsp.
