This sample deletes routing options.

Pre-condition:

Description:

* It deletes routing-options.
