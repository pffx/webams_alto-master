This sample gets operational status of LDP in Base router.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-router-ldp-create

Description:

* It gets state data of LDP.
