This sample updates Router interface configs.

Description:
* It modifies router interface configs.
