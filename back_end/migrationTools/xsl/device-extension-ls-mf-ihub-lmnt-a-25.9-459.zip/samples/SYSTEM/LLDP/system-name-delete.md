This sample deletes the system hostname.

Description:

This sample removes the system hostname.

