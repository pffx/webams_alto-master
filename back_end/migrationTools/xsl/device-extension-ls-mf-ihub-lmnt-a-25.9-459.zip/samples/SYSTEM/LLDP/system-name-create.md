This sample configures system hostname

Description:

This sample configures system hostname
