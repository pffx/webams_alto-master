This sample retrieves the configuration data system wide LLDP parameters

Description:

* This sample retrieves the configuration data system wide LLDP parameters
