This sample provides context to configure system-wide Link Layer Discovery Protocol(LLDP) parameters
lldp protocol is enabled by default in system context.
To modify the system level default lldp parameters,this sample can be used.
To enable lldp under port, port level lldp configurations must be done.

Pre-condition:

* None

Description:

* message-fast-tx -configures the duration (in seconds) of the fast transmission period for LLDP PDUs (Default: 1 second)
* message-fast-tx-init - configures the number of LLDPDUs to send during the fast transmission period (Default: 4)
* reinit-delay - configures the time (in seconds) before re-initializing LLDP on a port (Default: 2 seconds)
* tx-credit-max -  configures the maximum number of consecutive LLDPDUs transmitted (Default: 5)
* tx-hold-multiplier - configures the multiplier of the tx interval. (Default: 4)
* tx-interval - configures the LLDP transmit interval time (Default: 30 seconds)
* admin-state - enables/disables LLDP on a system wide level (Default: enable)



