This sample retrieves the state data for system wide LLDP parameters


Description:

* This sample retrieves the state data for system wide LLDP parameters
* Chassis Id Subtype - Shows the chassis ID subtype used in ISAM (for ISAM the subtype is 4 or MAC address type)
* Chassis Id - Shows the chassis ID for ISAM used for LLDP (for ISAM this is the system base MAC address)
* System Name - Shows the system name used for LLDP (for ISAM it is FAD chassis by default, can be changed by using the configure system name command)
* System Description -  Shows the system description for ISAM
* Capabilities Supported -  Shows the forwarding capabilities for ISAM. For ISAM, it is bridge router
* Capabilities Enabled - Shows the forwarding capabilities enabled in ISAM. For ISAM, it is bridge router
* Index 1 - Shows the Reserved Multicast Address used for Nearest Bridge LLDP PDUs
* Index 2 - Shows the Reserved Multicast Address used for Nearest Non TPMR Bridge LLDP PDUs
* Index 3 - Shows the Reserved Multicast Address used for Nearest Customer LLDP PDUs. 
* Remote-Last Changed -  Shows the last time (time since Apoch) wherein a remote LLDP information is inserted, removed or aged out
* Remote-inserts - Shows the number of times, remote LLDP information of LLDP remote peers are inserted
* Remote-deletes - Shows the number of times, remote LLDP information of LLDP remote peers are removed
* Remote-drops -  Shows the number of times, remote LLDP information of LLDP remote peers dropped.
* Remote-ageouts -  Shows the number of times, remote LLDP information of LLDP remote peers are aged-out
* mgmt-address - Shows the current system management address used by LLDP.
