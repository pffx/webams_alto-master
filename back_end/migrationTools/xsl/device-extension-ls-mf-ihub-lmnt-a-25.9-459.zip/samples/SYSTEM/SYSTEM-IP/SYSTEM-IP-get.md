This sample retrieves the state of system interface in device
Pre-condition:

* Following sample must be executed first,
    1) system-ip-create

Description:

* It retrieves state of system interface in device.
