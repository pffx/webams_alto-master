This sample creates System IP for accessing Aggregation Switch

Pre-condition:


* IES service must exist along with interface IP.

Description:

The AS-NE provides the provisioning of the OAM IP and System IP.

The OAM IP interface is in the same subnet as the next-hop.(equivalent to ies interface IP)
The System IP is like a loopback IP.
Client applications will use the System IP as Source IP.(For eg NTP,SYSLOG)

