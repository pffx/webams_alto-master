This sample retrieves the configuration data of system interface in device
Pre-condition:

* Following sample must be executed first,
    1) system-ip-create

Description:

* It retrieves configuration of system IP data in device.
