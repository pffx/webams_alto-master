This sample deletes the system IP address in Device

Pre-condition:

* Following sample must execute first,
    1) system-ip-create

Description:

* It deletes system IP address in Device
*Any change to system IP is recommended to be done using Commit Confirm option.
*The System IP delete operation can make the device unreachable, then the Commit Confirm message will not be received and hence AS-NE will trigger a rollback action thereby restoring the system IP.

