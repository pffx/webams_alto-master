This sample allows time zone and offset configuration on aggregation switch.

Pre-condition:

 None
  
Description:
  
* By default AS acts as NTP Client and syncs time with Shelf-ne
This sample provides provision to configure Time zone specific for AS NE
