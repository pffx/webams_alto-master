This sample gets NTP time synced on aggregation switch.

Pre-condition:

 None
  
Description:
  
* Gets NTP time synced on aggregation switch from Shelf-ne

