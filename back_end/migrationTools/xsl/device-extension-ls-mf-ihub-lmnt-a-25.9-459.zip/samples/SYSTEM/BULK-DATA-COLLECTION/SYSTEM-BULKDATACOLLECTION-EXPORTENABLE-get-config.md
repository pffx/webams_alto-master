Retrieve IPFIX export enable value

Description:

* This sample retrieves the IPFIX enable configuration.
