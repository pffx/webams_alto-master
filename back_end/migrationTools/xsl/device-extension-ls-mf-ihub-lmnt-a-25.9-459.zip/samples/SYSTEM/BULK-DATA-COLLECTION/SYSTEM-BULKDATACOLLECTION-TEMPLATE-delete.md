Delete an IPFIX cache template

Pre-condition:

Following sample should be executed first

* system-bulk-data-collection-template-create

Description :

* This sample deletes a configured IPFIX template and associated attributes. The data belonging to this template are ceased from exporting immediately after successful removal.
