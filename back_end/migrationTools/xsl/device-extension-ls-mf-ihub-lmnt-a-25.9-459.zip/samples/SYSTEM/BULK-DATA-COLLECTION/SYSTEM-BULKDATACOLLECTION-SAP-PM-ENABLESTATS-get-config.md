Retrieve SAP PM enable stats value 

Pre-condition:

Following sample should be executed first

* system-bulk-data-collection-sap-pm-enablestats-create

Description :

* This sample retrieves SAP PM enable stats configuration.
