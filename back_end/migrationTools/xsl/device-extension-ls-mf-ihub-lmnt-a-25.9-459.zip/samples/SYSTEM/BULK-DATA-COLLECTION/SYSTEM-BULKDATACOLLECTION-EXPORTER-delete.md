Delete an IPFIX exporter

Pre-condition:

Following sample should be executed first

* system-bulk-data-collection-exporter-create

Description :

* This sample deletes the configured IPFIX exporter and all the associated collector attributes.
