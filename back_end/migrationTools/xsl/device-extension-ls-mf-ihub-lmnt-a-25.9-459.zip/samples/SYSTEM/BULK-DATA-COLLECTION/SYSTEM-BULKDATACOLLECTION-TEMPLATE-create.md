Create an IPFIX cache template

Description :

* This sample configures an IPFIX template (or cache). The configured pm data is then exported to ipfix collector for every completed interval of 15 mins as per wall clock time (e.g. 00:00, 00:15, 00:30, .. 23:30,23:45,00:00). If template is configured at 00:13, the export starts from 00:15 for the previous 15 min interval from 00:00 to 00:15.The sample allows to configure the template name and enable/disable of this template for data export.
Note : For sap-pm template, system-bulk-data-collection-sap-pm-enablestats-create sample must be executed first to export the pm data.

cache-layout-types:
* rssi-sfp-pm [Template ID : 262]
This cache-layout-type exports RSSI SFP DDM values like Temperature, Supply Voltage, Tx Bias Current, Tx Output Power and Rx Optical Power.

* rssi-qsfp-pm [Template ID : 263]
This cache-layout-type exports RSSI QSFP DDM values like 
Temperature,
Supply Voltage,
Lane-1 Tx Bias Current, Lane-1 Tx Output Power and Lane-1 Rx Optical Power,
Lane-2 Tx Bias Current, Lane-2 Tx Output Power and Lane-2 Rx Optical Power,
Lane-3 Tx Bias Current, Lane-3 Tx Output Power and Lane-3 Rx Optical Power,
Lane-4 Tx Bias Current, Lane-4 Tx Output Power and Lane-4 Rx Optical Power.

* rssi-cfp-pm [Template ID : 264]
This cache-layout-type exports RSSI CFP DDM values like 
Temperature,
Supply Voltage,
Lane-1 Tx Bias Current, Lane-1 Tx Output Power and Lane-1 Rx Optical Power,
Lane-2 Tx Bias Current, Lane-2 Tx Output Power and Lane-2 Rx Optical Power,
Lane-3 Tx Bias Current, Lane-3 Tx Output Power and Lane-3 Rx Optical Power,
Lane-4 Tx Bias Current, Lane-4 Tx Output Power and Lane-4 Rx Optical Power.
