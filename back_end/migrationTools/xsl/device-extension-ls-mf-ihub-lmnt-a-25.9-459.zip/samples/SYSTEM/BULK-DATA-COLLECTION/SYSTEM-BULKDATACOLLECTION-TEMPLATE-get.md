Retrieve state information of IPFIX templates

Pre-condition:

Following sample should be executed first

* system-bulk-data-collection-template-create

Description :

* This sample retrieves state information on all configured IPFIX templates.
