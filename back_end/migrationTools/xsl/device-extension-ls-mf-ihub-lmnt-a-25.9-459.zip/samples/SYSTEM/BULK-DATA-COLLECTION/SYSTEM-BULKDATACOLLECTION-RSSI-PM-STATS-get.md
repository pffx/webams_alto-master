Retrieve RSSI SFP|QSFP|CFP DDM Values

Pre-condition:

Following sample should be executed first

* transport-ethernet-port-network-port-create.

Description :

* This sample retrieves RSSI SFP|QSFP|CFP DDM values.

rssi-sfp-pm:
* This sample retrives RSSI SFP DDM values like Temperature, Supply Voltage, Tx Bias Current, Tx Output Power and Rx Optical Power.

rssi-qsfp-pm:
* This sample retrives RSSI QSFP DDM values like 
Temperature,
Supply Voltage,
Lane-1 Tx Bias Current, Lane-1 Tx Output Power and Lane-1 Rx Optical Power,
Lane-2 Tx Bias Current, Lane-2 Tx Output Power and Lane-2 Rx Optical Power,
Lane-3 Tx Bias Current, Lane-3 Tx Output Power and Lane-3 Rx Optical Power,
Lane-4 Tx Bias Current, Lane-4 Tx Output Power and Lane-4 Rx Optical Power.

rssi-cfp-pm:
* This sample retrives RSSI CFP DDM values like 
Temperature,
Supply Voltage,
Lane-1 Tx Bias Current, Lane-1 Tx Output Power and Lane-1 Rx Optical Power,
Lane-2 Tx Bias Current, Lane-2 Tx Output Power and Lane-2 Rx Optical Power,
Lane-3 Tx Bias Current, Lane-3 Tx Output Power and Lane-3 Rx Optical Power,
Lane-4 Tx Bias Current, Lane-4 Tx Output Power and Lane-4 Rx Optical Power.
