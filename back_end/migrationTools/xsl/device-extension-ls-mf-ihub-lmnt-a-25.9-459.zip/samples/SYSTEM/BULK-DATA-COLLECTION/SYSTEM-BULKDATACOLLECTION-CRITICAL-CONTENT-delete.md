Delete an IPFIX cache critical-content

Pre-condition:

Following sample should be executed first

* system-bulk-data-collection-template-create

Description :

* This sample deletes a configured IPFIX critical-content and associated attributes. The cache db where the pkt information stored will reset.
