Retrieve PM statistics for SAP PM

Pre-condition:

Following sample should be executed first

* services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create

Description:

* This sample retrieves PM statistics on a SAP.
