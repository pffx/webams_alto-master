Retrieve PORT PM statistics 

Pre-condition:

Following sample should be executed first

* transport-ethernet-port-network-port-create or transport-ethernet-port-lt-port-create

Description :

* This sample retrieves PORT PM statistics.

Only the following attributes will be exported using IPFIX.

|               |                   |             |                   |               |
|-------------- |-------------------|-------------|-------------------|---------------|
| PORT ID       |  PORT OPERSTATE   |   TIMESTAMP |  MEASURED TIME    | IN OCTETS     |
| OUT OCTETS    |  IN PKTS          |   OUT PKTS  |  INVALIDDATA FLAG | IN BANDWIDTH  |
| OUT BANDWIDTH |  INTERVAL NUMBER  |             |                   |               |

: Port Stats PM
