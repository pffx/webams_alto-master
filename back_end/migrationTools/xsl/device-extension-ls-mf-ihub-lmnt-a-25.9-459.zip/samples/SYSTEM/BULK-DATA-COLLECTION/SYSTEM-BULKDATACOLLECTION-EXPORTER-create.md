Create an IPFIX exporter

Pre-condition:

Following sample should be executed first

* system-bulk-data-collection-exporter-exportenable-editconfig

Description:

* This sample creates an IPFIX exporter and configures the IPFIX collector attributes. IPFIX exporter establishes a TCP session with IPFIX collector using the configured collector attributes. The sample specifies to the exporter whether the collector is primary or an alternate collector. Upto 2 alternate collectors can be configured. More than one alternate collector can be configured by using the same sample repetitively. IPFIX collector autonomously tries to connect with alternate collector (if primary collector is not reachable) based on the configured order of priority and keeps retrying till a connection is established with collector.  IPFIX exporter must be explicitly enabled for an IPFIX exporter to establish connection with its collector and start exporting the records. 
