Enable IPFIX exporting

Description :

* This sample enables IPFIX exporting
