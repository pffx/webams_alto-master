Retrieve configured IPFIX templates

Pre-condition:

Following sample should be executed first

* system-bulk-data-collection-template-create

Description :

* This sample retrieves information on all configured IPFIX templates and the associated attributes
