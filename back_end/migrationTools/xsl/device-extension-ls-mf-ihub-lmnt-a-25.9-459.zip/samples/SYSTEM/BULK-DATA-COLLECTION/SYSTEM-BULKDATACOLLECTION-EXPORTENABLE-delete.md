Disable IPFIX exporting

Description :

* This sample disables IPFIX exporting
