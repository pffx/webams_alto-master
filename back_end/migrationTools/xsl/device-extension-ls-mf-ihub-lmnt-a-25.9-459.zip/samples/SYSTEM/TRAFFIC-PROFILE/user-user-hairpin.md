This sample creates user-to-user hairpin (user-user-hairpin)

Pre-condition:

*User-to-User communication [user-user-com] has to be enabled in service

