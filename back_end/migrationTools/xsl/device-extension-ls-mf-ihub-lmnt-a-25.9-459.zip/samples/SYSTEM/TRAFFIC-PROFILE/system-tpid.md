This sample creates system-level vlanDot1qEtype [tpid] configuration.

Pre-condition:
*Aggregation Switch supports not more than 4 TPIDs.

