This sample retrieves Equipment provisioning operational status on aggregation switch.
  
Pre-condition:

* Following sample must execute first,
    equipment-lt-mda-create
* MDA-SLOT-ID should be provisioned.

Description:

* It retrieves equipment provisioning operational status on aggregation switch.
