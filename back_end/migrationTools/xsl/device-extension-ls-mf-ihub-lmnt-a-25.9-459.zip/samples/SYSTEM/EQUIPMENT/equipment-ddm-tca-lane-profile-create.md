This sample provides context for configuring transceiver's digital diagnostic monitoring lane threshold  parameters.

Pre-condition:

* None

Description:

* Lane profile can be configured with values ranging from 1 to 5.
* Each profile requires the configuration of 4 threshold values for each threshold parameter.
* Any temperature value provided will be ignored.
* Each lane profile includes the following parameters with range of values:
    * Received optical power threshold: range -40.00 to 8.20 decibel-milliwatts
    * Transmit bias current threshold : range 0.0 to 131.0 milliamperes
    * Transmit output power threshold : range -40.00 to 8.20 decibel-milliwatts
* Each parameter requires 4 threshold values:
    * High alarm
    * High warning
    * Low warning
    * Low alarm
* The order of threshold values shall be:
    * High alarm > High warning > Low warning > Low alarm
* Zero is not a valid threshold for High Warning or High Alarm.
If a threshold value of zero is required, a value such as 0.1 or -0.1 can be used instead.