This sample provides context for configuring transceiver's digital diagnostic monitoring transceiver threshold parameters.

Pre-condition:

* None

Description:

* Transceiver profile can be configured with values ranging from 1 to 5.
* Each profile requires the configuration of 4 threshold values for each threshold parameter.
* Each transceiver profile includes the following parameters:
    * Temperature threshold : range -45.0 to 90.0 degrees celsius
    * Supply voltage threshold : range 0.0 to 6.60 volts
* Each parameter requires 4 threshold values:
    * High alarm
    * High warning
    * Low warning
    * Low alarm
* The order of threshold values shall be:
    * High alarm > High warning > Low warning > Low alarm
* Zero is not a valid threshold for High Warning or High Alarm.
If a threshold value of zero is required, a value such as 0.1 or -0.1 can be used instead.