This sample deletes a LT MDA provisioning on aggregation switch.
 
Pre-condition:

* Following sample must execute first,
    1) equipment-lt-mda-create
* LT-MDA-SLOT-ID should be provisioned. 

Description:
  
* It deletes a LT MDA provisioning on aggregation switch.
