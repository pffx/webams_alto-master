This sample provides context for deleting  transceiver's digital diagnostic monitoring transceiver threshold parameters using a transceiver profile id as reference.

Pre-condition:

* Following sample must execute first,
    1) equipment-ddm-transceiver-profile-create
    2) transport-transceiver-port-delete

Description:

* Transceiver profiles created within the range of 1 to 5 are removed.
* All threshold values associated with the transceiver profile are deleted.