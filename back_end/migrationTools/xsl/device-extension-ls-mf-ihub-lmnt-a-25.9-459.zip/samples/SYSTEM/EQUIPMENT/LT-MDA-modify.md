This sample will modify a LT MDA provisioning configuration on aggregation switch.
 
Pre-condition:

* Following sample must execute first,
    1)  equipment-lt-mda-create
* LT-MDA-SLOT-ID should be provisioned. 


Description:
  
* It will modify a LT MDA provisioning configuration on aggregation switch.
