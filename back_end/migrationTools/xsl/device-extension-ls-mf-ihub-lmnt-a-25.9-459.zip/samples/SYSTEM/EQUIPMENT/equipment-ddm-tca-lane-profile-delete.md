This sample provides context for deleting transceiver's digital diagnostic monitoring lane threshold parameters using a lane profile id as reference.

Pre-condition:

* Following sample must execute first,
    1) equipment-ddm-lane-profile-create
    2) transport-transceiver-port-delete

Description:

* Lane profiles created within the range of 1 to 5 are removed.
* All threshold values associated with the lane profile are deleted.
