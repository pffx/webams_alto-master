This sample creates CA-Certificate files to file system. Source string input should be given in PEM format with proper indentation.
 