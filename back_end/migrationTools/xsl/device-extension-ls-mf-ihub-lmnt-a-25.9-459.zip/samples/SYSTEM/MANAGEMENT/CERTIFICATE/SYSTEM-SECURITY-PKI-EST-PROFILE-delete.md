This sample will delete the est-profile in pki.
