This sample will retrieve the pki-est CA profile list

