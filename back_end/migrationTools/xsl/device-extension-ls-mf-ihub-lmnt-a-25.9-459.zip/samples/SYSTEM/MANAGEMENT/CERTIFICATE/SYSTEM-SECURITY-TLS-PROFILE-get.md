
This sample shows operational state of CA certificate, self certificate, trust anchor,TLS server profile and TLS client profile.

