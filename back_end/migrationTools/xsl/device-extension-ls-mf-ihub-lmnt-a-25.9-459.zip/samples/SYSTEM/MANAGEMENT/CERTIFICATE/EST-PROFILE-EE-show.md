This sample will display the EE certificate content of the est-profile
