This sample will delete the cipher list and De-Associate cipher list from server TLS profile.


