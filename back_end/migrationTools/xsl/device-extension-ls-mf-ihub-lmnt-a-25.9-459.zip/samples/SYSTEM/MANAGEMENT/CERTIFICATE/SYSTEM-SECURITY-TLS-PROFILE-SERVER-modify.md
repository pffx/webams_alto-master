
This sample will configure or modify the protocol version and cipher list of server TLS profile.

