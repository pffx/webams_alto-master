This sample deletes CA profile, trust anchor, cert-profile, cipher list and TLS client  Profile.
