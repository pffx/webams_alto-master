This sample will display the CA-certificate content of the est-profile
