This sample will delete the certificate to finger-print mapping under server TLS profile.

