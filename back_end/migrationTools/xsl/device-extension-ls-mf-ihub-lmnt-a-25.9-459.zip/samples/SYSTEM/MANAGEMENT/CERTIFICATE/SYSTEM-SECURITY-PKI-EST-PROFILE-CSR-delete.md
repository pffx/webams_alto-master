This sample will delete the CSR attributes in est-profile in pki.
