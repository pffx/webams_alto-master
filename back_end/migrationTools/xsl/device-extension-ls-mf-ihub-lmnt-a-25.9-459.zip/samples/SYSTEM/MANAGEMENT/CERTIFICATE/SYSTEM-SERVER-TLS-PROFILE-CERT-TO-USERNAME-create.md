This sample will configure certificate to finger-print mapping under server TLS profile.


