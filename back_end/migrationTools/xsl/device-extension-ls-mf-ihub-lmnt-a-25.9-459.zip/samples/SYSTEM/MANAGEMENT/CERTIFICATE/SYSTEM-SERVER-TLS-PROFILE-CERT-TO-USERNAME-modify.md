This sample will modify certificate to finger-print mapping under server TLS profile.
