This sample creates Self-Certificate to file system. Source string input should be given in PEM format with proper indentation.
 