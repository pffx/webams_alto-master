This sample will trigger the EE renew operation for est-profile.

