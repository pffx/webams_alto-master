This sample will trigger the CA renew operation for est-profile.
