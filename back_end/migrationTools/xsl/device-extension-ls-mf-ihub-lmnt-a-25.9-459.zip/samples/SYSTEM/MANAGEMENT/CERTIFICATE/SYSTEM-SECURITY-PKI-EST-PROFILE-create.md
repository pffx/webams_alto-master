This sample will create the pki est-profile.
  
  pre-condition:
  1) SYSTEM-SECURITY-TLS-PROFILE-CLIENT-create
  2) DNS-BASE-ROUTER-create (It is required if fqdn is configured)
