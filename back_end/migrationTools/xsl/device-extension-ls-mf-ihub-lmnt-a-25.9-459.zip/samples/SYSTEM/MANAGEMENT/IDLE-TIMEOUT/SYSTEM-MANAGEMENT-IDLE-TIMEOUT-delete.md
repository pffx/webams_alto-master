This sample deletes idle timeout from the system

Pre-condition:

* Deletion of idle-timeout will revert to the default value of 30 minutes.


