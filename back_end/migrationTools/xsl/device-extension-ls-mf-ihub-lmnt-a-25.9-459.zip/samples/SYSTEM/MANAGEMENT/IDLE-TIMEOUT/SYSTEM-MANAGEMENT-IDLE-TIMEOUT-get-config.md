This sample retrieves the idle-timeout configuration from system.

