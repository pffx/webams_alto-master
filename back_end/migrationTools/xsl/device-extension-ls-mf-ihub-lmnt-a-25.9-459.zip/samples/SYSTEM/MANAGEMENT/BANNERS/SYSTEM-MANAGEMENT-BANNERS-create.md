This sample enables or disables the display of a login banner.  The login banner contains 
a pre-login message which is displayed upon a console login attempt. 
The login banner contains the SR OS copyright and build date information for a console login attempt. 

The pre-login message is not included in the system name by default.

Pre-condition:

* By default the login-banner and pre-login message are not configured and hence, no login banner will be displayed during console login attempt.
* Users who do not belong to admin group are allowed only to read and not configure the login banner.

