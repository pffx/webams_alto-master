This sample deletes login banner from the system

Pre-condition:

* Deletion of login-banner will set the configurable boolean value to false by default.


