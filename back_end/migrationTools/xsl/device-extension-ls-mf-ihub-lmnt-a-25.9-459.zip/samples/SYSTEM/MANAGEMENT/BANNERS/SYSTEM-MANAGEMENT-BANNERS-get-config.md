This sample retrieves the login banner configuration from system.

