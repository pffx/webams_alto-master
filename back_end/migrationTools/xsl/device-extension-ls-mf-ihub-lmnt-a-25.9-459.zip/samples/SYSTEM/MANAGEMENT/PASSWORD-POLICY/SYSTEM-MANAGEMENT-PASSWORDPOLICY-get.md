This sample retreives the password policy rules.

* password-changed-time and password-expiration-time for each user

Pre-condition:

* Admin user can retrieve the data for the users in lockout