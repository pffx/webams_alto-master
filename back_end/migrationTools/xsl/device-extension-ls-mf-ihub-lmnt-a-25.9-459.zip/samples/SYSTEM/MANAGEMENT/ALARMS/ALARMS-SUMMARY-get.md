This sample gives summary of alarms.

Description:
This sample gives summary of alarms.