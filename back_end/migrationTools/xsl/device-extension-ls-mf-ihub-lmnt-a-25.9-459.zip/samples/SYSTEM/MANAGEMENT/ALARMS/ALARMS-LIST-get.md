This sample gives alarms on the device.

Description:
This sample gives alarms on the device.
