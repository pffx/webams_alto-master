This sample deletes any configured user profile from system

