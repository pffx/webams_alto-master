This sample creates local profile which can be attached to local user.

Description:
8 member profiles can be attached to local user profile. These profiles are effective in order-by user.
User considers the profile as high priority when default-action is mentioned in it. 
If default-action is set, it ignores next profiles in the list.


If multiple profiles has entries with different action and same match string, user will considers the first profiles entry action from the list.
