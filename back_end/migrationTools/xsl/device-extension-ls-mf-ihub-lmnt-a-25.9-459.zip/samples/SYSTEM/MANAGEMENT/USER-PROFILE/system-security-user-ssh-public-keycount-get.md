This sample retrieves the user level ssh-public-key-count from the system.
