This sample retrieves the local user profile configuration from system.

