This sample dettaches member profile from local user profile.
