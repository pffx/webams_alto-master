This sample creates a local user profile for accessing system via NCY/console
This sample forces the user to change a password at the next console login. The new 
password applies to FTP but the change can be enforced only by the console, SSH, or Telnet 
login. The change cannot be enforced on a netconf login attempt.


Pre-condition:

* By default the profile administrative is auto-created in system with all permissions,user has to attch this profile to enable all access
  during profile configuration
* By default the new-password-at-login field will be set to false hence not prompting the user to specify a new password
  at the first login attempt
* The user is required to enter the previous password , following by the the new password twice (for confirmation) if new-password-at-login
  in enforced
* The password reset will not impact the existing login session and will be refelcted from the subsequent login onwards.
* Impact on AV : Device has to be updated with the new password else it will lead to device misalignment since
  authentication failure might occur as Altiplano tries to establidh session with the existing(old) password.
