This sample modifies the rsa key for the user configuration.

Pre-condition:

* Following sample must execute first,
    1) system-user-profile-create 
