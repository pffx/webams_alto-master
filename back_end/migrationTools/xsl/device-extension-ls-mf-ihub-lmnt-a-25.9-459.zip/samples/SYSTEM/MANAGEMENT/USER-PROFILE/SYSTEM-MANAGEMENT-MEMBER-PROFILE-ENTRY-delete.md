This sample deletes specific entry from local profile.
