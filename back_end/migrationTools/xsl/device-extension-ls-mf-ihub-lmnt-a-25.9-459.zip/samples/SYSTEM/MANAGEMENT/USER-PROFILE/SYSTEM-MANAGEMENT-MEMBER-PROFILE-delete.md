This sample deletes local profile.

Pre-conditions:
* Mentioned profile should not be part of any local user profile
