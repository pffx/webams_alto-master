This sample retrieves the confirmed commit timeout state from system.

