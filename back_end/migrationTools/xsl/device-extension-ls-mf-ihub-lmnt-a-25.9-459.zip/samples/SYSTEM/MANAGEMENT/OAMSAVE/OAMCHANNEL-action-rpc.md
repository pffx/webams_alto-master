This sample is an action-rpc which will fetch the protected OAM connectivity configuration in "xml-output" format.

Pre-condition:

* Following sample must be executed first,
    1) OAMSAVE-action-rpc

Description:

* This sample will fetch the bare minimum configuration needed for OAM connectivity which will be protected in altiplano.
