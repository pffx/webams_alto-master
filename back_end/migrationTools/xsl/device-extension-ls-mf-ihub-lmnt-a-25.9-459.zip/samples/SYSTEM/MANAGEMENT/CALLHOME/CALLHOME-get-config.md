This sample retrieves ihub system callhome configuration.
 
Pre-condition:
 None

* It retrieves ihub system callhome configuration from aggregation switch.
