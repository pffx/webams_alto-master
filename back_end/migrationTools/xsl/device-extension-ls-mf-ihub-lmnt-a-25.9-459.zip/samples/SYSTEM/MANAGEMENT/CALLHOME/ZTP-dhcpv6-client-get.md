This sample retrieves opertaion data for dhcpv6-client obtained
 
Pre-condition:

* None 

Description:  

* It retrieves dhcpv6 client operational data.
