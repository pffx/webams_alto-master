This sample displays callhome certificate in uncoded format.
