This sample retrives all state data pertaining to system callhome
