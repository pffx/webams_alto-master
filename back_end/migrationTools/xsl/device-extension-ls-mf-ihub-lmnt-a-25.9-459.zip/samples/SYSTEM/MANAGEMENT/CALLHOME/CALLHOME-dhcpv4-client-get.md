This sample retrieves opertaion data for dhcpv4-client obtained
 
Pre-condition:

* None 

Description:  

* It retrieves dhcpv4 client operational data.
