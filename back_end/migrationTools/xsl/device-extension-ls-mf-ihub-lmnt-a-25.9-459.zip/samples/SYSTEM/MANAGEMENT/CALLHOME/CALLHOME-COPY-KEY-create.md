This is sample copies callhome key in file system.
