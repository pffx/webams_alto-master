This sample retrieves ihub callhome dhcpv4 configuration.
 
Pre-condition:
 None

* It retrieves ihub callhome dhcpv4 configuration from aggregation switch.
