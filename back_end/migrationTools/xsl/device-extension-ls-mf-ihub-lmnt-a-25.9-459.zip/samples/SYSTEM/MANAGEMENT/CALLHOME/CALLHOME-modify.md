This sample modifies callhome options
 
Pre-condition:

* Callhome should be configured 
    
Description:  

* It modifies callhome parameters at sytem level
  
