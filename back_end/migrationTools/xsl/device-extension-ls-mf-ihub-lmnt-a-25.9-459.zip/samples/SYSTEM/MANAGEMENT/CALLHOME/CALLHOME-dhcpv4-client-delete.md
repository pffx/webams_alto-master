This sample deletes callhome dhcpv4-client config.
 
Pre-condition:
None

Description:

* It deletes callhome dhcpv4-client configs in Aggregation Switch
* Existing IP interface allocated via DHCP will remain till end of lease period. When DHCP client is removed, the IP address will be forcibly released by DHCP client before removal.
