This sample retrieves ihub callhome dhcpv6 configuration.
 
Pre-condition:
 None

* It retrieves ihub callhome dhcpv6 configuration from aggregation switch.
