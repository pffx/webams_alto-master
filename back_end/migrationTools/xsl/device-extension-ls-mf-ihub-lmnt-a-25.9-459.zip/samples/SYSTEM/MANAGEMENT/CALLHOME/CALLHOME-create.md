This sample enables callhome
 
Pre-condition:

* None 
    
Description:  

* It enables callhome at sytem level
  
