This sample copies callhome certificate in file system. It will not have impact on current callhome session. This certificates will be validated when callhome session is restarted.
