This sample deletes callhome config.
 
Pre-condition:
None

* It deletes all callhome configs in Aggregation Switch
