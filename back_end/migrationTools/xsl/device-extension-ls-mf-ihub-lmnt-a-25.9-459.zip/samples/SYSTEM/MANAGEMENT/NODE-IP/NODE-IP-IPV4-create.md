Creates IPV4 node-ip which then used by LT-NEs for its client applications such as IPFIX, Radius, syslog etc.,
Description
This sample creates IPV4 node-ip to be used by LT-NEs as node identifier in their packet payload for its client applications such as IPFIX, Radius, syslog etc.,

Pre-condition:

The interface-name configured in node-ip should be present/configured already in IES router context.
Description:

It creates IPV4 node-ip to be used by LT-NEs for its client applications such as IPFIX, Radius, syslog etc.,
