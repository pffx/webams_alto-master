Gets state information of IPV6 node-ip used for client applications by LT-NEs. 
Description
This sample gets state information of IPV4 node-ip used for client applications by LT-NEs.

Pre-condition:

Following sample must execute first,
system-node-ip-ipv6-create
Description:

It gets state information of IPV6 node-ip used by LT-NEs as node identifier in their packet payload for its client applications such as IPFIX, Radius, syslog etc.,

