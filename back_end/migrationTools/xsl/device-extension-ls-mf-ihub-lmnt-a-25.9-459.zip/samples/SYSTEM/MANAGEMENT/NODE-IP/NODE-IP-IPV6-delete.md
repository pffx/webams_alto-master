Deletes IPV6 node-ip used for client applications by LT-NEs. 
Description
This sample deletes IPV6 node-ip used for client applications by LT-NEs.

Pre-condition:

Following sample must execute first,
system-node-ip-ipv6-create
Description:

It deletes IPV6 node-ip used for client applications by LT-NEs.
