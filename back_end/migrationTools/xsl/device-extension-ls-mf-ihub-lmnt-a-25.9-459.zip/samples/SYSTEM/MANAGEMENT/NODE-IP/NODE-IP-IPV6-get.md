This sample gets state information of IPV6 node-ip used for client applications.

Pre-condition:


* Following sample must execute first,
    1) system-node-ip-ipv6-create

Description:


* It gets state information of IPV6 node-ip used for client applications such as syslog,FTP,NTP etc.
