Deletes IPV4 node-ip used for client applications by LT-NEs. 
Description
This sample deletes IPV4 node-ip used for client applications by LT-NEs.

Pre-condition:

Following sample must execute first,
system-node-ip-ipv4-create
Description:

It deletes IPV4 node-ip used for client applications by LT-NEs.
