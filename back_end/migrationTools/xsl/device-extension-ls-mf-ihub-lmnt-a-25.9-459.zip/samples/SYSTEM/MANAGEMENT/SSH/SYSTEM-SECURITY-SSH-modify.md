This sample configures or modifies ssh server.

Description:
* It can be configure or modify the ssh server with provided values.
* It is recommended to configure highest secure Cipher/Mac/Kex at the start of the list