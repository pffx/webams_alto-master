This sample is for regeneration of SSH RSA key. This sample has to be executed twice and reboot is required in between

Description:
We support RSA key generation only at boot. below is the procedure for regeneration

* Set PRESERVE-KEY to false. This will delete the SSH RSA key files from file system
* set RSA-KEY-LENGTH to required length (optional)
* set SSH-VERSION to required version (optional)

* commit the configuration
* Reboot the system
* System will boot and generate new SSH RSA keys based on RSA-KEY-LENGTH

* Set PRESERVE-KEY to true after system reboot.This will store the key to file system
* commit the configuration
