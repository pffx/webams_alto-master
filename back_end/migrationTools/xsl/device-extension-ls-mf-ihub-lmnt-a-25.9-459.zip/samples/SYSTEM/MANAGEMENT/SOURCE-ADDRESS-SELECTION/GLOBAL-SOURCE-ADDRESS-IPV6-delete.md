This sample deletes IPV6 global source address used for client applications.

Pre-condition:


* Following sample must execute first,
    1) system-source-address-selection-global-source-address-ipv6-create
* The address configured in the interface to be removed first before deleting the global source address

Description:


* It deletes IPV6 global source address used for client applications such as syslog,FTP,NTP etc.
