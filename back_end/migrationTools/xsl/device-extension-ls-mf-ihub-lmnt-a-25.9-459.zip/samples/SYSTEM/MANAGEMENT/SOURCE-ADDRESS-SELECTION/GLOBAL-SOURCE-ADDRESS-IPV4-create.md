This sample creates IPV4 global source address to be used for client applications.

Pre-condition:


* The address/interface-name configured in global source address should be present in the Base/IES router context respectively.

Description:


* It creates IPV4 global source address to be used for client applications such as syslog,FTP,NTP etc.
