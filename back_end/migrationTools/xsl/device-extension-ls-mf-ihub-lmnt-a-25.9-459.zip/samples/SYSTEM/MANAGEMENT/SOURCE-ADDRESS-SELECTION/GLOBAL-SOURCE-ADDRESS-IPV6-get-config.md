This sample gets IPV6 global source address used for client applications.

Pre-condition:


* Following sample must execute first,
    1) system-source-address-selection-global-source-address-ipv6-create

Description:


* It gets IPV6 global source address used for client applications such as syslog,FTP,NTP etc.
