This sample creates a syslog id and associate it to log-id as destination.

Pre-condition:

* Syslog id number should give as input in range of 1 to 10.
* Log id number should give as input in range of 1 to 100.

Description:

* This sample creates a syslog id and associate it to log-id as destination.
