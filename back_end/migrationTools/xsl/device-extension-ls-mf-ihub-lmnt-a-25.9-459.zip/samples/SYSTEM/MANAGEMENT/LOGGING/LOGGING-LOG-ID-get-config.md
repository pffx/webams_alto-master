This sample retrieves configuration of log-id.

Pre-condition:

Below sample must be executed first,

* system-logging-syslog-create

Description:

* It retrieves configuration of log-id.
