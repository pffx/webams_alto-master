This sample retrieves configuration of syslog.

Pre-condition:

Below sample must be executed first,

* system-logging-syslog-create

Description:

This sample retrieves configuration of syslog.
