This sample creates a syslog id and attaches TLS profile to it.

Pre-condition:
* Syslog id number should give as input in range of 1 to 10.
* TLS profile should be created first to attach it to syslog.

