This sample deletes syslog and log-id.

Pre-condition:

Below sample must be executed first,

* system-logging-syslog-create

Description:

* This sample deletes syslog and log-id.
