Get-config information about lockout related data.

Pre-condition:

This sample retrieves the following lockout configuration from system 

*lockout - 	Specifies the lockout period, in minutes, during which the user is not allowed to login

*time - Specifies the period of time, in minutes, that a specified number of unsuccessful attempts can be made before the user is locked out. 

*count -Specifies the number of unsuccessful login attempts allowed for the specified time.


