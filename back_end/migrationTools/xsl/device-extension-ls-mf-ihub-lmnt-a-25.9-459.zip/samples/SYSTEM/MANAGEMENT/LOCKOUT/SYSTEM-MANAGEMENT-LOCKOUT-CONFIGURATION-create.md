This sample configures the lockout duration and maximum password retry attempts.

When a user exceeds the maximum number of attempts allowed (the default is 3
attempts) during a certain period of time (the default is 5 minutes),
the user will be locked out for a pre-configured lock-out period (the
default is 10 minutes).

Lockout duration can be configured either as dynamic or fixed. 
Value '0' enables dynamic lockout type. Initial value of dynamic lockout
duration is 2 minutes and every subsequent failure increases the
lockout-duration by an additional 2 minutes. Maximum lockout duration is restricted
to 15 minutes.



Pre-condition:

* Whenever lockout happens for a individual session, the other active sessions are not impacted, and they remain active/connected to the device.

* In case of system reboot, the information related to lockout is lost, as this info is not stored in a persistent way.

* Users with admin privilege only shall be able to configure lockout duration.
