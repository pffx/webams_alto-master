This sample retrieves information on which users are in lockout.

Remaining time until lockout, failure login, attempted-logins will be displayed for per user.