This sample allows configuration of ssh client authentication method.

Description:

* This sample allows user to configure the ssh-client authentication method with either key-based-and-password or key-based method.
* If the user chooses ‘key-based’ authentication, there is no fall back option to use password authentication. So exercise caution while choosing this mode. It is entirely upto the admin/user to ensure that the public keys are properly configured to avoid a lockout in case of incorrect key config with ‘key-based’ authentication.

