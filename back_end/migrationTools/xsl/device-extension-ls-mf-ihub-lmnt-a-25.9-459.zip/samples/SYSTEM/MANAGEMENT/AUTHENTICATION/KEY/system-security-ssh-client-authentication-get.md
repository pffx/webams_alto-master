This sample retrieves the ssh-client authentication method configured from the system.
