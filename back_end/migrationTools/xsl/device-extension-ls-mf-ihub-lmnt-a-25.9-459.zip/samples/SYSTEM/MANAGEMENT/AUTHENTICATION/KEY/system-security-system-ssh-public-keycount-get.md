This sample retrieves the overall system-ssh-public-key-count from the system.
