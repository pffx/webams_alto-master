This sample deletes configuration of ssh client authentication method.

Description:

* This sample allows user to delete the ssh-client authentication method with either key-based-and-password or key-based method.

