This sample allows the user to modify the ssh-client authentication method.

Description:

* If the user chooses ‘key-based’ authentication, there is no fall back option to use password authentication. So exercise caution while choosing this mode. It is entirely upto the admin/user to ensure that the public keys are properly configured to avoid a lockout in case of incorrect key config with ‘key-based’ authentication.

Pre-condition:

* Following sample must execute first,
    1) system-security-ssh-client-authentication-create
