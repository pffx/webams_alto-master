Retrieves SGT QoS Pbit policy configuration

Pre-condition:
* Following sample must execute first,
    1) services-layer2-traffic-management-pbit-sgt-policy-create

Description:
* It retrieves a Pbit SGT QoS policy configuration from system level.
