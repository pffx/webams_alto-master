This sample modifies Pbit SGT QoS policy configuration.

Pre-condition:
* Following sample must execute first,
    1) services-layer2-traffic-management-pbit-sgt-policy-create

Description:
* It modifies Pbit SGT QoS policy configuration on system level
~
