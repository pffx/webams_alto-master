This sample deletes a Pbit SGT QoS policy configuration from system level

Pre-condition:
* Following sample must execute first,
    1) services-layer2-traffic-management-pbit-sgt-policy-create

Description:
* It deletes a Pbit SGT QoS policy configuration from system level
