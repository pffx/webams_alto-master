This sample creates a SGT QoS Pbit profile configuration in system

Pre-condition:
* None

Description:
* It creates a SGT QoS Pbit policy profile configuration.
