This sample modifies multicast service on the host port in a Virtual Private LAN Service(v-VPLS).

Pre-condition:

* Following sample must execute first,
    1) services-layer2-bridge-multicast-vpn-host-port-create
* VPLS Service must exist.

Description:

* It modifies multicast service on the host port in a Virtual Private LAN Service(v-VPLS).
