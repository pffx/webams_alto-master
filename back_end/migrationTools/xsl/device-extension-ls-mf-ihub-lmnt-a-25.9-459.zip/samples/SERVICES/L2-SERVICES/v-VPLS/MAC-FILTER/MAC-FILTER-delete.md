This sample deletes a MAC filter policy configuration.
 
Pre-condition:

* Following sample must execute first,
    1) services-layer2-security-mac-filter-profile-create
 The above profile should not be associated with any service

Description:
  
* It deletes a MAC filter policy configuration.
