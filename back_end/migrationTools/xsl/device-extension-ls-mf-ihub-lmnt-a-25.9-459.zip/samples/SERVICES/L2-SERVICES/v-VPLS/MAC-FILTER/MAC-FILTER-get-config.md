This sample gets a MAC filter policy configuration.
 
Pre-condition:

* Following sample must execute first,
    1) services-layer2-security-mac-filter-profile-create

Description:
  
* It gets a MAC filter policy configuration.
