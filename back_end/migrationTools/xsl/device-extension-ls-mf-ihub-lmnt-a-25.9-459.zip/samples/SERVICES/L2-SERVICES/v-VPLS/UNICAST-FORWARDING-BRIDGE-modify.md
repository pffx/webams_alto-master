This sample modifies a Virtual Private LAN Service(v-VPLS) configuration
 
Pre-condition:

* Following sample must execute first,
    * services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
* VPLS Service must exist.

Description:
  
* It modifies a Virtual Private LAN Service(v-VPLS) configuration with attributes such as
  ADMIN-STATUS,FDB-TABLE-SIZE,MAC-AGING,MAC-LEARNING and LOCAL-AGE-TIME
