This sample removes Pbit SGT QoS policy association from service
  
Pre-condition:  
* Following sample must execute first,
    * services-layer2-bridge-v-vpls-create
 
* It deletes the SGT QoS PBit policy association with service.
