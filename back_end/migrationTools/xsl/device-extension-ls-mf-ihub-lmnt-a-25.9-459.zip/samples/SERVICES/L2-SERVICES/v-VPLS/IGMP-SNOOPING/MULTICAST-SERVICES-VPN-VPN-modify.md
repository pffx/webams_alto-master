This sample modifies multicast service in a Virtual Private LAN Service(v-VPLS).

Pre-condition:

* VPLS Service must exist.

Description:

* It modifies multicast service in a Virtual Private LAN Service(v-VPLS).
