This sample modifies a port attributes within a Virtual Private LAN Service(v-VPLS) configuration
 
Pre-condition:

* Following sample must execute first,
    * services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
* VPLS Service must exist.

Description:
  
* It modifies port attributes in a Virtual Private LAN Service(v-VPLS) configuration such as
  ADMIN-STATUS for lag or regular ports
