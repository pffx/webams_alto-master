This sample creates unicast services forwarding bridging with LT/Uplink NT ports
 
Pre-condition:


* Service name and id should not exist.
    
Description:
  

* It creates a unicast services forwarding bridging Virtual Private LAN Service(v-VPLS) configuration with LT and Uplink NT ports.
  
