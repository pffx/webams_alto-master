This sample allows or disallows regular to residential, residential to regular and residential to residential mac-movement configuration in vvpls service.

Pre-condition:

* A v-vpls service must be created already.
