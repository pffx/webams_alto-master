This sample creates multicast service on the network port in a Virtual Private LAN Service(v-VPLS).

Pre-condition:

* Following sample must execute first,
    1) services-layer2-bridge-v-vpls-create
* The VPLS serivce with serivce name must be exist.

Description:

* It creates multicast service on the network port in a Virtual Private LAN Service(v-VPLS)
