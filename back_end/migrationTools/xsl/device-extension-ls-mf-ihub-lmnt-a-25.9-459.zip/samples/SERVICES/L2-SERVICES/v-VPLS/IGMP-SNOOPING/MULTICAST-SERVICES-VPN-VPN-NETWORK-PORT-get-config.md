This sample gets muticast service on the network port in a Virtual Private LAN Service(v-VPLS).

Pre-condition:

* Following sample must execute first,
    1) services-layer2-bridge-multicast-vpn-network-port-create
* VPLS Service must exist.

Description:

* It gets muticast service on the network port in a Virtual Private LAN Service(v-VPLS).
