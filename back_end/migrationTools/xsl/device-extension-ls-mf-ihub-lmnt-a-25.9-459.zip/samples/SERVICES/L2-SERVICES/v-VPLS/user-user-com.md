This sample creates user-to-user communication (user-user-com) configuration.

Pre-condition:


* A v-vpls service must be created already.
* 4k v-vpls service can be enabled with user-user-com 

Description:

* This sample creates user-user-com configuration with true/false values.

