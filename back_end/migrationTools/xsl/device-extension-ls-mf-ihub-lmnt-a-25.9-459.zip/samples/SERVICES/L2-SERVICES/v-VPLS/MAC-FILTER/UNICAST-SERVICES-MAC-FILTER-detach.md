This sample deletes a MAC filter policy within unicast services on ingress or egress direction.
 
Pre-condition:

* Following sample must execute first,
    1) services-layer2-security-mac-filter-profile-create
 
Description:
  
* It deletes a ingress/egress MAC filter policy association within Service Access Point(SAP).
