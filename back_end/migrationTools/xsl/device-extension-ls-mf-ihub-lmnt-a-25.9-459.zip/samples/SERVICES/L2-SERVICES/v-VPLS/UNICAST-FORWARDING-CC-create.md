This sample creates unicast services forwarding cross connect with LT/Uplink NT ports
 
Pre-condition:

* Service name and id should not exist.

  
Description:
  
* It creates a unicast services forwarding CC Virtual Private LAN Service(v-VPLS) configuration with LT and Uplink NT ports.
  
