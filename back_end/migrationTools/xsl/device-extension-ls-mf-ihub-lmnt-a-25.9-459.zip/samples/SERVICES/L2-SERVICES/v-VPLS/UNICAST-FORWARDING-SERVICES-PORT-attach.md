This sample creates unicast services with LT/Uplink NT ports
 
Pre-condition:

Following sample should be executed first

* services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create

Description:
  
* It creates a unicast services Virtual Private LAN Service(v-VPLS) configuration with LT and Uplink NT ports.
