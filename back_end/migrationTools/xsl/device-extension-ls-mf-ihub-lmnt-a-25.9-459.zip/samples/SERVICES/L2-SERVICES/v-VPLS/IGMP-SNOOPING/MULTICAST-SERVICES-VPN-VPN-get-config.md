This sample gets multicast service in a Virtual Private LAN Service(v-VPLS).

Pre-condition:

* VPLS Service must exist.

Description:

* It gets multicast service in a Virtual Private LAN Service(v-VPLS).
