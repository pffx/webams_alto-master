This sample deletes a unicast services forwarding Bridging configuration.
 
Pre-condition:


* Following sample must execute first,

    * services-layer2-bridge-v-vpls-create

* It deletes unicast services forwarding Bridging configuration which is typically a v-vpls service in Aggregation Switch
  mac learning enabled
