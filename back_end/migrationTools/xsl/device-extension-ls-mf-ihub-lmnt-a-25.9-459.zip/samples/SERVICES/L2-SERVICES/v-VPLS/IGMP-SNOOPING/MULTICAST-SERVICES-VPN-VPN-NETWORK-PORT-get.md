This sample gets multicast service state configuration on the network port in a Virtual Private LAN Service(v-VPLS).

Pre-condition:

* Following sample must execute first,
    1) services-layer2-bridge-multicast-vpn-network-port-create
* VPLS Service must exist.

Description:

* It gets multicast service state configuration on the network port in a Virtual Private LAN Service(v-VPLS).
