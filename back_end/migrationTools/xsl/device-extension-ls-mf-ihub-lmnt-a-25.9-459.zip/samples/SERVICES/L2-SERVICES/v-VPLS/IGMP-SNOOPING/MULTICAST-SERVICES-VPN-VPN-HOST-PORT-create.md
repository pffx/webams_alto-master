This sample creates multicast service on the host port in a Virtual Private LAN Service(v-VPLS).

Pre-condition:

* Following sample must execute first,
    1) services-layer2-bridge-v-vpls-port-attach
* The VPLS service with service name must be exist.

Description:

* It creates multicast service on the host port in a Virtual Private LAN Service(v-VPLS)
