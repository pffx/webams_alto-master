This sample deletes LT/Uplink NT and LAG ports within unicast services
 
Pre-condition:

Following sample should be executed first

* services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create

Description:
  
* It deletes LT and Uplink NT and LAG ports within unicast services Virtual Private LAN Service(v-VPLS) configuration.
  
