This sample gets multicast service state configuration in a Virtual Private LAN Service(v-VPLS).

Pre-condition:

* VPLS Service must exist.

Description:

* It gets multicast service state configuration in a Virtual Private LAN Service(v-VPLS).
