This sample adds a port [represented by SAP] into m-VPLS service which represents a STP instance

Pre-condition:

* Following sample must execute first,
    1) services-layer2-protection-stp-instance-create
    2) transport-ethernet-port-network-port-create
*  A m-VPLS service which maps to RSTP instance should be present
