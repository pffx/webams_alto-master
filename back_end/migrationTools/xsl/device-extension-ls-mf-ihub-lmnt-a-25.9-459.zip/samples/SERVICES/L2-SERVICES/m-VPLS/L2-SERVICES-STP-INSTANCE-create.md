This sample creates a RSTP instance in Aggregation switch
 
* m-VPLS is representation of grouping of ports which participate in Rapid-Spanning-Tree RSTP protocol to ensure loop-free topology of traffic through those ports.
This procedure creates m-VPLS for 1st time in aggregation switch.
* RSTP protocol manages port forwarding states and will determine the port forward states of all VLANs for which the port is a member.
* RSTP defines three port states: discarding, learning, and forwarding and five port roles: root, designated, alternate, backup, and disabled.
* m-VPLS exclusively handles L2CP frames to support for STP

Pre-condition:

* Service name and id should not exist.
