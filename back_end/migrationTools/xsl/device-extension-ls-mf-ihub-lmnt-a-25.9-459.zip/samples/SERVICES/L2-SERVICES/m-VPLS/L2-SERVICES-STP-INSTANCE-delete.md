This sample deletes a RSTP instance from aggregation switch
 
Pre-condition:

* Following sample must execute first,
    * services-layer2-protection-stp-instance-create
* A m-VPLS service which maps to RSTP instance should be present
