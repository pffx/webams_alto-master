This sample deletes a port [represented by SAP] from m-VPLS service which represents a STP instance

Pre-condition:

* Following sample must execute first,
    1) services-layer2-protection-stp-instance-create
    2) transport-ethernet-port-network-port-create
   	3) services-layer2-protection-stp-instance-port-attach
*  A m-VPLS service which maps to RSTP instance should be present
