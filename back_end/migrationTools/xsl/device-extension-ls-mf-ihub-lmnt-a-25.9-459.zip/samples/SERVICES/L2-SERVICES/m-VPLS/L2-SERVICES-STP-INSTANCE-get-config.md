This sample retreives operational data of RSTP instance on Aggregation switch
 
Pre-condition:

* Following sample must execute first,
     services-layer2-protection-stp-instance-create
*  A m-VPLS service which maps to RSTP instance should be present
