This sample gets operational data of RSTP instance on Aggregation switch

Pre-condition:

* Following sample must execute first,
    services-layer2-m-vpls-stp-instance-create
* A m-VPLS service which maps to RSTP instance should be present
