This sample modifies parameters within rstp instance on service level

* This can cause a temporary blocking or unblocking of ports in respective VLANs associated with this STP instance [identified by m-VPLS service] 
till a loop free topology is identified with new configuration values specified for the port.

Pre-condition:

* Following sample must execute first,
	 services-layer2-protection-stp-instance-create
* A m-VPLS service which maps to RSTP instance should be present
