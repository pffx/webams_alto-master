This sample enables or disables the storm control on service level.
 
* It enables or disables the storm control on service level.

Pre-condition:

* Following sample must execute first,
    1) services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
