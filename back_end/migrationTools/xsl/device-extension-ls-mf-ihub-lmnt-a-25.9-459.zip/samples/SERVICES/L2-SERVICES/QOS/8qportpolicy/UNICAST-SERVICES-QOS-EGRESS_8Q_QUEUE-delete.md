This sample deletes weight/priority of queue in eight-queue policy mode.
 
Pre-condition:
  
* Following sample must execute first,
    1) services-layer2-traffic-management-egress-8q-scheduling-profile-create
* QoS eight-queue policy must exist.
 
Description:
  
* It deletes weight/priority of a queue in eight-queue policy mode.
