This sample detaches the egress policer profile association from service level. 

Pre-condition:


* Following sample must execute first,
    1) services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
    2) services-layer2-traffic-management-service-policer-create
    3) services-layer2-traffic-management-egress-policer-attach
 
* VPLS Service with egress rate-limit policer must exist.
 
Description:  
De-associate the policer with VPLS service configuration at egress level.
