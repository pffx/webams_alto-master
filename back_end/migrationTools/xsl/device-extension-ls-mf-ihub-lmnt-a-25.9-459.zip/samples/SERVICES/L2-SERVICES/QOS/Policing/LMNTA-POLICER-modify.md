This sample modifies the policer profile from system level.

Pre-condition:


* Following sample must execute first,
    1) services-layer2-traffic-management-service-policer-create
