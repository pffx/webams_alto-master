This sample retrieves the configuration of policer with default/pbit rate-limit.

Pre-condition:


* Following sample must execute first,
    1) services-layer2-traffic-management-service-policer-create

Description:
Retrieves the configuration of  policer with default/pbit rate-limit.
