This sample retrieves storm control configuration from system
 
* Retrieves storm control configuration.

Pre-condition:

* Following sample must execute first,
    1) services-layer2-traffic-management-storm-control-create
* Storm control configuration must exist.
