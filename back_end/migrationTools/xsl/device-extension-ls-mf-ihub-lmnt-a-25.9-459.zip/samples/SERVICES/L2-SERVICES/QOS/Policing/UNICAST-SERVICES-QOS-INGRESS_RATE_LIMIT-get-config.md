This sample retrieves the ingress policer configuration at service level.
 
Pre-condition:  


* Following sample must execute first,
    1)services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
	2) services-layer2-traffic-management-service-policer-create
	3) services-layer2-traffic-management-ingress-policer-attach
  
Description:  


* Retrieves the ingress rate limit per VPLS service configuration.
