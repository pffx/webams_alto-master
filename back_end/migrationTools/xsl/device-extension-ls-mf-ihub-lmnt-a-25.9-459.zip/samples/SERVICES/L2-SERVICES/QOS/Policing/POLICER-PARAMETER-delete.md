This sample deletes the default policer or particular pbit policer id from policer profile.

Pre-condition:


* Following sample must execute first, 
	1)services-layer2-traffic-management-service-policer-create 

Description:
Deletes the default policer or particular pbit policer id from policer profile.
