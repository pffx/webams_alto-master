This sample modifies storm control configuration.
 
* Modifies storm control configuration.
* Only either Aggregate or Individual (BC/MC/UUC) rate-limiters could exist in system and not both.

Pre-condition:

* Following sample must execute first,
    1) services-layer2-traffic-management-storm-control-create
* Storm control configuration must exist.
