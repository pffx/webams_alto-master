This sample deletes port QoS policy association from system level and resets it default policy
 
Pre-condition:
  
* Following sample must execute first,
    1) services-layer2-traffic-management-egress-8q-scheduling-profile-create 
* QoS eight queue policy must exist.
 
The following parameters have to be provided as input:
* None.

Description:
  
* It deletes user defined port QoS policy association from system level
* By default Port-qos policy 2 will be applied in system upon deleting any user defined association
