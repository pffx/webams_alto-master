This sample associates the ingress policer on service.

Pre-condition:  


* If only default rates are configured then policer can be associated to single service either for ingress or egress ratelimiting.
* If the policer has pbit profile, the policer can be applied for egress ratelimiting only
* Following sample must execute first,
    1) services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
    2) services-layer2-traffic-management-service-policer-create

Description:  
associate the policer with service for ingress rate-limit
