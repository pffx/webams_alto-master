This sample deletes storm control configuration.
 
* Deletes storm control configuration from system

Pre-condition:

* Following sample must execute first,
    1) services-layer2-traffic-management-storm-control-create
* Storm control configuration must exist.
