This sample retrieves eight queue mode policy configuration from system
 
Pre-condition:
  
* Following sample must execute first,
    services-layer2-traffic-management-egress-8q-scheduling-profile-create
* Eight queue policy must exist.
 
  
Description:
  
* It retrieves eight queue mode policy configuration from system
