This sample creates QoS eight-queue mode policy configuration.
 
Pre-condition:
  
* None
 
Description:
  
* It creates QoS eight-queue mode policy configuration. 
* The TC to queue mapping is fixed and cannot be modified
* User can configure Queue policy in eight-queue mode & create weight/priority of each queue's
* Default port-qos-policy in system should be 2[eight queue mode]
* For strict priority queue, queue and priority must be same.[i.e if weight is 0,queue number and priority must be same in LMNT-A]
* For weighted queue,priority is always 0.[i.e if weight not =0, priority must be 0 in LMNT-A]
* Valid configurable priority range is 0-7 in 8Qmode for LMNT-A

