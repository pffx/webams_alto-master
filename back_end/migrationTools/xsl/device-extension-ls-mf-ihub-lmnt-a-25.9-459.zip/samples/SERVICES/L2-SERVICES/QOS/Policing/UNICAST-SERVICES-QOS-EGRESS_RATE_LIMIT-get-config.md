This sample retrieves the egress policer configuration at service level
 
Pre-condition:  


* Following sample must execute first,
    1) services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
    2) services-layer2-traffic-management-service-policer-create
    3) services-layer2-traffic-management-egress-policer-attach
  
Description:

  
* Retrives the egress rate limit per VPLS service configuration.
