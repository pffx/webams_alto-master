This sample deletes the policer profile from system level.

Pre-condition:


* Following sample must execute first,
    1) services-layer2-traffic-management-service-policer-create
* Policer should not be associated in any service
