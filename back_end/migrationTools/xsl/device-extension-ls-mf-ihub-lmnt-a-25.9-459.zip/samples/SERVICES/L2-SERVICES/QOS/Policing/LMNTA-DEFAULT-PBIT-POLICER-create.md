This sample creates the policer profile in system level.



Pre-condition: None

Description:
Creates the default policer and pbit policer profile in system
