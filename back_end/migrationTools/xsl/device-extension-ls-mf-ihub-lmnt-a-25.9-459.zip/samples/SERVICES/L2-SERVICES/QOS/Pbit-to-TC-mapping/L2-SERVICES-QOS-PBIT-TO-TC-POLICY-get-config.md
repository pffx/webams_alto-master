This sample Retrieves the service ingress access Pbit to TC QoS policy configuration.
 
Pre-condition:

* Following sample must execute first,
  1) services-layer2-traffic-management-pbit-to-tc-policy-create
* Service Ingress QoS Policy must exist previously
 

