This sample retrieves the get state of policer with default/pbit rate-limit

Pre-condition: 


* Following sample must execute first,
    1)	services-layer2-traffic-management-service-policer-create

Description: 
Retrieves the get state of policer with default/pbit rate-limit.
