This sample delete ETH-CFM from the service.

* It delete ETH-CFM from the service.

Pre-condition:

* Following sample must execute first,
  1) services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
	2) services-layer2-oam-domain-create
	3) services-layer2-oam-association-create
  4) services-layer2-oam-lag-mep-association-create


