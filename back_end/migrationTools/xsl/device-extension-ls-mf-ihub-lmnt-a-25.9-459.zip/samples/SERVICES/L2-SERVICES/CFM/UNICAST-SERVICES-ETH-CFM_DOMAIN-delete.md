This sample deletes a ETH-CFM configuration.

* It deletes a ETH-CFM configuration.
 
 Pre-condition:

 * Following sample must execute first,
 1) services-layer2-oam-domain-create
