This sample is an action-rpc which will trigger ondemand lm test to measure frame loss ratio for mep mac where y1731 is configured.When y1731 is not configured , this test will not be initiated, when y1731 priorities changes beteen initiator and responder,test will not be initiated.

Pre-condition:
* Following sample must execute first,
    1) services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
    2) services-layer2-oam-domain-create
    3) services-layer2-oam-association-create
    4) services-layer2-oam-port-mep-association-create    

