This sample creates Y1731 proactive sessions.

* It creates a Y1731 proactive session with the given md-index, md-admin-name , local mep and peer mep mac address.
* The test type for Y1731 wil be any of the below values
  two-way-delay,two-way-slm,single-end-loss


Pre-condition:
* Following sample must execute first,
    1) services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
    2) services-layer2-oam-domain-create
    3) services-layer2-oam-association-create
    4) services-layer2-oam-port-mep-association-create


