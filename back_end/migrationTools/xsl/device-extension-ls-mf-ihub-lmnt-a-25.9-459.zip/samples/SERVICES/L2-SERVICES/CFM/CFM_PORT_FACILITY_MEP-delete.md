This sample deletes a ETH-CFM MEP configuration from port

 
Pre-condition:

* Following sample must execute first,
 1) services-layer2-oam-domain-create
 2) services-layer2-oam-association-create
 3) transport-ethernet-port-facility-mep-create
