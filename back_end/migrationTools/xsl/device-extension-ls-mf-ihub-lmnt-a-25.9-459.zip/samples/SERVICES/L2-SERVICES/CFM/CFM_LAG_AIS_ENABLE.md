This sample enables ais to the service in lag SAP.
 
Pre-condition:

* Following sample must execute first,
    1) services-layer2-oam-domain-create
    2) services-layer2-oam-association-create
    3) transport-ethernet-lag-port-create
    4) transport-ethernet-lag-facility-mep-create
    5) services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create

* Only one sap with ais enabled is allowed in the service.
