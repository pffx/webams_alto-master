This sample creates a MEP(Maintenance Endpoint) on top of LAG interface

* It creates a MEP(Maintenance Endpoint) on top of LAG interface
* It also allows enabling/disabling y1731 monitoring functions in responder mode under EthCFM mep in down direction.
* y1731pm-lm-dot1p values can be given only if y1731pm-enable in set to true.
* Either y1731pm-lm-dot1p all or y1731pm-lm-dot1p dot1p [value] , can only be configured.
 
Pre-condition:

* Following sample must execute first,
	1) services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
	2) services-layer2-oam-domain-create
	3) services-layer2-oam-association-create
