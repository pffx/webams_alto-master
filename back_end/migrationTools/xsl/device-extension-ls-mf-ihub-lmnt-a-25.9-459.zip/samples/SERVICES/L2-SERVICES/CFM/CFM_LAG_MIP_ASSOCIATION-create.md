This sample adds ETH-CFM MIP to the service in lag SAP.
 

Pre-condition:

* Following sample must execute first,
    1) services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
    2) services-layer2-oam-domain-create
    3) services-layer2-oam-association-create

