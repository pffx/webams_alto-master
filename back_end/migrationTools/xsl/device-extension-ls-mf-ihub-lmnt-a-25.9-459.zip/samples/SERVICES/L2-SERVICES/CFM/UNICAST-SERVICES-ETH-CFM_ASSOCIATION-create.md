This sample creates a association in ETH-CFM domain.

* It creates a association in ETH-CFM domain.
 
Pre-condition:
* Following sample must execute first,
    services-layer2-oam-domain-create

* Any one of the below parameter must be present,

  * ICC-BASED (String)
  * ICC-INTEGER (Range 0 to 65535)
  * ICC-STRING (String)
  * VID (Range 0 to 4094)
  * VPN-ID (<vpn identifier with id> - <xxxxxx:xxxxxxxx>)

* If format parameter is none in domain creation only then ICC-BASED can be used in association.
* To create a MEP, REMOTE-MEP parameter must be configured. Similarly, to create a MIP, MHF-CREATION parameter must be configured.
* To create Facility MEP, bridge identifier should not be configured. Domain level should be 0 or 1. If domain level is 1 then ais level should be greater than 1.
