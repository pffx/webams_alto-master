This sample retrieves Fault Management CFM statistics for Loopback and LinkTrace on corresponding MEP.

 
Pre-condition:

* Following sample must execute first,
    1) services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
    2) services-layer2-oam-domain-create
    3) services-layer2-oam-association-create
    4) services-layer2-oam-port-mep-association-create
    5) services-layer2-oam-linktrace
    6) services-layer2-oam-loopback 
