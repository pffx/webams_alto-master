This sample enables ais to the service in port SAP.
 
Pre-condition:

* Following sample must execute first,
    1) services-layer2-oam-domain-create
    2) services-layer2-oam-association-create
    3) transport-ethernet-port-facility-mep-create
    4) services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create

* Only one sap with ais enabled is allowed in the service.
