This sample is an action-rpc which will trigger ondemand slm test to measure the near and far end loss from initiator where y1731 is configured.When y1731 is not configured on peer, this test will not be initiated.
Pre-condition:
* Following sample must execute first,
    1) services-layer2-bridge-v-vpls-create or services-layer2-cross-connect-v-vpls-create
    2) services-layer2-oam-domain-create
    3) services-layer2-oam-association-create
    4) services-layer2-oam-port-mep-association-create    

