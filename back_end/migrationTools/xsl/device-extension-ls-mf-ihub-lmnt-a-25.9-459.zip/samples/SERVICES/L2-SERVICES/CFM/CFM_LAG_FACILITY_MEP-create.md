This sample adds ETH-CFM MEP to the lag
 

Pre-condition:

* Following sample must execute first,
    1) services-layer2-oam-domain-create
    2) services-layer2-oam-association-create
    3) transport-ethernet-lag-port-create

