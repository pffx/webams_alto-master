This sample adds ETH-CFM MEP to the port
 

Pre-condition:

* Following sample must execute first,
    1) services-layer2-oam-domain-create
    2) services-layer2-oam-association-create

* Port Facility mep creation is not allowed on Residential port.

