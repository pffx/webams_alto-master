This sample gets a ETH-CFM configuration.

* It gets a ETH-CFM configuration.
 
Pre-condition:

* Following sample must execute first,
    1) services-layer2-oam-domain-create
