This sample creates a ETH-CFM domain.

* It creates a ETH-CFM domain with the given md-index, md-admin-name and level
* If FORMAT is none then following parameters are not required,
  DNS, MAC, NAME.
* If FORMAT is not none then any-one of the following parameters must be present,
  DNS, MAC, NAME.

Pre-condition:

* None.
