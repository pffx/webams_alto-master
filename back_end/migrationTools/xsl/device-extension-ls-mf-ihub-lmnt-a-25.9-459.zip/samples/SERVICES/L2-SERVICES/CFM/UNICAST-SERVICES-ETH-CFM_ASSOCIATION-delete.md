This sample deletes a association in domain of ETH-CFM configuration.
 
* It deletes a ETH-CFM configuration.

Pre-condition:

* Following sample must execute first,
    1) services-layer2-oam-domain-create
    2) services-layer2-oam-association-create
