This sample creates a user defined Pbit and DSCP marking for SGT on VPRN service

Pre-condition:
* services-layer3-ipv4-vprn-router-create

Description:
* It creates a Pbit and DSCP marking for SGT configuration.
  Pbit and DSCP marking for SGT will be applied on a per protocol basis for VPRN.
  Creation of Pbit and DSCP mapping will be available under specific VPRN instances.
