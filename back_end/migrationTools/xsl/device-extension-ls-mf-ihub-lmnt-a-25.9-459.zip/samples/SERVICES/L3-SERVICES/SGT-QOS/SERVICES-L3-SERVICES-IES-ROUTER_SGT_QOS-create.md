This sample creates user defined Pbit and DSCP marking for SGT on Router instance

Pre-condition:
* None

Description:
* It creates a Pbit and DSCP marking for SGT configuration. Pbit and DSCP marking for SGT will be applied on a per protocol basis for IES base router. Creation of Pbit and DSCP mapping will be available under specific router instances.
