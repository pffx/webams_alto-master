This sample deletes a user defined Pbit and DSCP marking for SGT packets on router interface.

Pre-condition:
* Following sample must execute first,
    services-layer3-ipv4-traffic-management-ies-router-sgt-qos-create

Description:
* It deletes user defined Pbit and DSCP marking for SGT packets on router interface.
After deleting dscp/do1tp values are restored to default values.
