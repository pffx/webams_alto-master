This sample deletes user defined Pbit and DSCP marking for SGT on VPRN service

Pre-condition:
* Following sample must execute first,
  services-layer3-ipv4-traffic-management-vprn-router-sgt-qos-create

Description:
* It deletes user defined Pbit and DSCP marking for SGT on VPRN service.
After deleting the dot1p/dscp values,it will restore to default value.
