This sample retrieves a Pbit and DSCP marking for SGT on VPRN service.

Pre-condition:
* Following sample must execute first,
    services-layer3-ipv4-traffic-management-vprn-router-sgt-qos-create

Description:
* It retrieves a Pbit and DSCP marking for SGT on VPRN service.
