This sample retrieves Pbit and DSCP marking for SGT on router interface.

Pre-condition:
* Following sample must execute first,
    services-layer3-ipv4-traffic-management-ies-router-sgt-qos-create

Description:
* It retrieves Pbit and DSCP marking for SGT on router interface.
