This sample gets dhcp statistics information from ies interface in ies service.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-subscriber-ies-interface-dhcp-create

Description:

This sample gets dhcp statistics information from ies interface in ies service.
