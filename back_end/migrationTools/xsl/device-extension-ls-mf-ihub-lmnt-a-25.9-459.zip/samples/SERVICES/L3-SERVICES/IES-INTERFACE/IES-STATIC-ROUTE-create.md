This sample creates a static route for destination IP address.

Description:

* It creates a static route for destination IP address.
