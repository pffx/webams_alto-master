This sample gets state information of static routes.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-ies-static-route-create

Description:

* It gets state information of static routes.
