This sample gets ICMP configuration on IES (Base) router interface.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-ies-interface-icmp-create

Description:

* It gets ICMP configuration on IES (Base) router interface.
