This sample creates a dhcp relay instance for corresponding ies interface in ies service.

Pre-condition:

* IES interface must be exist.
* GI-ADDRESS must be same as primary interface IP address of the IES interface.
* LINK-SELECTION-IP address must be one of secondary address configured on the IES interface.

Description:

* It creates a dhcp relay instance for corresponding ies interface in ies service. IES interface must be a user/client interface.
