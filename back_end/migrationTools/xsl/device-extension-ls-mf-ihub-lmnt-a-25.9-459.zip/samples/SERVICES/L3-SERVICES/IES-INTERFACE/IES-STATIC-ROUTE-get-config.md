This sample gets static routes for destination IP address.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-ies-static-route-create

Description:

* It gets static routes for destination IP address.
