This sample deletes a static route for destination IP address.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-ies-static-route-create

Description:

* It deletes a static route for destination IP address.
