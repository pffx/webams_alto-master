*This sample is used to retrieve the input of oamsave (true or false) associated to the given ies interface.

1) Retrieves the value of oamsave which specifies whether an interface configuration is preserved during upgrade with default db reboot/upgrade.

Pre-condition:

*Following sample must execute first,
1) services-layer3-ipv4-ies-interface-create
