This sample creates ECMP.

Description:

* This sample enables ECMP and configures the number of routes for path sharing.
