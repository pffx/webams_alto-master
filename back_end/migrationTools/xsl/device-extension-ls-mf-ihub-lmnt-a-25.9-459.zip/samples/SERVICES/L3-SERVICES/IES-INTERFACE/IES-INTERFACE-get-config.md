This sample gets IP interface configurations within IES (Base) router instance

Pre-condition:


* Following sample must execute first,
    1) services-layer3-ipv4-ies-interface-create

Description:


* It gets IP interface configurations within IES (Base) router instance.
