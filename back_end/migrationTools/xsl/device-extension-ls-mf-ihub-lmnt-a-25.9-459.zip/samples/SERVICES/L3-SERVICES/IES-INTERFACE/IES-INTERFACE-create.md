This sample creates an IP interface within IES (Base) router instance.

Pre-condition:


* VPLS service must exist with this VLAN ID.
* IES service must exist.

Description:


* It creates an IP interface within IES (Base) router instance.
