This sample gets ecmp configuration.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-ies-ecmp-route-create

Description:

* It gets number of equal cost routes configured on the routing table
instance.
