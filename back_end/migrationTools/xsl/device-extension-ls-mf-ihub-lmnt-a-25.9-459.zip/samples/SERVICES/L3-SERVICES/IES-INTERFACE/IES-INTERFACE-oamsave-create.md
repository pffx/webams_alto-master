*This sample is used to identify the given ies interface as a protected interface, so as to enable the retention of the interface configurations and its underlying service/port properties etc when a default db is triggered.

1) The value of oamsave specifies whether an interface configuration is preserved during upgrade with default db reboot/upgrade.

Pre-condition:

*Following sample must execute first,
1) services-layer3-ipv4-ies-interface-create
