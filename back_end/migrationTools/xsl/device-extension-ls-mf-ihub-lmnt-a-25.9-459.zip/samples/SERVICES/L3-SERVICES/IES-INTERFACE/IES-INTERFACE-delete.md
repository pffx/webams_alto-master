This sample deletes an IP interface within IES (Base) router instance.

Pre-condition:


* Following sample must execute first,
    1) services-layer3-ipv4-ies-interface-create

Description:


* It deletes an IP interface within IES (Base) router instance.
