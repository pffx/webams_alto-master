This sample gets state information of IP interface configurations within IES (Base) router instance.

Pre-condition:


* Following sample must be executed first,
    1) services-layer3-ipv4-ies-interface-create

Description:


* It gets state information of IP interface configurations within IES (Base) router instance.
