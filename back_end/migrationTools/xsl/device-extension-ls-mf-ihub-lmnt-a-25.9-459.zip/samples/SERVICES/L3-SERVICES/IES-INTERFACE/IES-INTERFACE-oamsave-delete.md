This sample is used to remove the given ies interface as a protected interface, so as to disable the retention of the interface configurations and its underlying service/port properties etc when a default db reset is triggered.

Pre-condition:

*Following sample must execute first,
1) services-layer3-ipv4-ies-interface-create
