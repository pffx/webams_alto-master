This sample deletes ecmp.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-ies-ecmp-route-create

Description:

* It deletes ecmp.
