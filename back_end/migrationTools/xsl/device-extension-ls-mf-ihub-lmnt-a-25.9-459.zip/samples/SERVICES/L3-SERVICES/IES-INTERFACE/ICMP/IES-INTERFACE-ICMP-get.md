This sample gets state information of ICMP on IES (Base) router interface.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-ies-interface-icmp-create

Description:

* It gets state information of ICMP on IES (Base) router interface.
