This sample creates ICMP on IES (Base) router interface.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-ies-interface-create
* IES interface in IES service must be exist.

Description:

* It creates ICMP on IES (Base) router interface.
