This sample creates link local address on an IES interface.

Pre-condition:

* IES service must exist.
* IES interface in IES service must exist.
* Following sample must be executed first,
    1) services-layer3-ipv6-ies-interface-create

Description:

* It creates link local address on an IES interface.
