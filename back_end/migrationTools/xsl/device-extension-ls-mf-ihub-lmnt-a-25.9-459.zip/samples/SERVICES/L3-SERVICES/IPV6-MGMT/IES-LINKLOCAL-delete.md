This sample deletes link local address of IES interface in IES service.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-ipv6-ies-linklocal-create

Description:

* It deletes link local address of IES interface in IES service.
