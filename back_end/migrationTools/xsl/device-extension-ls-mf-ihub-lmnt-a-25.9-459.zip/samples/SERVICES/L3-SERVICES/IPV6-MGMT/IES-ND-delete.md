This sample deletes ND on IES interface.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-ipv6-ies-nd-create

Description:

* It deletes ND on IES interface.
