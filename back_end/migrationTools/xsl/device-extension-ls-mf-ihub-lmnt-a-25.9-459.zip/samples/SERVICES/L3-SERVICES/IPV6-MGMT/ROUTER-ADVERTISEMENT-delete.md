This sample deletes router-advertisement.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-ipv6-router-advertisement-create

Description:

* It deletes router-advertisement.
