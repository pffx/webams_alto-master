This sample creates a static route for destination IPv6 address.

Description:

* It creates a static route for destination IPv6 address.
