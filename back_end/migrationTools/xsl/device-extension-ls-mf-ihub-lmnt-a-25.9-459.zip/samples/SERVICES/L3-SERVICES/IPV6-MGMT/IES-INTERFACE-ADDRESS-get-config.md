This sample gets IPv6 address of IES interface in IES service.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-ipv6-ies-interface-create

Description:

* It gets IPv6 address of IES interface in IES service.
