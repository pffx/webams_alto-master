This sample gets a static route state for destination IPv6 address.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv6-static-route-create

Description:

* It gets a static route state for destination IPv6 address.
