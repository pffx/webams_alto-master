This sample creates router-advertisement on an IES interface.

Pre-condition:

* IES interface in IES service must exist
* Following sample must be executed first,
    1) services-layer3-ipv6-ies-interface-create

Description:

* It creates router-advertisement on an IES interface.
