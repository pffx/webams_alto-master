This sample modifies link local address of IES interface in IES service.

Pre-condition:

* IES service - service name must exist.
* IES interface in IES service must exist.
* Following sample must be executed first,
    1) services-layer3-ipv6-ies-linklocal-create

Description:

* It modifies link local address of IES interface in IES service.
