This sample gets ICMPv6 parameters of IES interface in IES service.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-ipv6-ies-icmpv6-create

Description:

* It gets ICMPv6 parameters of IES interface in IES service.
