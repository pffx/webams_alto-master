This sample deletes ICMPv6 on IES interface.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-ipv6-ies-icmpv6-create

Description:

* It deletes ICMPv6 on IES interface.
