This sample gets router-advertisement state of IES interface.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv6-router-advertisement-create

Description:

* It gets router-advertisement state of IES interface.
