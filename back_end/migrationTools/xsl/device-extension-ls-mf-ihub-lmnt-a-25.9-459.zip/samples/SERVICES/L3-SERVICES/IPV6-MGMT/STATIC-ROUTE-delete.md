This sample deletes a static route for destination IPv6 address.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv6-static-route-create

Description:

* It deletes a static route for destination IPv6 address.
