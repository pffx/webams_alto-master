This sample deletes corresponding router-advertisement prefix on an IES interface.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-ipv6-router-advertisement-create
* IES interface in IES service must exist.

Description:

* It deletes corresponding router-advertisement prefix on an IES interface.
