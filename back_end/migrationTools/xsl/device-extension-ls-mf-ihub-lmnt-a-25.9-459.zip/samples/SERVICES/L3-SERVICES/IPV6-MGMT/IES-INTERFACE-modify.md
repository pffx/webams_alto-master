This sample modifies IPv6 IES interface in IES service.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-ipv6-ies-interface-create
* IES interface in IES service must exist.

Description:

* It modifies IPv6 IES interface in IES service.
