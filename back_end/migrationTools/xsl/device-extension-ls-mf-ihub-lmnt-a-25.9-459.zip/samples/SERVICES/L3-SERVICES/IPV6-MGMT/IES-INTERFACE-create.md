This sample creates IPv6 IES interface in IES service.

Pre-condition:

* VPLS service must exist with this VLAN ID.
* IES service must exist.

Description:

* It creates IPv6 IES interface in IES service.
