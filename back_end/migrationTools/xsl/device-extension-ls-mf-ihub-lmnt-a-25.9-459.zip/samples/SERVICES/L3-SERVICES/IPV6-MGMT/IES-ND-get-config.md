This sample gets ND parameters of IES interface in IES service.

Pre-condition:

* Following sample must be executed first,
    1) services-layer3-ipv6-ies-nd-create

Description:

* It gets ND parameters of IES interface in IES service.
