This sample gets state information of an IP ACL filter policy.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-security-ip-filter-profile-create

Description:

* This sample retrieves the current association of this filter with all entries associated with it.
