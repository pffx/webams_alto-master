This sample creates an IP ACL filter policy.

Description:

* It creates an IP ACL filter policy based on match criteria and action.
