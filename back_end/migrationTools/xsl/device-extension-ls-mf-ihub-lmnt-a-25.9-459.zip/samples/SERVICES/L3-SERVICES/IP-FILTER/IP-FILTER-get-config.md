This sample gets an IP ACL filter policy configuration.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-security-ip-filter-profile-create

Description:

* It gets an IP ACL filter policy configuration.
