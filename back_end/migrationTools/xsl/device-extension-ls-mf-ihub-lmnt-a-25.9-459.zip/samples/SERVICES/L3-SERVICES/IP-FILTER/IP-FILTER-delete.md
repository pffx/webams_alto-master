This sample deletes an IP ACL filter policy.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-security-ip-filter-profile-create

Description:

* It deletes an IP ACL filter policy.
