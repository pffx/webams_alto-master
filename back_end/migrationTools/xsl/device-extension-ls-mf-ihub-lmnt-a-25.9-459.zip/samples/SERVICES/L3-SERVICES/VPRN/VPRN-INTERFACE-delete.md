This sample deletes a vprn interface in vprn service.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-vprn-interface-create

Description:

* It deletes a vprn interface in vprn service.
