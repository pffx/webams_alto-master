This sample gets state configuration of vprn router.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-vprn-router-create
* VPRN Service must exist.

Description:

* It gets state configuration of vprn router.
