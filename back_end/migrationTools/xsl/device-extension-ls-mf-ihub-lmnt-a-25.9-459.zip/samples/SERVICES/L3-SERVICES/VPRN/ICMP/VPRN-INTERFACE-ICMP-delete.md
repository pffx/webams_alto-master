This sample deletes ICMP on VPRN interface.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-vprn-interface-icmp-create
* VPRN interface in VPRN service must be exist.

Description:

* It deletes ICMP on VPRN interface.
