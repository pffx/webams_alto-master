This sample updates a static route for destination IP address in vprn service.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-vprn-static-route-create

Description:

* The sample identifies a static route using the destination IP address, next-hop address and VPRN interface used to reach destination.  The static route can be modified by changing the Interface or changing priority for an interface to choose the highest preference interface to reach a destination. Similarly if multiple next-hop routers are available, the next-hop router preference can be set. This configuration can cause the static route to use a different local interface or a different next-hop to reach same destination
