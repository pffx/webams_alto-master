This sample gets a vprn router configuration.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-vprn-router-create
* VPRN Service must exist.

Description:

* It gets a vprn router configuration.
