This sample gets dhcp statistics information from vprn interface in vprn router.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-subscriber-vprn-interface-dhcp-create

Description:

This sample gets DHCP statistics information from vprn interface in vprn router.
