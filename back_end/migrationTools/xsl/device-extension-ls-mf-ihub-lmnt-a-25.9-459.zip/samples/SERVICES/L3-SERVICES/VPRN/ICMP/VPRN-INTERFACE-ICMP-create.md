This sample creates ICMP on VPRN interface.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-vprn-interface-create
* VPRN interface in VPRN service must exist.

Description:

* It creates ICMP on VPRN interface.
