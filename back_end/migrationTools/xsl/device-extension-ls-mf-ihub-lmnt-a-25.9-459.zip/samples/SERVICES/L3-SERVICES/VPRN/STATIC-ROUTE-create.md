This sample creates a static route for destination IP address.

Pre-condition:

* VPRN service must exist

Description:

* It creates a static route for destination IP address.
