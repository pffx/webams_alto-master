This sample gets ICMP configuration on VPRN interface.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-vprn-interface-icmp-create

Description:

* It gets ICMP configuration on VPRN interface.
