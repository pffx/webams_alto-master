This sample gets state information of static routes in vprn service.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-vprn-static-route-create

Description:

* It gets state information of static routes in vprn service.
