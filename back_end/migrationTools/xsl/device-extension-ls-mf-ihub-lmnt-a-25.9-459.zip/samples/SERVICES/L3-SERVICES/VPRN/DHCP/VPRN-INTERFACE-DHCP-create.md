This sample creates a DHCP relay instance for corresponding VPRN interface in VPRN router.

Pre-condition:

* VPRN router and interface must be exist.
* GI-ADDRESS must be same as primary interface IP address of the VPRN interface.
* LINK-SELECTION-IP address must be one of secondary address configured on the VPRN interface.

Description:

* It creates a DHCP relay instance for corresponding VPRN interface in VPRN router. VPRN interface must be a user/client interface.
