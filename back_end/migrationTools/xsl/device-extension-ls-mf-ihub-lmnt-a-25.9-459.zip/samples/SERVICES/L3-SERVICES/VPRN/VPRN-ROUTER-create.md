This sample creates vprn router.

Pre-condition:

* VPRN service must exist.

Description:

* It creates vprn router.
