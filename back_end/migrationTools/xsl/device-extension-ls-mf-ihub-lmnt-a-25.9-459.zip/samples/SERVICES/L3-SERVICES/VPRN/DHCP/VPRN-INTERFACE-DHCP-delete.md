This sample deletes a DHCP relay instance for corresponding VPRN interface in VPRN router.

Pre-condition:

* VPRN router & interface must be exist.

Description:

* It deletes a DHCP relay instance for corresponding VPRN interface in VPRN router.
