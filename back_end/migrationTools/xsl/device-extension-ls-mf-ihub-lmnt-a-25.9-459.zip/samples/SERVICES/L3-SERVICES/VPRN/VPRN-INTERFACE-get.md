This sample gets state configuration of VPRN interface.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-vprn-interface-create
* VPRN Service must exist.

Description:

* It gets state configuration of VPRN interface.
