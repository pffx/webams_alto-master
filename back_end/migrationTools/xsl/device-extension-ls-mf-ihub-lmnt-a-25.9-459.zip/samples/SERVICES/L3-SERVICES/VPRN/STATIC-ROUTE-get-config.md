This sample gets static routes for destination IP address in vprn service.

Pre-condition:

* Following sample must execute first,
    1) services-layer3-ipv4-vprn-static-route-create

Description:

* It gets static routes for destination IP address in vprn service.
