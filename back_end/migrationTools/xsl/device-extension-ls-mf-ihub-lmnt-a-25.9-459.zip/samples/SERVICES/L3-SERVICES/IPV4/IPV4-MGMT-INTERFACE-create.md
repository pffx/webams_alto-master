This sample creates IPV4 management interface with end to end config.

Description:

* As part of current macro, VLAN service id 4000 will be created.
