This sample creates CPU ports as Mirror Source
 
Pre-condition:

* Mirror dest should be already configured.
* Mirror source service name should be same as mirror destination service name.
 
Description:  

* It creates CPU ports as Mirror Source for both ingress and egress direction.

