This sample creates SAP Mirror Source
 
Pre-condition:

* Mirror dest should be already configured.
* Mirror source service name should be same as mirror destination service name.
 
Description:  

* It creates Mirror Source SAP with Uplink NT/LT/LAG port for ingress direction only.

