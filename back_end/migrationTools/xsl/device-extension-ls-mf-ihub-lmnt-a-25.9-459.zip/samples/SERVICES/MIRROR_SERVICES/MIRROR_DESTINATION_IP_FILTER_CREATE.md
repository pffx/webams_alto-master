This sample creates Mirror Destination service with ip filter
 
Pre-condition:

* Service name and service id should not exist in any of the other existing services.
* IP filter created before associating with mirror service.  

Description:  

* It associates mirror destination SAP with an IP filter.
