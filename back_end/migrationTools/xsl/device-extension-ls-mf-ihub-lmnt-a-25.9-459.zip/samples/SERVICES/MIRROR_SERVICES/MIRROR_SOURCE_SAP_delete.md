This sample delete  Mirror SAP Source
 
Pre-condition:

* Mirror source service and sap should be already configured.
 
Description:  

* It deletes Mirror Source SAP with Uplink NT/LT/LAG port.

