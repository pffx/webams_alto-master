This sample creates Mirror Destination sap
 
Pre-condition:

* Service name and service id should not exist in any of the other existing services.
 
Description:  

* It configures a mirror destination SAP on uplink NT ports or AI port(1/5/3).
