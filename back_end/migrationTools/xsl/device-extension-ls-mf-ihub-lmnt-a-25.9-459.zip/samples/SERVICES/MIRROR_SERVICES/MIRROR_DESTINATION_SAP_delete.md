This sample delete Mirror Destination sap
 
Pre-condition:

* mirror destination service and sap should present.
 
Description:  

* It delete a mirror destination SAP on uplink NT port or AI port(1/5/3).
