This sample delete Port Mirror Source
 
Pre-condition:

* Port as Mirror Source should already present.

Description:  

* It deletes Uplink NT/LT/LAG port as Mirror Source.

