This sample delete Mirror Source service
 
Pre-condition:

* Mirror source service should exist.
 
Description:  

* It deletes Mirror Destination service with using service name.

