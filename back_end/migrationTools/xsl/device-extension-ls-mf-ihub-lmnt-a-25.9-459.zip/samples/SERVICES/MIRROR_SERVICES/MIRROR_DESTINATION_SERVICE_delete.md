This sample delete Mirror Destination service
 
Pre-condition:

* mirror destination service should present. 

Description:  

* It delete Mirror Destination service with using service name.

