Configure or Modify a transceiver's digital diagnostic monitoring threshold configuration attached to port.
 
Pre-condition:

* Following sample must executed first,
    1) equipment-ddm-transceiver-profile-create
	2) equipment-ddm-lane-profile-create
* Create a transceiver or lane profile to trigger an alarm based on threshold values.

Description:

* Transceiver’s digital diagnostic monitoring threshold configuration is applicable to all uplink ports, except lt mda ports, connector child ports, non-sfp mda ports, and virtual mda ports.
* For non-connector ports, parameters are monitored on lane 1.
* The digital diagnostic monitoring function can be enabled or disabled as needed.
* Each port is associated with one transceiver profile.
* Up to four different or identical lane profiles can be associated with a port.
* Digital diagnostic monitoring threshold configuration is not supported with externally calibrated transceivers.
