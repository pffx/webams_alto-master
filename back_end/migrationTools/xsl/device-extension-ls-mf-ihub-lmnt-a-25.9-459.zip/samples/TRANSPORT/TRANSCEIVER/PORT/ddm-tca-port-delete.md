This sample deletes transceiver's digital diagnostic monitoring threshold data attached to port.
 
Pre-condition:

* Following sample must executed first to delete the associated profile,
    1) equipment-ddm-transceiver-profile-create
    2) equipment-ddm-lane-profile-create

Description: 

* The digital diagnostic monitoring threshold configuration attached to the port is deleted.
* The digital diagnostic monitoring parameter is deleted.
* The associated lane profile attached to the port is deleted.
* The associated transceiver profile attached to the port is deleted.

