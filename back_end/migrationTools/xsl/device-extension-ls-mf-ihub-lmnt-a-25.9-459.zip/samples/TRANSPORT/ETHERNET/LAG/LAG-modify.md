This sample modifies static/dynamic Link Aggregation Group(LAG) configuration.

* It modifies static/dynamic Link Aggregation Group(LAG) configuration.
 
Pre-condition:

* Following sample must execute first,
    1) transport-ethernet-lag-port-create
