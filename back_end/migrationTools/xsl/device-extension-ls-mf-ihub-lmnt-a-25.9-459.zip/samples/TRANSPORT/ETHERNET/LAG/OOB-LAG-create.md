This sample creates a static OOB LAG (Link Aggregation Group) configuration.

Pre-condition:


* LACP cannot be enabled on an OOB lag
* Other type of ports(qsfp,sfp,xfp) cannot be added to OOB lag.
