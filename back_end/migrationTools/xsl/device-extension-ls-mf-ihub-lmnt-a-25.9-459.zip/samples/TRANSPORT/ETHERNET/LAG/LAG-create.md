This sample creates a static/dynamic Link Aggregation Group(LAG) configuration with uplink NT ports
 
Pre-condition:

* None
 
If LACP-MODE and ADMINSTRATIVE-KEY is given as input to sample then dynamic LAG is created,if these parameters are empty then static
LAG is created
  
Description:
  
* It creates a Link Aggregation Group (LAG) configuration & Add port to it. LAG can be
  used to group up to eight ports into one logical link. The aggregation of multiple
  physical links allows for load sharing and offers seamless redundancy.
