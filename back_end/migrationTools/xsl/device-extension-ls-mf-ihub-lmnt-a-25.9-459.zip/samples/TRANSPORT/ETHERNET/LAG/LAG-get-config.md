This sample retrieves the static/dynamic Link Aggregation Group(LAG) configuration.

* It retrieves the static/dynamic Link Aggregation Group(LAG) configuration for the particular LAG.
 
Pre-condition:
 
* Following sample must execute first,
    1) transport-ethernet-lag-port-create
