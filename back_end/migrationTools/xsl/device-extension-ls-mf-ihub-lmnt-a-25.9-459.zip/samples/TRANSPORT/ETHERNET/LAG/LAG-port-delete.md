This sample deletes uplink port from the static/dynamic Link Aggregation Group(LAG) configuration.
 
Pre-condition:

* Following sample must execute first,
    transport-ethernet-lag-port-create
 
Description:
  
* It deletes uplink port from the static/dynamic Link Aggregation Group(LAG) configuration.
