This sample retrieves the static/dynamic Link Aggregation Group(LAG) operational status.

* It retrieves the static/dynamic Link Aggregation Group(LAG) operational status
 
Pre-condition:
 
* Following sample must execute first,
    1) transport-ethernet-lag-port-create
