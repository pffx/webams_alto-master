This sample associates the lag-subgroup to a port.

Pre-condition:


* Following sample must be executed already,
     i.transport-ethernet-lag-subgroup-create
* LAG already existing in running db.
