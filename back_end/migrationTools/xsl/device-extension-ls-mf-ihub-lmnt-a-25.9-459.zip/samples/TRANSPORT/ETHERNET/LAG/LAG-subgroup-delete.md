This sample deletes a LAG Subgroup configuration.

* It deletes a LAG-subgroup Configuration with the LAG-ID.

Pre-condition:


* Following sample must execute first,
    1) transport-ethernet-lag-subgroup-create
* The LAG must exist with particular LAG-ID and a subgroup-id.

