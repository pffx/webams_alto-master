This sample modifies LAG-SUBGROUP parameters configuration.

* It modifies static/dynamic Link Aggregation Group(LAG) configuration.

Pre-condition:


* Following sample must execute first,
    1) transport-ethernet-lag-subgroup-create
* Modification is applicable only if shut/no shut is given.
