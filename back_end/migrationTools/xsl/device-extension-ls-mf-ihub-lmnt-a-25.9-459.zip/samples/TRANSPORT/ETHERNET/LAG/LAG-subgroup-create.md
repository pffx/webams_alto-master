This sample creates a static/dynamic LAG (Link Aggregation Group) subgroup configuration.

Pre-condition:


* Following sample must be executed already,
     i.transport-ethernet-lag-port-create
* LAG already existing in running db.

