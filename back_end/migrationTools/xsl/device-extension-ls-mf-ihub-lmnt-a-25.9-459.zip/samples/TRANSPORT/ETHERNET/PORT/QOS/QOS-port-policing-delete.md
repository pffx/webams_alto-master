This sample deletes the port level egress rate limiting configuration.

* It deletes the port level egress rate limiting configuration.
 
Pre-condition:

* Following sample must executed first,
    transport-ethernet-port-network-port-modify
* Egress rate configuration must exist in port level.
