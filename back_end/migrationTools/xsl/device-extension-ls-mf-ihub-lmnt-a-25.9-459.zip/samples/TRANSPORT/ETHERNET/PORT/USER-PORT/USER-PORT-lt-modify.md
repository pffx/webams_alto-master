This sample modifies a LT port configuration data.
 
Pre-condition:

* Following sample must execute first,
     transport-ethernet-port-user-port-create 
  
Description:
  
* It modifies a LT port configuration data.

* For LMNT-A the maximum burst which can be set for port egress rate in restricted to 16380 KiloBytes
