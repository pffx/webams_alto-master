This sample creates a lldp configuration under port level.
 
Pre-condition:

* None  

Description:

* This sample enables the context to configure Link Layer Discovery Protocol (LLDP) parameters on the specified port.
* mac-type -  configures destination MAC address parameters (nearest-bridge,nearest-non-tpmr,nearest-customer)
* port-id-subtype -  Port identifier TLVs transmitted to peer (tx-local,tx-if-name)
* receive - LLDP agent will receive, but will not transmit LLDP frames on this port
* transmit - LLDP agent will transmit LLDP frames on this port and will not store any information about the remote systems connected
* port-desc - The LLDP agent should transmit port description TLVs
* sys-name -  The LLDP agent should transmit system name TLVs
* sys-desc - The LLDP agent should transmit system description TLVs
* sys-cap - The LLDP agent should transmit system capabilities TLVs
* tx-mgmt-address  - system/system-ipv6  - Specifies to use the system IP address. Note that the system address will only be transmitted once it has been configured if this parameter is specified.
* tx-mgmt-address  - node-ipv4/node-ipv6  - Specifies to use the management IPV4/V6 address. Note that the management address will only be transmitted once it has been configured as parameter under port property. For node-ipv4/node-ipv6 , ip will be retrieved from interface/address specified under node-ip under system.
* tx-mgmt-address  - This field can have either system/system-ipv6 address or node-ipv4/node-ipv6 address.

