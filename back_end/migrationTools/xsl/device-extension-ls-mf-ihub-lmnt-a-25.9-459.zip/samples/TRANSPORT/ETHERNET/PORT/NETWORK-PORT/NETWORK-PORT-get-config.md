This sample retrieves network port configuration data.
 
Pre-condition:

* Following sample must execute first,
    1)transport-ethernet-port-network-port-create

Description:

* It retrieves network port configuration data.
