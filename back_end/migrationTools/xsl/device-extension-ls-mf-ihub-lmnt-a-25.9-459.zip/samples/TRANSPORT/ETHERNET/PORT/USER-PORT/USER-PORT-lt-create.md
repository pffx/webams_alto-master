This sample creates a LT port configuration data.
 
Pre-condition:

Following sample should be executed first
equipment-lt-mda-create
  
Description:
  
* It creates a LT port configuration data.
