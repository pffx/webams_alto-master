This sample deletes a port configuration.
 
Pre-condition:
  
* Following sample must execute first,
    1) transport-ethernet-port-network-port-create
	
  
Description:
  
* It deletes a port configuration.
