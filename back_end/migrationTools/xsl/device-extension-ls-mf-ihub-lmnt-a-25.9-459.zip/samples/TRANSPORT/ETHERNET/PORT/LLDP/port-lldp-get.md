This sample retrieves port lldp remote-system operational data.
 
Pre-condition:

* Following sample must execute first,
    1) transport-ethernet-port-lldp-create

Description:  

* It retrieves port lldp remote-system operational data.
