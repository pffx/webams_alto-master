This sample enables use of VlanDot1qEtype in port.

Pre-condition:
* Only one tpid is allowed on a port.
