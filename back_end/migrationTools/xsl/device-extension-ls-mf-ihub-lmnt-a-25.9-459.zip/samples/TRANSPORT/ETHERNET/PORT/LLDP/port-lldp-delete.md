This sample deletes lldp configuration under port level
 
Pre-condition:  

* Following sample must execute first,
    1) transport-ethernet-port-lldp-create
	
  
Description:  

* It deletes lldp configuration under port level.
