This sample creates a port configuration.
 
Pre-condition:

* None  
 
Description:
  
* This sample provides a context to configure ports & its Ethernet attributes(ie. speed, auto-negotiate).
* Auto-negotiate should be false when port speed is 10000
