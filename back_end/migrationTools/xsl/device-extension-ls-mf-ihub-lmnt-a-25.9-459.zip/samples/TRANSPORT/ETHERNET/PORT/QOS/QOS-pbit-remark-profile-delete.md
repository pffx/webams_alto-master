This sample deletes the QoS egress P bits remarking profile configuration.
 
* It deletes the QoS egress P bits remarking profile configuration.

Pre-condition:


* Following sample must execute first,
    transport-ethernet-port-qos-pbit-remark-profile-create
