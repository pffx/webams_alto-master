This sample gets the QoS egress P bits remarking profile configuration.

* Gets the QoS egress P bits remarking profile configuration.
 
Pre-condition:

* Following sample must execute first,
    transport-ethernet-port-qos-pbit-remark-profile-create
