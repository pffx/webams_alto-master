This sample retrieves a LT port status.
 
Pre-condition:

* Following sample must execute first,
     transport-ethernet-port-user-port-create 

The following parameters have to be provided as input:
  
Description:
  
* It retrieves a LT port status.
