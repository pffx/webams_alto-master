This sample modify a port configuration.
 
Pre-condition:

* Following sample must executed first,
    1) transport-ethernet-port-network-port-create
* Port must created.

Description:
  
* This sample modifies the port configuration & its Ethernet attributes(ie. speed,
  mode, autonegotiate,category & dot1q-etype).
* For LMNT-A the maximum burst which can be set for port egress rate in restricted to 16380 KiloBytes
