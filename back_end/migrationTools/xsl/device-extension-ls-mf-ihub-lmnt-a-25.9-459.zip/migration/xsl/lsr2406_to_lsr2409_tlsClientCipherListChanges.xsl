<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
<xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>

    <xsl:template match="@*|node()">
        <xsl:copy>
            <xsl:apply-templates select="@*|node()"/>
        </xsl:copy>
    </xsl:template>

    <!-- Match the cipher element -->
    <xsl:template match="ihub:system/ihub:security/ihub:tls/ihub:client-cipher-list/ihub:cipher">
        <xsl:variable name="cipher-ns" select="namespace-uri()"/>
        <xsl:element name="tls12-cipher" namespace="{$cipher-ns}">
           <xsl:apply-templates select="ihub:index"/>
            <xsl:apply-templates select="ihub:name"/>
        </xsl:element>
    </xsl:template>

    <!-- Match the name element within cipher -->
    <xsl:template match="ihub:system/ihub:security/ihub:tls/ihub:client-cipher-list/ihub:cipher/ihub:name">
        <xsl:variable name="ns" select="namespace-uri()"/>
        <xsl:choose>
            <xsl:when test=". = 'tls-rsa-with3des-ede-cbc-sha'">
                <xsl:element name="name" namespace="{$ns}">tls-rsa-with-3des-ede-cbc-sha</xsl:element>
            </xsl:when>
	    <xsl:when test=". = 'tls-rsa-with-aes128-cbc-sha'">
                 <xsl:element name="name" namespace="{$ns}">tls-rsa-with-aes-128-cbc-sha</xsl:element>
            </xsl:when>
	    <xsl:when test=". = 'tls-rsa-with-aes256-cbc-sha'">
                 <xsl:element name="name" namespace="{$ns}">tls-rsa-with-aes-256-cbc-sha</xsl:element>
            </xsl:when>
	    <xsl:when test=". = 'tls-rsa-with-aes128-cbc-sha256'">
                 <xsl:element name="name" namespace="{$ns}">tls-rsa-with-aes-128-cbc-sha256</xsl:element>
            </xsl:when>
	    <xsl:when test=". = 'tls-rsa-with-aes256-cbc-sha256'">
                 <xsl:element name="name" namespace="{$ns}">tls-rsa-with-aes-256-cbc-sha256</xsl:element>
            </xsl:when>
        </xsl:choose>
    </xsl:template>
</xsl:stylesheet>
