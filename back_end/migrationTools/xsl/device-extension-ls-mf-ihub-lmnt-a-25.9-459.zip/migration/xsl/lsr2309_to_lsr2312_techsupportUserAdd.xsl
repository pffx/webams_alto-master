<xsl:stylesheet version="3.0"
xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
<xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>
<!-- The below segment copies the defaults.xml as such-->
<xsl:template match="*">
<xsl:copy>
<xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
</xsl:template>

<!-- The below segment search & inserts node element for user techsupport if not present -->

<xsl:variable name="ns"/>
<xsl:variable name="flag"/>

<xsl:template match="ihub:system/ihub:security/ihub:user-params/ihub:local-user/ihub:user[ihub:user-name='techsupport']">
  <xsl:variable name="ns" select="namespace-uri()"/>
  <xsl:variable name="flag" select="'true'"/>
</xsl:template>


<xsl:template match="ihub:system/ihub:security/ihub:user-params/ihub:local-user">
  <xsl:variable name="ns" select="namespace-uri()"/>
  <xsl:copy>
    <xsl:copy-of select="@*"/>
    <xsl:apply-templates/>
    <xsl:if test="'$flag' != 'true'">
      <xsl:element name="user"  namespace="{$ns}">
      <xsl:element name="user-name"  namespace="{$ns}">techsupport</xsl:element>
      <xsl:element name="password"   namespace="{$ns}">$2y$10$D/HSSNWo9e.v58p11.k4A.EHaP2f0L9cvRDuajC0b3/3srkGTXCtq</xsl:element>
      <xsl:element name="restricted-to-home"  namespace="{$ns}">false</xsl:element>
        <xsl:element name="access"  namespace="{$ns}">
          <xsl:element name="console"  namespace="{$ns}">true</xsl:element>
          <xsl:element name="ftp"  namespace="{$ns}">false</xsl:element>
          <xsl:element name="snmp"  namespace="{$ns}">false</xsl:element>
          <xsl:element name="netconf"  namespace="{$ns}">false</xsl:element>
          <xsl:element name="grpc"  namespace="{$ns}">false</xsl:element>
          </xsl:element>
        <xsl:element name="console"  namespace="{$ns}">
          <xsl:element name="cannot-change-password"  namespace="{$ns}">false</xsl:element>
          <xsl:element name="new-password-at-login"  namespace="{$ns}">false</xsl:element>
          <xsl:element name="member"  namespace="{$ns}">techsupport</xsl:element>
        </xsl:element>
        <xsl:element name="public-keys"  namespace="{$ns}">
          <xsl:element name="ecdsa"  namespace="{$ns}"/>
          <xsl:element name="rsa"  namespace="{$ns}">
            <xsl:element name="rsa-key"  namespace="{$ns}">
              <xsl:element name="rsa-public-key-id"  namespace="{$ns}">1</xsl:element>
              <xsl:element name="description"  namespace="{$ns}">An operator's RSA Key</xsl:element>
              <xsl:element name="key-value"  namespace="{$ns}">RSA_KEY_HERE</xsl:element>
            </xsl:element>
          </xsl:element>
        </xsl:element>
        <xsl:element name="snmp"  namespace="{$ns}"/>
      </xsl:element>
    </xsl:if>
  </xsl:copy>
</xsl:template>

<xsl:template match="ihub:system/ihub:security/ihub:user-params/ihub:local-user/ihub:user[ihub:user-name='techsupport']/ihub:password">
  <xsl:variable name="ns" select="namespace-uri()"/>
  <xsl:element name="password" namespace="{$ns}">$2y$10$D/HSSNWo9e.v58p11.k4A.EHaP2f0L9cvRDuajC0b3/3srkGTXCtq</xsl:element>
</xsl:template>

</xsl:stylesheet>
