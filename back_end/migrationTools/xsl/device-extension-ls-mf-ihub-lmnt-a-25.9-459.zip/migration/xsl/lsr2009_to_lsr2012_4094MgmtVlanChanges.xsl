<xsl:stylesheet version="3.0" 
     xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
     xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
      <xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>

<!-- The below segment copies the defaults.xml as such-->
    <xsl:template match="*">
        <xsl:copy>
            <xsl:copy-of select="@*"/>
            <xsl:apply-templates/>
        </xsl:copy>
    </xsl:template>

<!-- The below segment removes vprn with service-name '2147483647',vpls with service-name '4093' and ntp server-->
    <xsl:template match="ihub:service/ihub:vprn[ihub:service-name='2147483647']"/>         
    <xsl:template match="ihub:service/ihub:vpls[ihub:service-name='4093']"/>
    <xsl:template match="ihub:system/ihub:time/ihub:ntp/ihub:server"/>

</xsl:stylesheet>

