<xsl:stylesheet version="3.0"
     xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
     xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
      <xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>

<!-- The below segment copies the defaults.xml as such-->
    <xsl:template match="*">
        <xsl:copy>
            <xsl:copy-of select="@*"/>
            <xsl:apply-templates/>
        </xsl:copy>
    </xsl:template>

<!-- The below segment replaces "show qos" with "show qos-servicerouter" in the aaa local-profile "qos-config" -->
<xsl:template match="ihub:system/ihub:security/ihub:aaa/ihub:local-profiles/ihub:profile[ihub:user-profile-name='qos-config']/ihub:entry[ihub:entry-id=5]/ihub:match">
        <xsl:variable name="ns" select="namespace-uri()"/>
    <xsl:element name="match" namespace="{$ns}">show qos-servicerouter</xsl:element>
</xsl:template>
<!-- The below segment replaces "show qos" with "show qos-servicerouter" in the aaa local-profile "qos-read" -->
<xsl:template match="ihub:system/ihub:security/ihub:aaa/ihub:local-profiles/ihub:profile[ihub:user-profile-name='qos-read']/ihub:entry[ihub:entry-id=5]/ihub:match">
        <xsl:variable name="ns" select="namespace-uri()"/>
    <xsl:element name="match" namespace="{$ns}">show qos-servicerouter</xsl:element>
</xsl:template>
</xsl:stylesheet>
