<xsl:stylesheet version="3.0"
     xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
     xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
      <xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>
<!-- The below segment copies the defaults.xml as such-->
    <xsl:template match="*">
        <xsl:copy>
            <xsl:copy-of select="@*"/>
            <xsl:apply-templates/>
        </xsl:copy>
    </xsl:template>
<!-- The below segment check if the system interface bfd timers are less than 100msec; if they are, it resets them to 100msec-->
<xsl:template match="ihub:router/ihub:interface[ihub:interface-name='system']/ihub:ipv4/ihub:bfd/ihub:transmit-interval">
    <xsl:variable name="ns" select="namespace-uri()"/>
    <xsl:choose>
        <xsl:when test=". &lt; 100">
            <xsl:element name="transmit-interval" namespace="{$ns}">100</xsl:element>
        </xsl:when>
        <xsl:when test=". &gt;= 100">
            <xsl:copy-of select="."/>
        </xsl:when>
        <xsl:otherwise>
        </xsl:otherwise>
    </xsl:choose>
</xsl:template>
<xsl:template match="ihub:router/ihub:interface[ihub:interface-name='system']/ihub:ipv4/ihub:bfd/ihub:receive">
    <xsl:variable name="ns" select="namespace-uri()"/>
    <xsl:choose>
        <xsl:when test=". &lt; 100">
            <xsl:element name="receive" namespace="{$ns}">100</xsl:element>
        </xsl:when>
        <xsl:when test=". &gt;= 100">
            <xsl:copy-of select="."/>
        </xsl:when>
        <xsl:otherwise>
        </xsl:otherwise>
    </xsl:choose>
</xsl:template>

</xsl:stylesheet>
