<xsl:stylesheet version="3.0" 
     xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
     xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
      <xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>

<!-- The below segment copies the defaults.xml as such-->
    <xsl:template match="*">
        <xsl:copy>
            <xsl:copy-of select="@*"/>
            <xsl:apply-templates/>
        </xsl:copy>
    </xsl:template>

<!-- The below segment removes the leaf service-mtu from vpls service -->
    <xsl:template match="ihub:eth-cfm/ihub:domain/ihub:association/ihub:vid"/>
    <xsl:template match="ihub:eth-cfm/ihub:domain/ihub:association/ihub:vpn-id"/>
    <xsl:template match="ihub:eth-cfm/ihub:domain/ihub:association/ihub:bridge-identifier/ihub:id-permission"/>
    <xsl:template match="ihub:eth-cfm/ihub:domain/ihub:association/ihub:bridge-identifier/ihub:mhf-creation"/>
    <xsl:template match="ihub:eth-cfm/ihub:domain/ihub:association/ihub:bridge-identifier/ihub:mip-ltr-priority"/>
    <xsl:template match="ihub:lag/ihub:local-nt-ports-only"/>
    <xsl:template match="ihub:lag/ihub:port-type"/>
    <xsl:template match="ihub:lag/ihub:port-threshold/ihub:cost"/>
    <xsl:template match="ihub:sap/ihub:eth-cfm/ihub:mep/ihub:alarm-notification"/>
    <xsl:template match="ihub:service/ihub:mac-list"/>
    <xsl:template match="ihub:filter/ihub:mac-filter/ihub:entry/ihub:action/ihub:forward"/>
    <xsl:template match="ihub:filter/ihub:mac-filter/ihub:entry/ihub:action/ihub:http-redirect"/>


</xsl:stylesheet>

