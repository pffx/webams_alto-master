<xsl:stylesheet version="3.0"
xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
<xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>
<!-- The below segment copies the defaults.xml as such-->
<xsl:template match="*">
<xsl:copy>
<xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
</xsl:template>
<!-- The below segment inserts node element  for ntVpMcPort-1/5/2-->
  <xsl:template match="ihub:log">
  <xsl:variable name="ns" select="namespace-uri()"/>
  <xsl:copy-of select="."/>
      <xsl:element name="port" namespace="{$ns}">
        <xsl:element name="port-id" namespace="{$ns}">1/5/2</xsl:element>
        <xsl:element name="ddm-events"   namespace="{$ns}">true</xsl:element>
        <xsl:element name="description"  namespace="{$ns}">ISAM/FTTU Virtual Port</xsl:element>
        <xsl:element name="admin-state"  namespace="{$ns}">enable</xsl:element>
        <xsl:element name="transceiver"  namespace="{$ns}"/>
        <xsl:element name="ethernet"  namespace="{$ns}">
          <xsl:element name="dot1q-etype"  namespace="{$ns}">0x8100</xsl:element>
          <xsl:element name="mode"  namespace="{$ns}">access</xsl:element>
          <xsl:element name="encap-type"  namespace="{$ns}">dot1q</xsl:element>
          <xsl:element name="category"  namespace="{$ns}">regular</xsl:element>
          <xsl:element name="remark"  namespace="{$ns}">false</xsl:element>
          <xsl:element name="use-vlan-dot1q-etype"  namespace="{$ns}">false</xsl:element>
          <xsl:element name="backplane"  namespace="{$ns}"/>
        </xsl:element>
        <xsl:element name="connector"  namespace="{$ns}"/>
      </xsl:element>
  </xsl:template>
</xsl:stylesheet>
