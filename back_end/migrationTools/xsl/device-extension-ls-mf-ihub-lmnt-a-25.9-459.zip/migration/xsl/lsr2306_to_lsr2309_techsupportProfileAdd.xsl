<xsl:stylesheet version="3.0"
xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
<xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>
<!-- The below segment copies the defaults.xml as such-->
<xsl:template match="*">
<xsl:copy>
<xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
</xsl:template>
<!-- The below segment adds techsupport profile and updates techsupport profile for techsupport user -->

<xsl:variable name="ns"/>
<xsl:variable name="flag"/>

<xsl:template match="ihub:system/ihub:security/ihub:aaa/ihub:local-profiles/ihub:profile[ihub:user-profile-name='techsupport']">
  <xsl:variable name="ns" select="namespace-uri()"/>
  <xsl:variable name="flag" select="'true'"/>
</xsl:template>

<xsl:template match="ihub:system/ihub:security/ihub:aaa/ihub:local-profiles">
  <xsl:variable name="ns" select="namespace-uri()"/>
  <xsl:copy>
    <xsl:copy-of select="@*"/>
      <xsl:apply-templates/>
      <xsl:if test="'$flag' != 'true'">
        <xsl:element name="profile"  namespace="{$ns}">
        <xsl:element name="user-profile-name"  namespace="{$ns}">techsupport</xsl:element>
        <xsl:element name="default-action"   namespace="{$ns}">permit-all</xsl:element>
          <xsl:element name="netconf"  namespace="{$ns}">
            <xsl:element name="base-op-authorization"  namespace="{$ns}">
              <xsl:element name="kill-session"  namespace="{$ns}">false</xsl:element>
              <xsl:element name="lock"  namespace="{$ns}">false</xsl:element>
          </xsl:element>
        </xsl:element>
      </xsl:element>
    </xsl:if>
  </xsl:copy>
 </xsl:template>

<xsl:template match="ihub:system/ihub:security/ihub:user-params/ihub:local-user/ihub:user[ihub:user-name='techsupport']/ihub:console/ihub:member">
  <xsl:variable name="ns" select="namespace-uri()"/>
  <xsl:element name="member" namespace="{$ns}">techsupport</xsl:element>
</xsl:template>

</xsl:stylesheet>
