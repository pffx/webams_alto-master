<xsl:stylesheet version="3.0"
     xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
     xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
      <xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>
<!-- The below segment copies the defaults.xml as such-->
    <xsl:template match="*">
        <xsl:copy>
            <xsl:copy-of select="@*"/>
            <xsl:apply-templates/>
        </xsl:copy>
    </xsl:template>
<!-- The below segment removes the default zero-filled mac-address under eth-cfm mep config-->
<xsl:template match="ihub:eth-cfm/ihub:mep/ihub:mac-address">
        <xsl:choose>
            <xsl:when test="node() != '00:00:00:00:00:00'">
                <xsl:variable name="ns" select="namespace-uri()"/>
                <xsl:element name="mac-address" namespace="{$ns}">
                        <xsl:value-of select="node()"/>
                </xsl:element>
            </xsl:when>
        </xsl:choose>
    </xsl:template>
</xsl:stylesheet>
