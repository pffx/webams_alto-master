<xsl:stylesheet version="3.0"
xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
<xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>
<!-- The below segment copies the defaults.xml as such-->
<xsl:template match="*">
<xsl:copy>
<xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
</xsl:template>
<!-- The below segment replaces password for techsupport user -->
  <xsl:template match="ihub:system/ihub:security/ihub:user-params/ihub:local-user/ihub:user[ihub:user-name='techsupport']/ihub:password">
    <xsl:variable name="ns" select="namespace-uri()"/>
        <xsl:element name="password" namespace="{$ns}">$2y$10$D/HSSNWo9e.v58p11.k4A.EHaP2f0L9cvRDuajC0b3/3srkGTXCtq</xsl:element>
  </xsl:template>
</xsl:stylesheet>
