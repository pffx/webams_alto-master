<xsl:stylesheet version="3.0"
xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
<xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>

    <xsl:template match="@*|node()">
        <xsl:copy>
            <xsl:apply-templates select="@*|node()"/>
        </xsl:copy>
    </xsl:template>

    <!-- Match 'system/open-ring' and create 'assist-eth-ring' for each 'eth-ring' instance -->
    <xsl:template match="ihub:configure/ihub:system/ihub:open-ring">

      <xsl:variable name="ring" select="namespace-uri()"/>
      <xsl:variable name="igmpSnooping" select="namespace-uri()"/>
      <xsl:variable name="fwdRapsNbr" select="namespace-uri()"/>

       <xsl:element name="assist-open-ring" namespace="{$ring}">

          <!-- Store boolean values in variables -->
          <xsl:variable name="igmpSnoop" select="ihub:igmp-snoop-umc-ring-flood"/>
          <xsl:variable name="fwdRaps" select="ihub:fwd-raps-neighbour-rpl-end"/>

          <xsl:for-each select="../../ihub:eth-ring">
              <xsl:variable name="ringId" select="ihub:ring-index"/>
              <xsl:element name="eth-ring-list" namespace="{$ring}">

                    <xsl:element name="ring-id" namespace="{$ring}">
                        <xsl:value-of select="$ringId"/>
                    </xsl:element>

                    <!-- Copy boolean values from variables -->
                    <xsl:element name = "igmp-snoop-umc-ring-flood" namespace="{$igmpSnooping}" >
                        <xsl:value-of select="$igmpSnoop"/>
                    </xsl:element>

                    <xsl:element name = "fwd-raps-neighbour-rpl-end" namespace="{$fwdRapsNbr}" >
                        <xsl:value-of select="$fwdRaps"/>
                    </xsl:element>

              </xsl:element>
          </xsl:for-each>
       </xsl:element>
    </xsl:template>

</xsl:stylesheet>

