<xsl:stylesheet version="3.0"
   xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
   xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
      <xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>

<!-- The below segment copies the defaults.xml as such-->
    <xsl:template match="*">
        <xsl:copy>
            <xsl:copy-of select="@*"/>
            <xsl:apply-templates/>
        </xsl:copy>
    </xsl:template>

<!-- The below segment removes non unicast dest-ip -->
<!--
a)non unicast ranges:
    1)0.x.x.x
    2)127.x.x.x
    3)224.x.x.x to 239.x.x.x
    4)240.x.x.x
-->
    <xsl:template match="ihub:ipfix/ihub:exporting-process/ihub:destination/ihub:tcp-exporter/ihub:destination-ip-address">
        <xsl:variable name="ns" select="namespace-uri()"/>
        <xsl:variable name="ip" select="substring-before(string(node()), '.')"/>
        <xsl:variable name="ipNum" select="number($ip)" />

        <xsl:if test="not($ipNum=0) and not($ipNum=127) and not($ipNum &gt;= 224 and $ipNum &lt;= 240)">
            <xsl:element name="destination-ip-address" namespace="{$ns}">
                <xsl:value-of select="node()"/>
            </xsl:element>
       </xsl:if>
    </xsl:template>

</xsl:stylesheet>
