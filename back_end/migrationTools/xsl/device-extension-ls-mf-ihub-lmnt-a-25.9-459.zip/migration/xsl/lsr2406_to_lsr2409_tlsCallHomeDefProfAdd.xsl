<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
<xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>

    <xsl:template match="@*|node()">
        <xsl:copy>
            <xsl:apply-templates select="@*|node()"/>
        </xsl:copy>
    </xsl:template>

    <!-- The below segment add the Default CallHome CA profiles if not present -->
    <xsl:template match="ihub:system/ihub:security/ihub:pki">
        <xsl:variable name="ns" select="namespace-uri()"/>
        <xsl:copy>
            <xsl:copy-of select="@*"/>
            <xsl:apply-templates/>
            <xsl:if test="not(ihub:ca-profile[ihub:ca-profile-name='CALLHOME_INTERMEDIATE_CA1'])">
                <xsl:element name="ca-profile" namespace="{$ns}">
                    <xsl:element name="ca-profile-name" namespace="{$ns}">CALLHOME_INTERMEDIATE_CA1</xsl:element>
                    <xsl:element name="admin-state" namespace="{$ns}">enable</xsl:element>
                    <xsl:element name="description" namespace="{$ns}">CALLHOME_INTERMEDIATE_CA1 Profile</xsl:element>
                    <xsl:element name="cert-file" namespace="{$ns}">clientInterimCA1.pem</xsl:element>
                </xsl:element>
            </xsl:if>
            <xsl:if test="not(ihub:ca-profile[ihub:ca-profile-name='CALLHOME_INTERMEDIATE_CA2'])">
                <xsl:element name="ca-profile" namespace="{$ns}">
                    <xsl:element name="ca-profile-name" namespace="{$ns}">CALLHOME_INTERMEDIATE_CA2</xsl:element>
                    <xsl:element name="admin-state" namespace="{$ns}">enable</xsl:element>
                    <xsl:element name="description" namespace="{$ns}">CALLHOME_INTERMEDIATE_CA2 Profile</xsl:element>
                    <xsl:element name="cert-file" namespace="{$ns}">clientInterimCA2.pem</xsl:element>
                </xsl:element>
            </xsl:if>
            <xsl:if test="not(ihub:ca-profile[ihub:ca-profile-name='CALLHOME_INTERMEDIATE_CA3'])">
    	        <xsl:element name="ca-profile" namespace="{$ns}">
                    <xsl:element name="ca-profile-name" namespace="{$ns}">CALLHOME_INTERMEDIATE_CA3</xsl:element>
                    <xsl:element name="admin-state" namespace="{$ns}">enable</xsl:element>
                    <xsl:element name="description" namespace="{$ns}">CALLHOME_INTERMEDIATE_CA3 Profile</xsl:element>
                    <xsl:element name="cert-file" namespace="{$ns}">clientInterimCA3.pem</xsl:element>
                </xsl:element>
            </xsl:if>
            <xsl:if test="not(ihub:ca-profile[ihub:ca-profile-name='CALLHOME_INTERMEDIATE_CA4'])">
    	        <xsl:element name="ca-profile" namespace="{$ns}">
                    <xsl:element name="ca-profile-name" namespace="{$ns}">CALLHOME_INTERMEDIATE_CA4</xsl:element>
                    <xsl:element name="admin-state" namespace="{$ns}">enable</xsl:element>
                    <xsl:element name="description" namespace="{$ns}">CALLHOME_INTERMEDIATE_CA4 Profile</xsl:element>
                    <xsl:element name="cert-file" namespace="{$ns}">clientInterimCA4.pem</xsl:element>
                </xsl:element>
            </xsl:if>
            <xsl:if test="not(ihub:ca-profile[ihub:ca-profile-name='CALLHOME_ROOT_CA'])">
                <xsl:element name="ca-profile" namespace="{$ns}">
                    <xsl:element name="ca-profile-name" namespace="{$ns}">CALLHOME_ROOT_CA</xsl:element>
                    <xsl:element name="admin-state" namespace="{$ns}">enable</xsl:element>
                    <xsl:element name="description" namespace="{$ns}">CALLHOME_ROOT_CA Profile</xsl:element>
                    <xsl:element name="cert-file" namespace="{$ns}">clientrootCA.pem</xsl:element>
                </xsl:element>
            </xsl:if>
        </xsl:copy>
    </xsl:template>

    <!-- The below segment add the Default CallHome Cert profile, TLS profile, TA profile and Cipher list if not present -->
    <xsl:template match="ihub:system/ihub:security/ihub:tls">
        <xsl:variable name="ns" select="namespace-uri()"/>
        <xsl:copy>
            <xsl:copy-of select="@*"/>
            <xsl:apply-templates/>
            <xsl:if test="not(ihub:cert-profile[ihub:cert-profile-name='CALLHOME_LOCAL_CERT_PROFILE'])"> 
                <xsl:element name="cert-profile" namespace="{$ns}">
                    <xsl:element name="cert-profile-name" namespace="{$ns}">CALLHOME_LOCAL_CERT_PROFILE</xsl:element>
                    <xsl:element name="admin-state" namespace="{$ns}">enable</xsl:element>
                    <xsl:element name="entry" namespace="{$ns}">
                        <xsl:element name="entry-id" namespace="{$ns}">1</xsl:element>
                        <xsl:element name="key-file" namespace="{$ns}">server_local.key</xsl:element>
                        <xsl:element name="certificate-file" namespace="{$ns}">server_local.crt</xsl:element>
                    </xsl:element>
                </xsl:element>
            </xsl:if>
            <xsl:if test="not(ihub:cert-profile[ihub:cert-profile-name='CALLHOME_PEER_CERT_PROFILE'])"> 
                <xsl:element name="cert-profile" namespace="{$ns}">
                    <xsl:element name="cert-profile-name" namespace="{$ns}">CALLHOME_PEER_CERT_PROFILE</xsl:element>
                    <xsl:element name="admin-state" namespace="{$ns}">enable</xsl:element>
                    <xsl:element name="entry" namespace="{$ns}">
                        <xsl:element name="entry-id" namespace="{$ns}">1</xsl:element>
                        <xsl:element name="key-file" namespace="{$ns}">server_peer.key</xsl:element>
                        <xsl:element name="certificate-file" namespace="{$ns}">server_peer.crt</xsl:element>
                    </xsl:element>
                </xsl:element>
            </xsl:if>
            <xsl:if test="not(ihub:server-cipher-list[ihub:server-cipher-list-name='CALLHOME_CIPHER_LIST'])"> 
               <xsl:element name="server-cipher-list" namespace="{$ns}">
                   <xsl:element name="server-cipher-list-name" namespace="{$ns}">CALLHOME_CIPHER_LIST</xsl:element>
               </xsl:element>
            </xsl:if>
            <xsl:if test="not(ihub:server-tls-profile[ihub:server-profile-name='CALLHOME_LOCAL_TLS_PROFILE'])"> 
               <xsl:element name="server-tls-profile" namespace="{$ns}">
                   <xsl:element name="server-profile-name" namespace="{$ns}">CALLHOME_LOCAL_TLS_PROFILE</xsl:element>
                   <xsl:element name="cipher-list" namespace="{$ns}">CALLHOME_CIPHER_LIST</xsl:element>
                   <xsl:element name="admin-state" namespace="{$ns}">enable</xsl:element>
                   <xsl:element name="cert-profile" namespace="{$ns}">CALLHOME_LOCAL_CERT_PROFILE</xsl:element>
                   <xsl:element name="protocol-version" namespace="{$ns}">tls-version-all</xsl:element>
                   <xsl:element name="authenticate-client" namespace="{$ns}">
                       <xsl:element name="trust-anchor-profile" namespace="{$ns}">CALLHOME_TA_PROFILE</xsl:element>
                   </xsl:element>
               </xsl:element>
            </xsl:if>
            <xsl:if test="not(ihub:server-tls-profile[ihub:server-profile-name='CALLHOME_PEER_TLS_PROFILE'])"> 
                <xsl:element name="server-tls-profile" namespace="{$ns}">
                    <xsl:element name="server-profile-name" namespace="{$ns}">CALLHOME_PEER_TLS_PROFILE</xsl:element>
                    <xsl:element name="cipher-list" namespace="{$ns}">CALLHOME_CIPHER_LIST</xsl:element>
                    <xsl:element name="admin-state" namespace="{$ns}">enable</xsl:element>
                    <xsl:element name="cert-profile" namespace="{$ns}">CALLHOME_PEER_CERT_PROFILE</xsl:element>
                    <xsl:element name="protocol-version" namespace="{$ns}">tls-version-all</xsl:element>
                    <xsl:element name="authenticate-client" namespace="{$ns}">
                        <xsl:element name="trust-anchor-profile" namespace="{$ns}">CALLHOME_TA_PROFILE</xsl:element>
                    </xsl:element>
                </xsl:element>
	    </xsl:if>
            <xsl:if test="not(ihub:trust-anchor-profile[ihub:trust-anchor-profile-name='CALLHOME_TA_PROFILE'])"> 
                <xsl:element name="trust-anchor-profile" namespace="{$ns}">
                    <xsl:element name="trust-anchor-profile-name" namespace="{$ns}">CALLHOME_TA_PROFILE</xsl:element>
                    <xsl:element name="trust-anchor" namespace="{$ns}">
                        <xsl:element name="ca-profile-name" namespace="{$ns}">CALLHOME_INTERMEDIATE_CA1</xsl:element>
                    </xsl:element>
                    <xsl:element name="trust-anchor" namespace="{$ns}">
                        <xsl:element name="ca-profile-name" namespace="{$ns}">CALLHOME_INTERMEDIATE_CA2</xsl:element>
                    </xsl:element>
                    <xsl:element name="trust-anchor" namespace="{$ns}">
                        <xsl:element name="ca-profile-name" namespace="{$ns}">CALLHOME_INTERMEDIATE_CA3</xsl:element>
                    </xsl:element>
                    <xsl:element name="trust-anchor" namespace="{$ns}">
                        <xsl:element name="ca-profile-name" namespace="{$ns}">CALLHOME_INTERMEDIATE_CA4</xsl:element>
                    </xsl:element>
                    <xsl:element name="trust-anchor" namespace="{$ns}">
                        <xsl:element name="ca-profile-name" namespace="{$ns}">CALLHOME_ROOT_CA</xsl:element>
                    </xsl:element>
                </xsl:element>
	    </xsl:if>
        </xsl:copy>
    </xsl:template>
</xsl:stylesheet>
