<xsl:stylesheet version="3.0"
     xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
     xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
      <xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>
<!-- The below segment copies the defaults as such-->
    <xsl:template match="*">
        <xsl:copy>
            <xsl:copy-of select="@*"/>
            <xsl:apply-templates/>
        </xsl:copy>
    </xsl:template>
	
        <!--To replace the vpls egress with qos policy-->
	<xsl:template match="ihub:service/ihub:vpls/ihub:egress">
	<xsl:variable name="qos" select="namespace-uri()"/>
        <xsl:choose>
          <xsl:when test="ihub:rate-limit|current()/ihub:rate-limit-pbits">
	    <xsl:element name="egress" namespace="{$qos}">
	    <xsl:element name="policer" namespace="{$qos}">
	      <xsl:value-of select="concat('egr_pol_', ../ihub:vlan)"/>
	    </xsl:element>
	    </xsl:element>
          </xsl:when>
          <xsl:otherwise>
	    <xsl:element name="egress" namespace="{$qos}">
              <xsl:copy-of select="node()"/>
	    </xsl:element>
          </xsl:otherwise>
        </xsl:choose>
        </xsl:template>

        <!--To replace the vpipe-group egress with qos policy-->
	<xsl:template match="ihub:service/ihub:vpipe-group/ihub:egress">
	<xsl:variable name="qos" select="namespace-uri()"/>
        <xsl:choose>
          <xsl:when test="ihub:rate-limit|current()/ihub:rate-limit-pbits">
	    <xsl:element name="egress" namespace="{$qos}">
	    <xsl:element name="policer" namespace="{$qos}">
	      <xsl:value-of select="concat('egr_pol_', ../ihub:outer-vlan)"/>
	    </xsl:element>
	    </xsl:element>
          </xsl:when>
          <xsl:otherwise>
	    <xsl:element name="egress" namespace="{$qos}">
              <xsl:copy-of select="node()"/>
	    </xsl:element>
          </xsl:otherwise>
        </xsl:choose>
        </xsl:template>

        <!--To replace the vpls ingress with qos policy-->
	<xsl:template match="ihub:service/ihub:vpls/ihub:ingress/ihub:rate-limit">
	<xsl:variable name="qos" select="namespace-uri()"/>
	<xsl:element name="policer" namespace="{$qos}">
	    <xsl:value-of select="concat('ing_pol_', ../../ihub:vlan)"/>
	</xsl:element>
        </xsl:template>

        <!--To replace the vpipe-group ingress with qos policy-->
	<xsl:template match="ihub:service/ihub:vpipe-group/ihub:ingress/ihub:rate-limit">
	<xsl:variable name="qos" select="namespace-uri()"/>
	<xsl:element name="policer" namespace="{$qos}">
	    <xsl:value-of select="concat('ing_pol_', ../../ihub:outer-vlan)"/>
	</xsl:element>
        </xsl:template>

     <!--Specific call template for modifying some of the existing qos elements-->
        <xsl:template match="node()|@*" name="identity">
         <xsl:variable name="qos" select="namespace-uri()"/>
         <xsl:copy>
            <xsl:apply-templates select="node()|@*"/>
         </xsl:copy>
        </xsl:template>


     <!--To copy the exsisting vpls qos configs to qos-servicerouter by creating a new qos policy-->
     <xsl:param name="removeElementsNamed" select="'admin-state'"/>
     <xsl:param name="addElementsNamed" select="'rate-limit-pbits-value'"/>
	 <xsl:template match="ihub:qos-servicerouter" >
     <!--xsl:template match="*[name()='configure']"-->
        <xsl:variable name="qos" select="namespace-uri()"/>
        <xsl:copy>
        <xsl:apply-templates select="@* | node()"/>
            <xsl:if test="../ihub:service/ihub:vpls/ihub:egress/ihub:rate-limit|../ihub:service/ihub:vpls/ihub:egress/ihub:rate-limit-pbits|../ihub:service/ihub:vpls/ihub:ingress/ihub:rate-limit|../ihub:service/ihub:vpipe-group/ihub:egress/ihub:rate-limit|../ihub:service/ihub:vpipe-group/ihub:egress/ihub:rate-limit-pbits|../ihub:service/ihub:vpipe-group/ihub:ingress/ihub:rate-limit">
                <!--xsl:element name="qos-servicerouter" namespace="{$qos}"-->
                   <!--Start of qos-servicerouter for vpls-->
                   <xsl:for-each select="../ihub:service/ihub:vpls">
                     <xsl:if test="ihub:egress and (ihub:egress/ihub:rate-limit|ihub:egress/ihub:rate-limit-pbits)">
                       <xsl:element name="policer" namespace="{$qos}">
                         <xsl:element name="policer-name" namespace="{$qos}">
                           <xsl:value-of select="concat('egr_pol_',ihub:vlan)"/>
                         </xsl:element>
                         <xsl:element name="identifier" namespace="{$qos}">
                           <xsl:value-of select="number(ihub:vlan)"/>
                         </xsl:element>
                         <xsl:if test="ihub:egress/ihub:rate-limit">
                           <xsl:element name="default-policer" namespace="{$qos}">
                             <xsl:copy-of select="ihub:egress/ihub:rate-limit/node()"/>
                           </xsl:element>
                         </xsl:if>
                         <xsl:if test="ihub:egress/ihub:rate-limit-pbits">
                           <xsl:for-each select="ihub:egress/ihub:rate-limit-pbits">
                             <xsl:element name="pbit-policer" namespace="{$qos}">
                               <xsl:for-each select="*">
        			 <xsl:choose>
          			   <xsl:when test="(name() = $removeElementsNamed)">
          			   </xsl:when>
          			   <xsl:when test="(name() = $addElementsNamed)">
                                     <xsl:element name="pbit-policer-id" namespace="{$qos}">
                                     <xsl:value-of select="../ihub:rate-limit-pbits-value"/>
                                     </xsl:element>
          			   </xsl:when>
          			   <xsl:otherwise>
                                     <xsl:call-template name="identity"/>
          			   </xsl:otherwise>
        			 </xsl:choose>
                               </xsl:for-each>
                             </xsl:element>
                           </xsl:for-each>
                         </xsl:if>
                       </xsl:element>
                     </xsl:if>
                     <xsl:if test="ihub:ingress and ihub:ingress/ihub:rate-limit">
                            <xsl:element name="policer" namespace="{$qos}">
                          <xsl:element name="policer-name" namespace="{$qos}">
                                     <xsl:value-of select="concat('ing_pol_', ihub:vlan)"/>
                                   </xsl:element>
                                   <xsl:element name="identifier" namespace="{$qos}">
                                     <xsl:value-of select="number(ihub:vlan) + 4096"/>
                                   </xsl:element>
                                   <xsl:if test="ihub:ingress/ihub:rate-limit">
                                     <xsl:element name="default-policer" namespace="{$qos}">
                                 <xsl:copy-of select="ihub:ingress/ihub:rate-limit/node()"/>
                                 </xsl:element>
                                   </xsl:if>
                                </xsl:element>
                     </xsl:if>
		   </xsl:for-each>	
                   <!--End of qos-servicerouter for vpls-->
                   <!--Start of qos-servicerouter for vpipe-group-->
                   <xsl:for-each select="../ihub:service/ihub:vpipe-group">
                     <xsl:if test="ihub:egress and (ihub:egress/ihub:rate-limit|ihub:egress/ihub:rate-limit-pbits)">
                       <xsl:element name="policer" namespace="{$qos}">
                         <xsl:element name="policer-name" namespace="{$qos}">
                           <xsl:value-of select="concat('egr_pol_',ihub:outer-vlan)"/>
                         </xsl:element>
                         <xsl:element name="identifier" namespace="{$qos}">
                           <xsl:value-of select="number(ihub:outer-vlan)"/>
                         </xsl:element>
                         <xsl:if test="ihub:egress/ihub:rate-limit">
                           <xsl:element name="default-policer" namespace="{$qos}">
                             <xsl:copy-of select="ihub:egress/ihub:rate-limit/node()"/>
                           </xsl:element>
                         </xsl:if>
                         <xsl:if test="ihub:egress/ihub:rate-limit-pbits">
                           <xsl:for-each select="ihub:egress/ihub:rate-limit-pbits">
                             <xsl:element name="pbit-policer" namespace="{$qos}">
                               <xsl:for-each select="*">
        			 <xsl:choose>
          			   <xsl:when test="(name() = $removeElementsNamed)">
          			   </xsl:when>
          			   <xsl:when test="(name() = $addElementsNamed)">
                                     <xsl:element name="pbit-policer-id" namespace="{$qos}">
                                     <xsl:value-of select="../ihub:rate-limit-pbits-value"/>
                                     </xsl:element>
          			   </xsl:when>
          			   <xsl:otherwise>
                                     <xsl:call-template name="identity"/>
          			   </xsl:otherwise>
        			 </xsl:choose>
                               </xsl:for-each>
                             </xsl:element>
                           </xsl:for-each>
                         </xsl:if>
                       </xsl:element>
                     </xsl:if>
                     <xsl:if test="ihub:ingress and ihub:ingress/ihub:rate-limit">
                            <xsl:element name="policer" namespace="{$qos}">
                          <xsl:element name="policer-name" namespace="{$qos}">
                                     <xsl:value-of select="concat('ing_pol_', ihub:outer-vlan)"/>
                                   </xsl:element>
                                   <xsl:element name="identifier" namespace="{$qos}">
                                     <xsl:value-of select="number(ihub:outer-vlan) + 4096"/>
                                   </xsl:element>
                                   <xsl:if test="ihub:ingress/ihub:rate-limit">
                                     <xsl:element name="default-policer" namespace="{$qos}">
                                 <xsl:copy-of select="ihub:ingress/ihub:rate-limit/node()"/>
                                 </xsl:element>
                                   </xsl:if>
                                </xsl:element>
                     </xsl:if>
		   </xsl:for-each>	
                   <!--End of qos-servicerouter for vpipe-group-->
                <!--/xsl:element-->
		</xsl:if>		   
    </xsl:copy>
    </xsl:template>


</xsl:stylesheet>
