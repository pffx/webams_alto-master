<xsl:stylesheet version="3.0"
xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:ihub="urn:nokia.com:sros:ns:yang:sr:conf">
<xsl:strip-space elements="*"/>
<xsl:output indent="yes" method="xml" encoding="utf-8" use-character-maps="mapCharacter" omit-xml-declaration="yes"/>
<xsl:character-map name="mapCharacter">
<xsl:output-character character="&apos;" string="&amp;apos;"/>
</xsl:character-map>
<!-- The below segment copies the defaults.xml as such-->
<xsl:template match="*">
<xsl:copy>
<xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
</xsl:template>
<!-- The below segment adds node-ip configs if not present -->

<xsl:template match="ihub:configure/ihub:system">
  <xsl:variable name="ns" select="namespace-uri()"/>
  <xsl:copy>
    <xsl:apply-templates/>
    <xsl:choose>
      <xsl:when test="not (ihub:node-ip)">
        <xsl:element name="node-ip"  namespace="{$ns}">
         <xsl:if test="ihub:dhcpv4-client/ihub:intf-name != ''">
          <xsl:element name="ipv4"  namespace="{$ns}">
            <xsl:element name="interface-name"   namespace="{$ns}">
              <xsl:value-of select="ihub:dhcpv4-client/ihub:intf-name"/>
            </xsl:element>
          </xsl:element>
         </xsl:if>

         <xsl:if test="ihub:dhcpv6-client/ihub:intf-name != ''">
          <xsl:element name="ipv6"  namespace="{$ns}">
            <xsl:element name="interface-name"   namespace="{$ns}">
              <xsl:value-of select="ihub:dhcpv6-client/ihub:intf-name"/>
            </xsl:element>
          </xsl:element>
         </xsl:if>
        </xsl:element>
      </xsl:when>
      <xsl:otherwise>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:copy>
</xsl:template>

</xsl:stylesheet>
