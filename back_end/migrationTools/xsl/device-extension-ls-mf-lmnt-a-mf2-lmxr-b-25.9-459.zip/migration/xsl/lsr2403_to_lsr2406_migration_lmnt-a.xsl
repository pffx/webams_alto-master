<?xml version='1.0' encoding='utf-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">

    
    <xsl:template match="@* | node()">
        <xsl:copy>
            <xsl:apply-templates select="@* | node()" />
        </xsl:copy>
    </xsl:template>

    <xsl:include href="lsr2403_to_lsr2406_ipfix-caches_lmnt-a.xsl" />
    <xsl:include href="lsr2403_to_lsr2406_ipfix_lmnt-a.xsl" />
    <xsl:include href="lsr2403_to_lsr2406_nacm_1.xsl" />
    <xsl:include href="lsr2403_to_lsr2406_remove_unsecure_algorithms_1.xsl" />
    <xsl:include href="lsr2403_to_lsr2406_fan_remove_eco_auto_1.xsl" />

</xsl:stylesheet>