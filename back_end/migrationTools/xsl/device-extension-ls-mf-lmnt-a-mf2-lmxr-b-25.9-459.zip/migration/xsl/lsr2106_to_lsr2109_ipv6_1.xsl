<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
    <xsl:strip-space elements="*"/>
    <xsl:output method="xml" indent="yes"/>

<!-- default rule -->
    <xsl:template match="*">
        <xsl:copy>
        <xsl:copy-of select="@*"/>
        <xsl:apply-templates/>
        </xsl:copy>
    </xsl:template>

    <xsl:template match="@* | node()">
        <xsl:copy>
            <xsl:apply-templates select="@* | node()"/>
        </xsl:copy>
    </xsl:template>

    <xsl:template match="*[name() = 'config'         and (namespace-uri() = 'urn:ietf:params:xml:ns:netconf:base:1.0' or namespace-uri() = 'http://tail-f.com/ns/config/1.0')     ]">
        <xsl:copy>
            <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
<interfaces xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces">
                <!-- inband INTERFACE -->
                <interface>
                    <name>inband</name>
                    <type xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type">ianaift:ipForward</type>
                    <ipif-lower-layer xmlns="urn:ietf:params:xml:ns:yang:nokia-ip-aug">
                        <sub-interface>inband-l2term</sub-interface>
                    </ipif-lower-layer>
                    <tag-ip-intf xmlns="urn:ietf:params:xml:ns:yang:nokia-ip-aug">
                        <tag-ip-intf>inband-mgnt</tag-ip-intf>
                    </tag-ip-intf>
                    <ipv6 xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">
                        <enabled>true</enabled>
                    </ipv6>
                </interface>
                <!-- inband L2 Termination INTERFACE -->
                <interface>
                    <name>inband-l2term</name>
                    <type xmlns:nokia-l2-ti="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-mgntvlan-termination-itf">nokia-l2-ti:l2-termination-interface</type>
                    <l2-termination-interface xmlns="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-mgntvlan-termination-itf">
                        <interface-usage>user-port</interface-usage>
                        <termination-port-transmit>
                            <push-tag>
                                <index>0</index>
                                <dot1q-tag>
                                    <tag-type xmlns:bbf-dot1qt="urn:bbf:yang:bbf-dot1q-types">bbf-dot1qt:c-vlan</tag-type>
                                    <vlan-id>4092</vlan-id>
                                    <pbit-from-tag-index>0</pbit-from-tag-index>
                                    <dei-from-tag-index>0</dei-from-tag-index>
                                </dot1q-tag>
                            </push-tag>
                        </termination-port-transmit>
                        <termination-port-receive>
                            <pop-tags>0</pop-tags>
                        </termination-port-receive>
                    </l2-termination-interface>
                </interface>
            </interfaces>

        </xsl:copy>
    </xsl:template>

</xsl:stylesheet>
