<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
        <xsl:strip-space elements="*"/>
        <xsl:output method="xml" indent="yes"/>

<!-- default rule -->
    <xsl:template match="*">
        <xsl:copy>
        <xsl:copy-of select="@*"/>
        <xsl:apply-templates/>
        </xsl:copy>
    </xsl:template>

        <!-- remove serial from LMNT-A -->
        <xsl:template match="*[name() = 'serial']">
        <xsl:choose>
         <xsl:when test="namespace-uri() = 'http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-ietf-system-aug' and parent::*[name() = 'management' or name() = 'cli']"/>
         <xsl:otherwise>
         <xsl:copy>
           <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
       </xsl:otherwise>
      </xsl:choose>
     </xsl:template>

</xsl:stylesheet>
