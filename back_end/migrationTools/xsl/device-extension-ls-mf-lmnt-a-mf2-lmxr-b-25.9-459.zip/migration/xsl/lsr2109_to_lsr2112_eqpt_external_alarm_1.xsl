<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
  <xsl:strip-space elements="*"/>
  <xsl:output method="xml" encoding="UTF-8" indent="yes"/>

<!-- default rule -->
  <xsl:template match="*">
    <xsl:copy>
      <xsl:copy-of select="@*"/>
      <xsl:apply-templates/>
    </xsl:copy>
  </xsl:template>

  <!--delete External-Alarm-Port and add it later -->
  <xsl:template match="*[name()='component']">
      <xsl:choose>
          <xsl:when test="parent::*[name() = 'hardware'] and (./child::*[name()='name' and (text()='External-Alarm-Port')])">
          </xsl:when>
          <xsl:otherwise>
              <xsl:copy>
                  <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
          </xsl:otherwise>
      </xsl:choose>
  </xsl:template>

  <!--parent=External-Alarm-Port to External-Alarm-Port-Nta -->
  <xsl:template match="*[name() = 'parent' and (namespace-uri() = 'urn:ietf:params:xml:ns:yang:ietf-hardware')]">
      <xsl:choose>
        <xsl:when test="node() = 'External-Alarm-Port'">
          <xsl:element name="parent" namespace="urn:ietf:params:xml:ns:yang:ietf-hardware"><xsl:text>External-Alarm-Port-Nta</xsl:text></xsl:element>
        </xsl:when>
        <xsl:otherwise>
            <xsl:copy>
               <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
        </xsl:otherwise>
      </xsl:choose>
  </xsl:template>

  <!--Alarm-Output-Port-1 to Alarm-Output-Nta
      Alarm-Input-Port-1 to Alarm-Input-Nta-1
      Alarm-Input-Port-2 to Alarm-Input-Nta-2
      Alarm-Input-Port-3 to Alarm-Input-Nta-3
      Alarm-Input-Port-4 to Alarm-Input-Nta-4
      Alarm-Input-Port-5 to Alarm-Input-Nta-5 -->
  <xsl:template match="*[name() = 'name' and (namespace-uri() = 'urn:ietf:params:xml:ns:yang:ietf-hardware')]">
      <xsl:choose>
        <xsl:when test="node() = 'Alarm-Input-Port-1'">
          <xsl:element name="name" namespace="urn:ietf:params:xml:ns:yang:ietf-hardware"><xsl:text>Alarm-Input-Nta-1</xsl:text></xsl:element>
        </xsl:when>
        <xsl:when test="node() = 'Alarm-Input-Port-2'">
          <xsl:element name="name" namespace="urn:ietf:params:xml:ns:yang:ietf-hardware"><xsl:text>Alarm-Input-Nta-2</xsl:text></xsl:element>
        </xsl:when>
      	<xsl:when test="node() = 'Alarm-Input-Port-3'">
          <xsl:element name="name" namespace="urn:ietf:params:xml:ns:yang:ietf-hardware"><xsl:text>Alarm-Input-Nta-3</xsl:text></xsl:element>
        </xsl:when>
        <xsl:when test="node() = 'Alarm-Input-Port-4'">
          <xsl:element name="name" namespace="urn:ietf:params:xml:ns:yang:ietf-hardware"><xsl:text>Alarm-Input-Nta-4</xsl:text></xsl:element>
        </xsl:when>
        <xsl:when test="node() = 'Alarm-Input-Port-5'">
          <xsl:element name="name" namespace="urn:ietf:params:xml:ns:yang:ietf-hardware"><xsl:text>Alarm-Input-Nta-5</xsl:text></xsl:element>
        </xsl:when>
        <xsl:when test="node() = 'Alarm-Output-Port-1'">
          <xsl:element name="name" namespace="urn:ietf:params:xml:ns:yang:ietf-hardware"><xsl:text>Alarm-Output-Nta</xsl:text></xsl:element>
        </xsl:when>
        <xsl:otherwise>
            <xsl:copy>
               <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
        </xsl:otherwise>
      </xsl:choose>
  </xsl:template>

  <xsl:template match="*[name() = 'output-scan-point' and (namespace-uri() = 'http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-external-alarm')]">
      <xsl:choose>
        <xsl:when test="node() = 'Alarm-Output-Port-1'">
          <xsl:element name="output-scan-point" namespace="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-external-alarm"><xsl:text>Alarm-Output-Nta</xsl:text></xsl:element>
        </xsl:when>
        <xsl:otherwise>
            <xsl:copy>
               <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
        </xsl:otherwise>
      </xsl:choose>
  </xsl:template>

  <!-- add new component -->
  <xsl:template match="*[name() = 'hardware' and (namespace-uri() = 'urn:ietf:params:xml:ns:yang:ietf-hardware')]">
      <xsl:copy>
          <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
<component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>External-Alarm-Port-Nta</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:external-alarm-port</class>
      <parent>Board-Nta</parent>
      <parent-rel-pos>1</parent-rel-pos>
      <admin-state>unlocked</admin-state>
   </component>
   <component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>External-Alarm-Port-Ntb</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:external-alarm-port</class>
      <parent>Board-Ntb</parent>
      <parent-rel-pos>1</parent-rel-pos>
      <admin-state>unlocked</admin-state>
   </component>
   <component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>Alarm-Output-Ntb</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:alarm-port-output-scan-point</class>
      <parent>External-Alarm-Port-Ntb</parent>
      <parent-rel-pos>1</parent-rel-pos>
      <admin-state>unlocked</admin-state>
   </component>
   <component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>Alarm-Input-Ntb-1</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:alarm-port-input-scan-point</class>
      <parent>External-Alarm-Port-Ntb</parent>
      <parent-rel-pos>1</parent-rel-pos>
      <admin-state>unlocked</admin-state>
   </component>
   <component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>Alarm-Input-Ntb-2</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:alarm-port-input-scan-point</class>
      <parent>External-Alarm-Port-Ntb</parent>
      <parent-rel-pos>2</parent-rel-pos>
      <admin-state>unlocked</admin-state>
   </component>
   <component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>Alarm-Input-Ntb-3</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:alarm-port-input-scan-point</class>
      <parent>External-Alarm-Port-Ntb</parent>
      <parent-rel-pos>3</parent-rel-pos>
      <admin-state>unlocked</admin-state>
   </component>
   <component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>Alarm-Input-Ntb-4</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:alarm-port-input-scan-point</class>
      <parent>External-Alarm-Port-Ntb</parent>
      <parent-rel-pos>4</parent-rel-pos>
      <admin-state>unlocked</admin-state>
   </component>
   <component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>Alarm-Input-Ntb-5</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:alarm-port-input-scan-point</class>
      <parent>External-Alarm-Port-Ntb</parent>
      <parent-rel-pos>5</parent-rel-pos>
      <admin-state>unlocked</admin-state>
   </component>

      </xsl:copy>
  </xsl:template>

</xsl:stylesheet>
