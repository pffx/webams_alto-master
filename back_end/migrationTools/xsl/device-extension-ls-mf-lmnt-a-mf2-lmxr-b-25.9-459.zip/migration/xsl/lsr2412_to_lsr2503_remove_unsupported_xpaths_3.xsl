<?xml version='1.0' encoding='utf-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"
	            xmlns:if="urn:ietf:params:xml:ns:yang:ietf-interfaces"
                xmlns:eth="urn:ieee:params:xml:ns:yang:ethernet"
		        xmlns:bbf-qos-cls="urn:bbf:yang:bbf-qos-classifiers"
		        xmlns:bbf-qos-pol="urn:bbf:yang:bbf-qos-policies"
		        xmlns:bbf-l2-fwd="urn:bbf:yang:bbf-l2-forwarding"
		        xmlns:nokia-dhcp-client="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-dhcp-client">

    <xsl:strip-space elements="*"/>
    <xsl:output method="xml" encoding="UTF-8" indent="yes"/>

    <!-- Remove /bbf-l2-fwd:forwarding -->
    <xsl:template match="bbf-l2-fwd:forwarding"/>

    <!-- Remove /if:interfaces/if:interface/bbf-l2-fwd:mac-learning -->
    <xsl:template match="if:interfaces/if:interface/bbf-l2-fwd:mac-learning"/>

    <!-- Remove /if:interfaces/if:interface/eth:ethernet -->
    <xsl:template match="if:interfaces/if:interface/eth:ethernet"/>

    <!-- Remove /bbf-qos-cls:classifiers -->
    <xsl:template match="bbf-qos-cls:classifiers"/>

    <!-- Remove /bbf-qos-pol:policies -->
    <xsl:template match="bbf-qos-pol:policies"/>

    <!-- Remove /bbf-qos-pol:qos-policy-profiles -->
    <xsl:template match="bbf-qos-pol:qos-policy-profiles"/>

    <!-- Remove /nokia-dhcp-client:dhcp-client -->
    <xsl:template match="nokia-dhcp-client:dhcp-client"/>

</xsl:stylesheet>
