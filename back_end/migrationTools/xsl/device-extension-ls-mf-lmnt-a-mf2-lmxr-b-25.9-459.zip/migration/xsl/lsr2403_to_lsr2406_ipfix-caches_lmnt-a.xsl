<?xml version="1.0" ?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                              xmlns:ipfix="urn:ietf:params:xml:ns:yang:ietf-ipfix-psamp" >
    <xsl:strip-space elements="*"/>
    <xsl:output method="xml" encoding="UTF-8" indent="yes"/>
    <xsl:param name="ipfix_ns" select="'urn:ietf:params:xml:ns:yang:ietf-ipfix-psamp'" />




    <!-- Need to explore if this scenario can be automated -->
    <!-- Remove cacheField with nokia-itfpktcnt:in-pkts -->
    <xsl:template match="ipfix:cacheField[ipfix:ieName='/if:interfaces-state/if:interface/if:statistics/nokia-itfpktcnt:in-pkts' and ../ipfix:cacheField/ipfix:ieName='/if:interfaces-state/if:interface/if:statistics/bbf-if-ctrs:in-pkts']">
    </xsl:template>
 
    <!-- Remove cacheField with nokia-itfpktcnt:out-pkts -->
    <xsl:template match="ipfix:cacheField[ipfix:ieName='/if:interfaces-state/if:interface/if:statistics/nokia-itfpktcnt:out-pkts' and ../ipfix:cacheField/ipfix:ieName='/if:interfaces-state/if:interface/if:statistics/bbf-if-ctrs:out-pkts']">
    </xsl:template>

    <!-- xsl rule to migrate an existing configured counter which has changed its xpath -->
    <xsl:template match="ipfix:ipfix/ipfix:cache/ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName">
        <xsl:choose>
            <xsl:when test="./text()='/if:interfaces-state/if:interface/if:statistics/nokia-itfpktcnt:in-pkts' and ../../ipfix:cacheField/ipfix:ieName!='/if:interfaces-state/if:interface/if:statistics/bbf-if-ctrs:in-pkts'">
                <xsl:element name="ieName" namespace="{$ipfix_ns}">
                    <xsl:text>/if:interfaces-state/if:interface/if:statistics/bbf-if-ctrs:in-pkts</xsl:text>
                </xsl:element>
            </xsl:when>
            <xsl:when test="./text()='/if:interfaces-state/if:interface/if:statistics/nokia-itfpktcnt:out-pkts' and ../../ipfix:cacheField/ipfix:ieName!='/if:interfaces-state/if:interface/if:statistics/bbf-if-ctrs:out-pkts'">
                <xsl:element name="ieName" namespace="{$ipfix_ns}">
                    <xsl:text>/if:interfaces-state/if:interface/if:statistics/bbf-if-ctrs:out-pkts</xsl:text>
                </xsl:element>
            </xsl:when>
            <xsl:otherwise>
                <xsl:copy>
                    <xsl:copy-of select="@*"/>
                    <xsl:apply-templates/>
                </xsl:copy>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>


   <!-- Delete cacheField if underlying ieName is set to an unsupported xpath -->
   <xsl:template match="ipfix:ipfix/ipfix:cache/ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField[
                          ipfix:ieName[
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:number-of-active-sessions' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:total-tasks' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:running-tasks' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:sleeping-tasks' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:stopped-tasks' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:zombie-tasks' or
                                      text()='/hw:hardware-state' or
                                      text()='/hw:hardware-state/hw:component/hw:state' or
                                      text()='/if:interfaces-state' or
                                      text()='/if:interfaces-state/if:interface/ip:ipv4' or
                                      text()='/if:interfaces-state/if:interface/ip:ipv6' or
                                      text()='/sys:system-state' or
                                      text()='/sys:system-state/sys:platform' or
                                      text()='/sys:system-state/nokia-ietf-system-aug:ntp-state' or
                                      text()='/lic-app:licensing-state'
                          ]
   ]"/>



   <!-- Delete cache if the count of the underlying ieNames equals to the count of ieNames that contain
                unsupported xpaths, i.e, not even 1 supported xpath is present in the cache. Also add 
                exporting process name to the each valid cache -->
   <xsl:variable name="exp">
             <xsl:value-of select="//*[ local-name() = 'name' and parent::*[local-name() = 'exportingProcess'] ]"/>
   </xsl:variable>
   <xsl:template match="ipfix:ipfix/ipfix:cache">
       <xsl:if test = "not(count(./ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName) > 0 and
                          count(./ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName) =
                          count(./ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName[
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:number-of-active-sessions' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:total-tasks' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:running-tasks' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:sleeping-tasks' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:stopped-tasks' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:zombie-tasks' or
                                      text()='/hw:hardware-state' or
                                      text()='/hw:hardware-state/hw:component/hw:state' or
                                      text()='/if:interfaces-state' or
                                      text()='/if:interfaces-state/if:interface/ip:ipv4' or
                                      text()='/if:interfaces-state/if:interface/ip:ipv6' or
                                      text()='/sys:system-state' or
                                      text()='/sys:system-state/sys:platform' or
                                      text()='/sys:system-state/nokia-ietf-system-aug:ntp-state' or
                                      text()='/lic-app:licensing-state'
                          ]))">
           <xsl:choose>
            <xsl:when test="./ipfix:exportingProcess">
                <xsl:copy>
                    <xsl:copy-of select="@*"/>
                    <xsl:apply-templates/>
                </xsl:copy>
            </xsl:when>
            <xsl:otherwise>
            <xsl:copy>
                <xsl:copy-of select="@*"/>
                <xsl:apply-templates/>
                <xsl:if test="string-length($exp) > 0">
                    <exportingProcess xmlns="urn:ietf:params:xml:ns:yang:ietf-ipfix-psamp">
                        <xsl:value-of select="$exp"/>
                    </exportingProcess>
                </xsl:if>
            </xsl:copy>
            </xsl:otherwise>
          </xsl:choose>
        </xsl:if>
    </xsl:template>


   <!-- xsl rule to remove ipfix elements -->
   <xsl:template match="ipfix:ipfix[
                          count(./ipfix:randomize-data-collection) = 0 and
                          count(./ipfix:ipfix-exporting-enable) = 0 and
                          count(./exportingProcess) = 0 and
                          (count(./ipfix:cache) = 0 or
                          count(./ipfix:cache/ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName) > 0 and
                          count(./ipfix:cache/ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName) = count(./ipfix:cache/ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName[
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:number-of-active-sessions' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:total-tasks' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:running-tasks' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:sleeping-tasks' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:stopped-tasks' or
                                      text()='/hw:hardware-state/hw:component/bbf-cpu-rs:cpu-processor-data/bbf-cpu-rs:task-counts/bbf-cpu-rs:zombie-tasks' or
                                      text()='/hw:hardware-state' or
                                      text()='/hw:hardware-state/hw:component/hw:state' or
                                      text()='/if:interfaces-state' or
                                      text()='/if:interfaces-state/if:interface/ip:ipv4' or
                                      text()='/if:interfaces-state/if:interface/ip:ipv6' or
                                      text()='/sys:system-state' or
                                      text()='/sys:system-state/sys:platform' or
                                      text()='/sys:system-state/nokia-ietf-system-aug:ntp-state' or
                                      text()='/lic-app:licensing-state'
                          ]))
   ]"/>

</xsl:stylesheet>