<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
	<xsl:strip-space elements="*"/>
	<xsl:output method="xml" indent="yes"/>

<!-- default rule -->
    <xsl:template match="*">
        <xsl:copy>
        <xsl:copy-of select="@*"/>
        <xsl:apply-templates/>
        </xsl:copy>
    </xsl:template>

	<!-- remove useless modules from NT -->
	<xsl:template match="*[name() = 'wavelength-profiles']">
        <xsl:choose>
         <xsl:when test="namespace-uri() = 'urn:bbf:yang:bbf-xpon'"/>
         <xsl:otherwise>
          <xsl:copy>
             <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
       </xsl:otherwise>
      </xsl:choose>
    </xsl:template>

	<xsl:template match="*[name() = 'ictp-config']">
        <xsl:choose>
         <xsl:when test="namespace-uri() = 'urn:bbf:yang:bbf-xpon'"/>
         <xsl:otherwise>
          <xsl:copy>
             <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
       </xsl:otherwise>
      </xsl:choose>
    </xsl:template>

	<xsl:template match="*[name() = 'multicast']">
        <xsl:choose>
         <xsl:when test="namespace-uri() = 'urn:bbf:yang:bbf-mgmd'"/>
         <xsl:otherwise>
          <xsl:copy>
             <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
       </xsl:otherwise>
      </xsl:choose>
    </xsl:template>

	<xsl:template match="*[name() = 'multicast-gemports-config']">
        <xsl:choose>
         <xsl:when test="namespace-uri() = 'urn:bbf:yang:bbf-xpon'"/>
         <xsl:otherwise>
          <xsl:copy>
             <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
       </xsl:otherwise>
      </xsl:choose>
    </xsl:template>

	<xsl:template match="*[name() = 'multicast-distribution-set-config']">
        <xsl:choose>
         <xsl:when test="namespace-uri() = 'urn:bbf:yang:bbf-xpon'"/>
         <xsl:otherwise>
          <xsl:copy>
             <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
       </xsl:otherwise>
      </xsl:choose>
    </xsl:template>

</xsl:stylesheet>
