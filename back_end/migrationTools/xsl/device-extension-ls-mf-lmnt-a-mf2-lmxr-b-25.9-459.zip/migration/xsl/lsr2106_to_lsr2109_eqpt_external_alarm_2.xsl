<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
  <xsl:strip-space elements="*"/>
  <xsl:output method="xml" encoding="UTF-8" indent="yes"/>
  <xsl:param name="hardwareNS" select="'urn:ietf:params:xml:ns:yang:ietf-hardware'"/>

<!-- default rule -->
  <xsl:template match="*">
    <xsl:copy>
      <xsl:copy-of select="@*"/>
      <xsl:apply-templates/>
    </xsl:copy>
  </xsl:template>

    <xsl:template match="@* | node()">
        <xsl:copy>
            <xsl:apply-templates select="@* | node()"/>
        </xsl:copy>
    </xsl:template>

   <xsl:template match="*[name()='component']">
        <xsl:choose>
            <xsl:when test="parent::*[name() = 'hardware'] and ./child::*[name()='name' and (text()='Alarm-Port-1' or text()='Alarm-Port-2' or text()='Alarm-Port-3' or text()='Alarm-Port-4' or text()='Alarm-Port-5')]">
            </xsl:when>
            <xsl:otherwise>
                <xsl:copy>
                    <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

  <xsl:template match="*[name() = 'hardware' and (namespace-uri() = 'urn:ietf:params:xml:ns:yang:ietf-hardware')]">
      <xsl:copy>
          <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
<component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>External-Alarm-Port</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:external-alarm-port</class>
      <parent>Chassis</parent>
      <parent-rel-pos>1</parent-rel-pos>
      <admin-state>unlocked</admin-state>
   </component>
   <component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>Alarm-Output-Port-1</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:alarm-port-output-scan-point</class>
      <parent>External-Alarm-Port</parent>
      <parent-rel-pos>1</parent-rel-pos>
      <admin-state>unlocked</admin-state>
   </component>
   <component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>Alarm-Input-Port-1</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:alarm-port-input-scan-point</class>
      <parent>External-Alarm-Port</parent>
      <parent-rel-pos>1</parent-rel-pos>
      <admin-state>unlocked</admin-state>
      <input-scan-point xmlns="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-external-alarm">
        <alarm-text>power-system-comprehensive-alarm</alarm-text>
        <polarity>normal</polarity>
        <alarm-severity>major</alarm-severity>
        <output-scan-point>Alarm-Output-Port-1</output-scan-point>
      </input-scan-point>
   </component>
   <component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>Alarm-Input-Port-2</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:alarm-port-input-scan-point</class>
      <parent>External-Alarm-Port</parent>
      <parent-rel-pos>2</parent-rel-pos>
      <admin-state>unlocked</admin-state>
      <input-scan-point xmlns="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-external-alarm">
        <alarm-text>battery-low-or-water-alarm</alarm-text>
        <polarity>normal</polarity>
        <alarm-severity>major</alarm-severity>
        <output-scan-point>Alarm-Output-Port-1</output-scan-point>
      </input-scan-point>
   </component>
   <component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>Alarm-Input-Port-3</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:alarm-port-input-scan-point</class>
      <parent>External-Alarm-Port</parent>
      <parent-rel-pos>3</parent-rel-pos>
      <admin-state>unlocked</admin-state>
      <input-scan-point xmlns="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-external-alarm">
        <alarm-text>fan-or-temperature-alarm</alarm-text>
        <polarity>normal</polarity>
        <alarm-severity>major</alarm-severity>
        <output-scan-point>Alarm-Output-Port-1</output-scan-point>
      </input-scan-point>
   </component>
   <component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>Alarm-Input-Port-4</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:alarm-port-input-scan-point</class>
      <parent>External-Alarm-Port</parent>
      <parent-rel-pos>4</parent-rel-pos>
      <admin-state>unlocked</admin-state>
      <input-scan-point xmlns="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-external-alarm">
        <alarm-text>door-alarm</alarm-text>
        <polarity>normal</polarity>
        <alarm-severity>major</alarm-severity>
        <output-scan-point>Alarm-Output-Port-1</output-scan-point>
      </input-scan-point>
   </component>
   <component xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware">
      <name>Alarm-Input-Port-5</name>
      <class xmlns:nokia-hwi="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-identities">nokia-hwi:alarm-port-input-scan-point</class>
      <parent>External-Alarm-Port</parent>
      <parent-rel-pos>5</parent-rel-pos>
      <admin-state>unlocked</admin-state>
      <input-scan-point xmlns="http://www.nokia.com/Fixed-Networks/BBA/yang/nokia-hardware-external-alarm">
        <alarm-text>smoke-or-water-alarm</alarm-text>
        <polarity>normal</polarity>
        <alarm-severity>major</alarm-severity>
        <output-scan-point>Alarm-Output-Port-1</output-scan-point>
      </input-scan-point>
   </component>

      </xsl:copy>
  </xsl:template>

</xsl:stylesheet>
