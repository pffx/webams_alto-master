<?xml version='1.0' encoding='UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
    <xsl:strip-space elements="*"/>
    <xsl:output method="xml" indent="yes"/>

<!-- default rule -->
    <xsl:template match="*">
        <xsl:copy>
        <xsl:copy-of select="@*"/>
        <xsl:apply-templates/>
        </xsl:copy>
    </xsl:template>

<!-- remove nodes whose name are 'NTA-C1', 'NTA-C2', 'NTA-C3', 'NTA-C4', 'NTB-C1', 'NTB-C2', 'NTB-C3', 'NTB-C4' -->
<!-- remove nodes whose class are 'bbf-hwt:transceiver', 'bbf-hwt:transceiver-link' -->
    <xsl:template match="*[name()='component']">
        <xsl:choose>

            <xsl:when test="parent::*[name() = 'hardware'] and ((./child::*[name()='name' and (text()='NTA-C1' or text()='NTA-C2' or text()='NTA-C3' or text()='NTA-C4' or text()='NTB-C1' or text()='NTB-C2' or text()='NTB-C3' or text()='NTB-C4')]) or (./child::*[name()='class' and (text()='bbf-hwt:transceiver' or text()='bbf-hwt:transceiver-link')]))">
            </xsl:when>

            <xsl:otherwise>
                <xsl:copy>
                    <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
            </xsl:otherwise>

        </xsl:choose>
    </xsl:template>

<!-- remove node lag-system -->
    <xsl:template match="*[name() = 'lag-system']">
        <xsl:choose>

            <xsl:when test="parent::*[name() = 'config']">
            </xsl:when>

            <xsl:otherwise>
                <xsl:copy>
                    <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
            </xsl:otherwise>

        </xsl:choose>
    </xsl:template>

<!-- remove node interfaces -->
    <xsl:template match="*[name() = 'interfaces']">
        <xsl:choose>

            <xsl:when test="parent::*[name() = 'config']">
            </xsl:when>

            <xsl:otherwise>
                <xsl:copy>
                    <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
            </xsl:otherwise>

        </xsl:choose>
    </xsl:template>

<!-- remove node routing -->
    <xsl:template match="*[name() = 'routing']">
        <xsl:choose>

            <xsl:when test="parent::*[name() = 'config']">
            </xsl:when>

            <xsl:otherwise>
                <xsl:copy>
                    <xsl:copy-of select="@*"/>
<xsl:apply-templates/>
</xsl:copy>
            </xsl:otherwise>

        </xsl:choose>
    </xsl:template>

</xsl:stylesheet>
