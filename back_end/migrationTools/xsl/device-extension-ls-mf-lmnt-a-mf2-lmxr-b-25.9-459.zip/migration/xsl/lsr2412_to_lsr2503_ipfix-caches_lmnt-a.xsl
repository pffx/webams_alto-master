<?xml version="1.0" ?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                              xmlns:ipfix="urn:ietf:params:xml:ns:yang:ietf-ipfix-psamp" >
    <xsl:strip-space elements="*"/>
    <xsl:output method="xml" encoding="UTF-8" indent="yes"/>
    <xsl:param name="ipfix_ns" select="'urn:ietf:params:xml:ns:yang:ietf-ipfix-psamp'" />






   <!-- Delete cacheField if underlying ieName is set to an unsupported xpath -->
   <xsl:template match="ipfix:ipfix/ipfix:cache/ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField[
                          ipfix:ieName[
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:name' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:ports' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:ports/bbf-l2-fwd:port/bbf-l2-fwd:name' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:ports/bbf-l2-fwd:port/bbf-l2-fwd:sub-interface' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:name' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses/bbf-l2-fwd:mac-address/bbf-l2-fwd:mac-address' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses/bbf-l2-fwd:mac-address/bbf-l2-fwd:forwarder' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses/bbf-l2-fwd:mac-address/bbf-l2-fwd:port' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses/bbf-l2-fwd:mac-address' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:ports/bbf-l2-fwd:port' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:forwarding-databases' or
                                      text()='/if:interfaces-state/if:interface/eth:Ethernet/eth:auto-negotiation/eth:status' or
                                      text()='/if:interfaces-state/if:interface/eth:Ethernet/eth:duplex' or
                                      text()='/if:interfaces-state/if:interface/eth:Ethernet/eth:speed' or
                                      text()='/if:interfaces-state/if:interface/eth:Ethernet/eth:auto-negotiation' or
                                      text()='/bbf-l2-fwd:forwarding-state' or
                                      text()='/hw:hardware-state/hw:component' or
                                      text()='/if:interfaces-state/if:interface' or
                                      text()='/if:interfaces-state/if:interface/ip:ipv4/ip:address' or
                                      text()='/if:interfaces-state/if:interface/ip:ipv6/ip:address' or
                                      text()='/sys:system-state/nokia-radius:radius-statistics' or
                                      text()='/sys:system-state/nokia-ietf-system-aug:ntp-state/nokia-ietf-system-aug:peer' or
                                      text()='/lic-app:licensing-state/lic-app:features'
                          ]
   ]"/>



   <!-- Delete cache if the count of the underlying ieNames equals to the count of ieNames that contain
                unsupported xpaths, i.e, not even 1 supported xpath is present in the cache. -->
   <xsl:template match="ipfix:ipfix/ipfix:cache[
                          count(./ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName) > 0 and
                          count(./ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName) =
                          count(./ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName[
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:name' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:ports' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:ports/bbf-l2-fwd:port/bbf-l2-fwd:name' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:ports/bbf-l2-fwd:port/bbf-l2-fwd:sub-interface' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:name' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses/bbf-l2-fwd:mac-address/bbf-l2-fwd:mac-address' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses/bbf-l2-fwd:mac-address/bbf-l2-fwd:forwarder' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses/bbf-l2-fwd:mac-address/bbf-l2-fwd:port' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses/bbf-l2-fwd:mac-address' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:ports/bbf-l2-fwd:port' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:forwarding-databases' or
                                      text()='/if:interfaces-state/if:interface/eth:Ethernet/eth:auto-negotiation/eth:status' or
                                      text()='/if:interfaces-state/if:interface/eth:Ethernet/eth:duplex' or
                                      text()='/if:interfaces-state/if:interface/eth:Ethernet/eth:speed' or
                                      text()='/if:interfaces-state/if:interface/eth:Ethernet/eth:auto-negotiation' or
                                      text()='/bbf-l2-fwd:forwarding-state' or
                                      text()='/hw:hardware-state/hw:component' or
                                      text()='/if:interfaces-state/if:interface' or
                                      text()='/if:interfaces-state/if:interface/ip:ipv4/ip:address' or
                                      text()='/if:interfaces-state/if:interface/ip:ipv6/ip:address' or
                                      text()='/sys:system-state/nokia-radius:radius-statistics' or
                                      text()='/sys:system-state/nokia-ietf-system-aug:ntp-state/nokia-ietf-system-aug:peer' or
                                      text()='/lic-app:licensing-state/lic-app:features'
                          ])
   ]"/>


   <!-- xsl rule to remove ipfix elements -->
   <xsl:template match="ipfix:ipfix[
                          count(./ipfix:randomize-data-collection) = 0 and
                          count(./ipfix:ipfix-exporting-enable) = 0 and
                          count(./exportingProcess) = 0 and
                          (count(./ipfix:cache) = 0 or
                          count(./ipfix:cache/ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName) > 0 and
                          count(./ipfix:cache/ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName) = count(./ipfix:cache/ipfix:permanentCache/ipfix:cacheLayout/ipfix:cacheField/ipfix:ieName[
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:name' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:ports' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:ports/bbf-l2-fwd:port/bbf-l2-fwd:name' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:ports/bbf-l2-fwd:port/bbf-l2-fwd:sub-interface' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:name' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses/bbf-l2-fwd:mac-address/bbf-l2-fwd:mac-address' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses/bbf-l2-fwd:mac-address/bbf-l2-fwd:forwarder' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses/bbf-l2-fwd:mac-address/bbf-l2-fwd:port' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarding-databases/bbf-l2-fwd:forwarding-database/bbf-l2-fwd:mac-addresses/bbf-l2-fwd:mac-address' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:ports/bbf-l2-fwd:port' or
                                      text()='/bbf-l2-fwd:forwarding-state/bbf-l2-fwd:forwarders/bbf-l2-fwd:forwarder/bbf-l2-fwd:forwarding-databases' or
                                      text()='/if:interfaces-state/if:interface/eth:Ethernet/eth:auto-negotiation/eth:status' or
                                      text()='/if:interfaces-state/if:interface/eth:Ethernet/eth:duplex' or
                                      text()='/if:interfaces-state/if:interface/eth:Ethernet/eth:speed' or
                                      text()='/if:interfaces-state/if:interface/eth:Ethernet/eth:auto-negotiation' or
                                      text()='/bbf-l2-fwd:forwarding-state' or
                                      text()='/hw:hardware-state/hw:component' or
                                      text()='/if:interfaces-state/if:interface' or
                                      text()='/if:interfaces-state/if:interface/ip:ipv4/ip:address' or
                                      text()='/if:interfaces-state/if:interface/ip:ipv6/ip:address' or
                                      text()='/sys:system-state/nokia-radius:radius-statistics' or
                                      text()='/sys:system-state/nokia-ietf-system-aug:ntp-state/nokia-ietf-system-aug:peer' or
                                      text()='/lic-app:licensing-state/lic-app:features'
                          ]))
   ]"/>

</xsl:stylesheet>